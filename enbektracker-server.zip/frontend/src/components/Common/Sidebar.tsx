import {
  Box,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerOverlay,
  Flex,
  IconButton,
  Text,
  useDisclosure,
} from "@chakra-ui/react"
import { useQueryClient } from "@tanstack/react-query"
import { FiLogOut, FiMenu } from "react-icons/fi"

import type { UserPublic } from "../../client"
import useAuth from "../../hooks/useAuth"
import SidebarItems from "./SidebarItems"

const Sidebar = () => {
  const queryClient = useQueryClient()
  const currentUser = queryClient.getQueryData<UserPublic>(["currentUser"])
  const { isOpen, onOpen, onClose } = useDisclosure()
  const { logout } = useAuth()

  const content = (
    <Flex direction="column" justify="space-between" h="full">
      <Box>
        <Box
          px={3}
          pb={4}
          borderBottomWidth="1px"
          borderColor="ui.border"
          mb={4}
        >
          <Text fontSize="11px" color="ui.muted" letterSpacing="0.08em">
            КОРПОРАТИВНАЯ СИСТЕМА
          </Text>
          <Text fontWeight="700" fontSize="lg" color="ui.main">
            Enbek Tracker
          </Text>
        </Box>
        <SidebarItems onClose={onClose} />
      </Box>

      <Box px={2} pt={4} borderTopWidth="1px" borderColor="ui.border">
        <Text fontSize="xs" color="ui.muted" noOfLines={2} mb={2}>
          {currentUser?.full_name || currentUser?.email}
        </Text>
        <Flex
          as="button"
          onClick={logout}
          align="center"
          gap={2}
          px={2}
          py={2}
          color="ui.danger"
          fontSize="sm"
          borderRadius="6px"
          _hover={{ bg: "#FDECEC" }}
        >
          <FiLogOut />
          Выйти
        </Flex>
      </Box>
    </Flex>
  )

  return (
    <>
      <IconButton
        onClick={onOpen}
        display={{ base: "flex", lg: "none" }}
        aria-label="Открыть меню"
        position="fixed"
        left={3}
        top={3}
        zIndex={40}
        size="sm"
        variant="subtle"
        icon={<FiMenu />}
      />

      <Drawer isOpen={isOpen} placement="left" onClose={onClose}>
        <DrawerOverlay />
        <DrawerContent
          maxW="280px"
          borderRightWidth="1px"
          borderColor="ui.border"
        >
          <DrawerCloseButton />
          <DrawerBody p={3}>{content}</DrawerBody>
        </DrawerContent>
      </Drawer>

      <Box
        w="280px"
        borderRightWidth="1px"
        borderColor="ui.border"
        bg="ui.panel"
        display={{ base: "none", lg: "block" }}
        position="sticky"
        top={0}
        h="100vh"
      >
        <Box p={3} h="full">
          {content}
        </Box>
      </Box>
    </>
  )
}

export default Sidebar
