import {
  Avatar,
  Badge,
  Box,
  Button,
  Flex,
  HStack,
  IconButton,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Popover,
  PopoverBody,
  PopoverContent,
  PopoverHeader,
  PopoverTrigger,
  Text,
  VStack,
} from "@chakra-ui/react"
import { useQuery, useQueryClient } from "@tanstack/react-query"
import { Link } from "@tanstack/react-router"
import { useEffect, useMemo, useState } from "react"
import { FiBell, FiLogOut, FiSettings, FiUser } from "react-icons/fi"

import type { UserPublic } from "../../client"
import useAuth from "../../hooks/useAuth"
import { readUserAvatar } from "../../hooks/useUserAvatar"
import { trackerApi } from "../../services/trackerApi"

const AppHeader = () => {
  const queryClient = useQueryClient()
  const { logout } = useAuth()
  const [avatarSrc, setAvatarSrc] = useState<string | null>(null)

  const currentUser = queryClient.getQueryData<
    UserPublic & { system_role?: string }
  >(["currentUser"])

  useEffect(() => {
    setAvatarSrc(readUserAvatar(currentUser?.id))
  }, [currentUser?.id])

  useEffect(() => {
    const handler = () => setAvatarSrc(readUserAvatar(currentUser?.id))
    window.addEventListener("tracker-avatar-updated", handler)
    return () => {
      window.removeEventListener("tracker-avatar-updated", handler)
    }
  }, [currentUser?.id])

  const { data: desktopEvents } = useQuery({
    queryKey: ["desktop-events-header"],
    queryFn: () => trackerApi.pollDesktopEvents({ limit: 200 }),
    enabled: Boolean(currentUser?.id),
    refetchInterval: 30_000,
    retry: false,
  })

  const recentEvents = useMemo(
    () =>
      [...(desktopEvents?.data ?? [])].sort((a, b) => b.id - a.id).slice(0, 8),
    [desktopEvents],
  )

  return (
    <Flex
      as="header"
      h="68px"
      borderBottomWidth="1px"
      borderColor="ui.border"
      bg="linear-gradient(180deg, #FFFFFF 0%, #F7FAFF 100%)"
      px={{ base: 3, md: 5 }}
      align="center"
      justify="space-between"
      position="sticky"
      top={0}
      zIndex={20}
    >
      <Box minW={{ base: "auto", xl: "240px" }}>
        <Text fontSize="11px" color="ui.muted" letterSpacing="0.06em">
          АО ЦРТР
        </Text>
        <Text fontSize="12px" color="ui.darkSlate">
          Корпоративная система задач
        </Text>
      </Box>

      <Text
        flex={1}
        textAlign="center"
        display={{ base: "none", lg: "block" }}
        fontSize="13px"
        fontWeight="600"
        color="ui.darkSlate"
      >
        Министерство труда и социальной защиты населения Республики Казахстан
      </Text>

      <HStack spacing={3}>
        <Popover placement="bottom-end">
          <PopoverTrigger>
            <Button
              variant="subtle"
              size="sm"
              px={2}
              leftIcon={<FiBell />}
              position="relative"
            >
              Уведомления
              {!!recentEvents.length && (
                <Badge
                  ml={1}
                  colorScheme="red"
                  borderRadius="full"
                  minW="18px"
                  textAlign="center"
                >
                  {recentEvents.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent borderColor="ui.border" maxW="420px">
            <PopoverHeader
              fontWeight="700"
              fontSize="sm"
              borderBottomWidth="1px"
              borderColor="ui.border"
            >
              Последние события
            </PopoverHeader>
            <PopoverBody maxH="360px" overflowY="auto" p={0}>
              {!recentEvents.length && (
                <Text px={4} py={3} color="ui.muted" fontSize="sm">
                  Новых событий нет
                </Text>
              )}
              {recentEvents.map((event) => (
                <Box
                  key={event.id}
                  px={4}
                  py={3}
                  borderBottomWidth="1px"
                  borderColor="ui.secondary"
                >
                  <HStack justify="space-between" align="start">
                    <VStack align="start" spacing={0}>
                      <Text fontSize="sm" fontWeight="600">
                        {event.title}
                      </Text>
                      <Text fontSize="xs" color="ui.muted">
                        {event.message}
                      </Text>
                      <Text fontSize="xs" color="ui.dim">
                        {new Date(event.created_at).toLocaleString()}
                      </Text>
                    </VStack>
                    {event.task_id ? (
                      <Button
                        as={Link}
                        to="/tasks/$taskId"
                        params={{ taskId: String(event.task_id) }}
                        size="xs"
                        variant="subtle"
                      >
                        Открыть
                      </Button>
                    ) : null}
                  </HStack>
                </Box>
              ))}
            </PopoverBody>
          </PopoverContent>
        </Popover>

        <Menu>
          <MenuButton
            as={IconButton}
            aria-label="Профиль"
            variant="subtle"
            icon={
              <Avatar
                size="sm"
                name={currentUser?.full_name || currentUser?.email}
                src={avatarSrc || undefined}
              />
            }
          />
          <MenuList borderColor="ui.border">
            <MenuItem icon={<FiUser />} as={Link} to="/settings">
              Профиль
            </MenuItem>
            <MenuItem icon={<FiSettings />} as={Link} to="/settings">
              Настройки
            </MenuItem>
            <MenuItem icon={<FiLogOut />} color="ui.danger" onClick={logout}>
              Выйти
            </MenuItem>
          </MenuList>
        </Menu>
      </HStack>
    </Flex>
  )
}

export default AppHeader
