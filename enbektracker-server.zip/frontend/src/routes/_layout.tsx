import { Box, Flex, Spinner } from "@chakra-ui/react"
import { Outlet, createFileRoute, redirect } from "@tanstack/react-router"

import AppHeader from "../components/Common/AppHeader"
import Sidebar from "../components/Common/Sidebar"
import useAuth, { isLoggedIn } from "../hooks/useAuth"

export const Route = createFileRoute("/_layout")({
  component: Layout,
  beforeLoad: async () => {
    if (!isLoggedIn()) {
      throw redirect({
        to: "/login",
      })
    }
  },
})

function Layout() {
  const { isLoading } = useAuth()

  return (
    <Flex w="100%" minH="100vh" position="relative" bg="ui.light">
      <Sidebar />
      <Flex direction="column" flex={1} minW={0}>
        <AppHeader />
        <Box flex={1} minW={0}>
          {isLoading ? (
            <Flex justify="center" align="center" h="full" w="full">
              <Spinner size="xl" color="ui.main" />
            </Flex>
          ) : (
            <Outlet />
          )}
        </Box>
      </Flex>
    </Flex>
  )
}
