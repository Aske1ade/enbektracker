import {
  Badge,
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Heading,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
  Text,
  VStack,
  useDisclosure,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { Link, Outlet, createFileRoute, useMatchRoute } from "@tanstack/react-router"
import { useMemo, useState } from "react"

import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"
import type { Project } from "../../types/tracker"

export const Route = createFileRoute("/_layout/projects")({
  component: ProjectsPage,
})

type ProjectGroup = {
  blockName: string
  projects: Project[]
}

function ProjectsPage() {
  const matchRoute = useMatchRoute()
  const isProjectDetailsPath = Boolean(
    matchRoute({
      to: "/projects/$projectId",
      fuzzy: false,
    }),
  )

  const queryClient = useQueryClient()
  const modal = useDisclosure()
  const showToast = useCustomToast()

  const [search, setSearch] = useState("")
  const [blockFilter, setBlockFilter] = useState("all")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")

  const { data, isLoading } = useQuery({
    queryKey: ["projects", "wall-list"],
    queryFn: () =>
      trackerApi.listProjects({
        page: 1,
        page_size: 500,
        sort_by: "name",
        sort_order: "asc",
      }),
  })

  const createMutation = useMutation({
    mutationFn: () =>
      trackerApi.createProject({
        name,
        description,
      }),
    onSuccess: () => {
      setName("")
      setDescription("")
      modal.onClose()
      queryClient.invalidateQueries({ queryKey: ["projects"] })
      showToast.success("Успешно", "Проект создан")
    },
    onError: (error) => showToast.error("Не удалось создать проект", error),
  })

  const groupedProjects = useMemo<ProjectGroup[]>(() => {
    const rows = data?.data ?? []
    const query = search.trim().toLowerCase()

    const filtered = rows.filter((project) => {
      if (!query) return true
      const haystack = [
        project.name,
        project.description || "",
        project.organization_name || "",
        project.block_name || "",
      ]
        .join(" ")
        .toLowerCase()
      return haystack.includes(query)
    })

    const grouped = new Map<string, Project[]>()
    for (const project of filtered) {
      const blockName = project.block_name?.trim() || "Без группы"
      if (blockFilter !== "all" && blockFilter !== blockName) {
        continue
      }
      const bucket = grouped.get(blockName) ?? []
      bucket.push(project)
      grouped.set(blockName, bucket)
    }

    return [...grouped.entries()]
      .map(([blockName, projects]) => ({
        blockName,
        projects: projects.sort((a, b) => a.name.localeCompare(b.name, "ru")),
      }))
      .sort((a, b) => {
        if (a.blockName === "Без группы") return 1
        if (b.blockName === "Без группы") return -1
        return a.blockName.localeCompare(b.blockName, "ru")
      })
  }, [blockFilter, data?.data, search])

  const blockOptions = useMemo(() => {
    const set = new Set<string>()
    for (const project of data?.data ?? []) {
      set.add(project.block_name?.trim() || "Без группы")
    }
    return [...set].sort((a, b) => {
      if (a === "Без группы") return 1
      if (b === "Без группы") return -1
      return a.localeCompare(b, "ru")
    })
  }, [data?.data])

  const visibleProjectsCount = groupedProjects.reduce(
    (acc, group) => acc + group.projects.length,
    0,
  )

  if (isProjectDetailsPath) {
    return <Outlet />
  }

  return (
    <Container maxW="full" py={6}>
      <HStack justify="space-between" mb={5} align="start" flexWrap="wrap" gap={3}>
        <Box>
          <Heading size="lg">Проекты</Heading>
          <Text color="ui.muted" mt={1}>
            Структура как в YouTrack: проекты сгруппированы по блокам, вход в проект в
            один клик.
          </Text>
        </Box>
        <Button variant="primary" onClick={modal.onOpen}>
          Создать проект
        </Button>
      </HStack>

      <Grid templateColumns={{ base: "1fr", xl: "320px 1fr" }} gap={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            p={4}
            bg="white"
            boxShadow="sm"
            position={{ xl: "sticky" }}
            top={4}
          >
            <Heading size="sm" mb={3}>
              Фильтры
            </Heading>
            <FormControl mb={3}>
              <FormLabel>Поиск проекта</FormLabel>
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Название, описание, организация"
              />
            </FormControl>
            <FormControl>
              <FormLabel>Группа (блок)</FormLabel>
              <Select
                value={blockFilter}
                onChange={(e) => setBlockFilter(e.target.value)}
              >
                <option value="all">Все группы</option>
                {blockOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </Select>
            </FormControl>
            <HStack mt={4} spacing={2}>
              <Badge borderRadius="full" colorScheme="blue" px={2} py={1}>
                Групп: {groupedProjects.length}
              </Badge>
              <Badge borderRadius="full" colorScheme="green" px={2} py={1}>
                Проектов: {visibleProjectsCount}
              </Badge>
            </HStack>
          </Box>
        </GridItem>

        <GridItem>
          <VStack align="stretch" spacing={4}>
            {isLoading && (
              <Box
                borderWidth="1px"
                borderColor="ui.border"
                borderRadius="12px"
                p={6}
                bg="white"
              >
                <Text>Загрузка проектов...</Text>
              </Box>
            )}

            {!isLoading && groupedProjects.length === 0 && (
              <Box
                borderWidth="1px"
                borderColor="ui.border"
                borderRadius="12px"
                p={6}
                bg="white"
              >
                <Text>Проекты не найдены</Text>
              </Box>
            )}

            {!isLoading &&
              groupedProjects.map((group) => (
                <Box
                  key={group.blockName}
                  borderWidth="1px"
                  borderColor="ui.border"
                  borderRadius="12px"
                  bg="white"
                  overflow="hidden"
                  boxShadow="sm"
                >
                  <HStack
                    justify="space-between"
                    px={4}
                    py={3}
                    borderBottomWidth="1px"
                    borderColor="ui.border"
                    bg="ui.secondary"
                  >
                    <Heading size="sm">{group.blockName}</Heading>
                    <Badge borderRadius="full" px={2} py={1} colorScheme="blue">
                      {group.projects.length}
                    </Badge>
                  </HStack>

                  <VStack spacing={0} align="stretch">
                    {group.projects.map((project, index) => (
                      <Box
                        key={project.id}
                        as={Link}
                        to="/projects/$projectId"
                        params={{ projectId: String(project.id) }}
                        px={4}
                        py={3}
                        borderTopWidth={index === 0 ? "0" : "1px"}
                        borderColor="ui.border"
                        _hover={{ bg: "#F8FAFD" }}
                      >
                        <HStack justify="space-between" align="start" gap={3}>
                          <Box minW={0}>
                            <Text fontWeight="700" noOfLines={1}>
                              {project.name}
                            </Text>
                            <Text fontSize="sm" color="ui.muted" noOfLines={2} mt={0.5}>
                              {project.description || "Описание не указано"}
                            </Text>
                            <HStack mt={2} spacing={2} flexWrap="wrap">
                              <Badge borderRadius="full">
                                Участники: {project.members_count ?? 0}
                              </Badge>
                              <Badge borderRadius="full">
                                Задачи: {project.tasks_count ?? 0}
                              </Badge>
                              <Badge borderRadius="full">
                                {project.organization_name || "Без организации"}
                              </Badge>
                              <Badge borderRadius="full" colorScheme="purple">
                                {project.department_name ||
                                  project.department_names?.join(", ") ||
                                  "Без департамента"}
                              </Badge>
                            </HStack>
                          </Box>
                          <Text color="ui.main" fontWeight="600" whiteSpace="nowrap">
                            Открыть →
                          </Text>
                        </HStack>
                      </Box>
                    ))}
                  </VStack>
                </Box>
              ))}
          </VStack>
        </GridItem>
      </Grid>

      <Modal isOpen={modal.isOpen} onClose={modal.onClose} isCentered>
        <ModalOverlay />
        <ModalContent borderRadius="12px">
          <ModalHeader>Новый проект</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl isRequired>
              <FormLabel>Название</FormLabel>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </FormControl>
            <FormControl mt={3}>
              <FormLabel>Описание</FormLabel>
              <Input
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </FormControl>
          </ModalBody>
          <ModalFooter gap={3}>
            <Button
              onClick={() => createMutation.mutate()}
              isLoading={createMutation.isPending}
              isDisabled={!name.trim()}
            >
              Создать
            </Button>
            <Button variant="subtle" onClick={modal.onClose}>
              Отмена
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Container>
  )
}
