import {
  Badge,
  Box,
  Button,
  Container,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  DrawerOverlay,
  FormControl,
  FormLabel,
  Grid,
  HStack,
  Heading,
  Input,
  Select,
  Spinner,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  VStack,
  useDisclosure,
} from "@chakra-ui/react"
import { useQuery } from "@tanstack/react-query"
import { Link, createFileRoute } from "@tanstack/react-router"
import { useMemo, useState } from "react"

import { trackerApi } from "../../services/trackerApi"
import type {
  CalendarDayTask,
  CalendarScope,
  CalendarViewBucket,
  CalendarViewMode,
} from "../../types/tracker"

export const Route = createFileRoute("/_layout/calendar")({
  component: CalendarPage,
})

function CalendarPage() {
  const [anchorDate, setAnchorDate] = useState(() => new Date())
  const [mode, setMode] = useState<CalendarViewMode>("month")
  const [scope, setScope] = useState<CalendarScope>("project")
  const [projectId, setProjectId] = useState("")
  const [departmentId, setDepartmentId] = useState("")
  const [projectSearch, setProjectSearch] = useState("")
  const [departmentSearch, setDepartmentSearch] = useState("")
  const [selectedDay, setSelectedDay] = useState<string | null>(null)
  const dayDrawer = useDisclosure()

  const projectNumber = projectId ? Number(projectId) : undefined
  const departmentNumber = departmentId ? Number(departmentId) : undefined

  const { data: projectsData } = useQuery({
    queryKey: ["projects-for-calendar"],
    queryFn: () =>
      trackerApi.listProjects({
        page: 1,
        page_size: 300,
        sort_by: "name",
        sort_order: "asc",
      }),
  })

  const { data: departmentsData } = useQuery({
    queryKey: ["departments-for-calendar"],
    queryFn: () => trackerApi.listDepartments(),
  })

  const filteredProjects = useMemo(() => {
    const query = projectSearch.trim().toLowerCase()
    if (!query) return projectsData?.data ?? []
    return (projectsData?.data ?? []).filter((project) =>
      project.name.toLowerCase().includes(query),
    )
  }, [projectSearch, projectsData?.data])

  const filteredDepartments = useMemo(() => {
    const query = departmentSearch.trim().toLowerCase()
    if (!query) return departmentsData?.data ?? []
    return (departmentsData?.data ?? []).filter((department) =>
      department.name.toLowerCase().includes(query),
    )
  }, [departmentSearch, departmentsData?.data])

  const { data: calendarView, isLoading } = useQuery({
    queryKey: [
      "calendar-view",
      toYmd(anchorDate),
      mode,
      scope,
      projectNumber,
      departmentNumber,
    ],
    queryFn: () =>
      trackerApi.calendarView({
        date: toYmd(anchorDate),
        mode,
        scope,
        project_id: scope === "project" ? projectNumber : undefined,
        department_id: departmentNumber,
      }),
  })

  const bucketsByDay = useMemo(() => {
    const map = new Map<string, CalendarViewBucket>()
    for (const bucket of calendarView?.data ?? []) {
      map.set(String(bucket.day).slice(0, 10), bucket)
    }
    return map
  }, [calendarView])

  const selectedBucket = selectedDay ? bucketsByDay.get(selectedDay) : undefined
  const dayTabs = useMemo(
    () =>
      (calendarView?.data ?? [])
        .map((bucket) => String(bucket.day).slice(0, 10))
        .sort((a, b) => a.localeCompare(b)),
    [calendarView?.data],
  )

  const monthStart = new Date(anchorDate.getFullYear(), anchorDate.getMonth(), 1)
  const monthEnd = new Date(anchorDate.getFullYear(), anchorDate.getMonth() + 1, 0)
  const gridStart = startOfWeekMonday(monthStart)
  const gridEnd = endOfWeekSunday(monthEnd)

  const gridDays = useMemo(() => {
    const days: Date[] = []
    const current = new Date(gridStart)
    while (current <= gridEnd) {
      days.push(new Date(current))
      current.setDate(current.getDate() + 1)
    }
    return days
  }, [gridStart, gridEnd])

  const headerLabel = useMemo(() => {
    if (mode === "day") {
      return anchorDate.toLocaleDateString("ru-RU", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      })
    }
    if (mode === "week") {
      const from = calendarView?.date_from
      const to = calendarView?.date_to
      if (!from || !to) return "Неделя"
      return `${new Date(from).toLocaleDateString("ru-RU")} - ${new Date(
        to,
      ).toLocaleDateString("ru-RU")}`
    }
    return capitalize(
      anchorDate.toLocaleDateString("ru-RU", {
        month: "long",
        year: "numeric",
      }),
    )
  }, [anchorDate, calendarView?.date_from, calendarView?.date_to, mode])

  const renderMonth = () => (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="md"
      overflow="hidden"
      bg="white"
    >
      <Grid
        templateColumns="repeat(7, minmax(0, 1fr))"
        borderBottomWidth="1px"
        borderColor="ui.border"
      >
        {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((dayName) => (
          <Box
            key={dayName}
            p={2}
            borderRightWidth="1px"
            borderColor="ui.border"
            fontSize="12px"
            textTransform="uppercase"
            fontWeight="700"
            color="ui.muted"
          >
            {dayName}
          </Box>
        ))}
      </Grid>

      <Grid templateColumns="repeat(7, minmax(0, 1fr))">
        {gridDays.map((day, index) => {
          const dayKey = toYmd(day)
          const bucket = bucketsByDay.get(dayKey)
          const totalCount = bucket?.total_count ?? 0
          const preview = bucket?.tasks.slice(0, 3) ?? []
          const inCurrentMonth = day.getMonth() === anchorDate.getMonth()
          const isToday = dayKey === toYmd(new Date())
          return (
            <Box
              key={`${dayKey}-${index}`}
              minH="150px"
              borderRightWidth={(index + 1) % 7 === 0 ? "0" : "1px"}
              borderBottomWidth="1px"
              borderColor={isToday ? "#1E3A5F" : "ui.border"}
              p={2}
              bg={calendarCellColor(bucket)}
              opacity={inCurrentMonth ? 1 : 0.45}
              cursor={totalCount > 0 ? "pointer" : "default"}
              onClick={() => {
                if (!totalCount) return
                setSelectedDay(dayKey)
                dayDrawer.onOpen()
              }}
            >
              <HStack justify="space-between" align="start" mb={1}>
                <Text fontSize="md" fontWeight="700">
                  {day.getDate()}
                </Text>
                {isToday ? (
                  <Badge colorScheme="blue" borderRadius="sm">
                    Сегодня
                  </Badge>
                ) : null}
              </HStack>

              {totalCount ? (
                <>
                  <Text fontSize="xs" color="ui.muted" mb={1}>
                    Всего: {totalCount}
                  </Text>
                  {preview.map((task) => (
                    <Text
                      key={task.id}
                      as={task.closed_at ? "s" : undefined}
                      fontSize="xs"
                      color={taskRowColor(task)}
                      noOfLines={1}
                    >
                      {task.title}
                    </Text>
                  ))}
                  {totalCount > preview.length ? (
                    <Text fontSize="xs" color="ui.muted" mt={1}>
                      +{totalCount - preview.length} задач
                    </Text>
                  ) : null}
                </>
              ) : (
                <Text fontSize="xs" color="ui.dim">
                  Без задач
                </Text>
              )}
            </Box>
          )
        })}
      </Grid>
    </Box>
  )

  const renderWeekOrDay = () => (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="md"
      overflow="hidden"
      bg="white"
    >
      <Table size="sm">
        <Thead>
          <Tr>
            <Th>Дата</Th>
            <Th>Задачи</Th>
            <Th>Просроченные</Th>
            <Th>Закрытые</Th>
            <Th>Действие</Th>
          </Tr>
        </Thead>
        <Tbody>
          {(calendarView?.data ?? []).map((bucket) => {
            const dayKey = String(bucket.day).slice(0, 10)
            return (
              <Tr key={dayKey}>
                <Td>{new Date(dayKey).toLocaleDateString("ru-RU")}</Td>
                <Td>{bucket.total_count}</Td>
                <Td>{bucket.overdue_count}</Td>
                <Td>{bucket.closed_count}</Td>
                <Td>
                  <Button
                    size="xs"
                    onClick={() => {
                      setSelectedDay(dayKey)
                      dayDrawer.onOpen()
                    }}
                    isDisabled={!bucket.total_count}
                  >
                    Открыть день
                  </Button>
                </Td>
              </Tr>
            )
          })}
        </Tbody>
      </Table>
    </Box>
  )

  return (
    <Container maxW="full" py={6}>
      <HStack justify="space-between" mb={4} flexWrap="wrap" gap={3}>
        <Box>
          <Heading size="lg">Календарь задач</Heading>
          <Text color="gray.600">
            Режимы день/неделя/месяц, переключение на мой календарь и
            детальный просмотр задач дня
          </Text>
        </Box>
        <HStack>
          <Button
            size="sm"
            variant="subtle"
            onClick={() => setAnchorDate(shiftDate(anchorDate, mode, -1))}
          >
            ←
          </Button>
          <Text minW="260px" textAlign="center" fontWeight="700">
            {headerLabel}
          </Text>
          <Button
            size="sm"
            variant="subtle"
            onClick={() => setAnchorDate(shiftDate(anchorDate, mode, 1))}
          >
            →
          </Button>
        </HStack>
      </HStack>

      <Grid templateColumns={{ base: "1fr", xl: "1.2fr 1fr" }} gap={4} mb={4}>
        <Box
          borderWidth="1px"
          borderColor="ui.border"
          borderRadius="md"
          p={4}
          bg="white"
        >
          <HStack mb={3} flexWrap="wrap">
            <FormControl w={{ base: "100%", md: "170px" }}>
              <FormLabel>Режим</FormLabel>
              <Select
                value={mode}
                onChange={(event) => setMode(event.target.value as CalendarViewMode)}
              >
                <option value="day">День</option>
                <option value="week">Неделя</option>
                <option value="month">Месяц</option>
              </Select>
            </FormControl>
            <FormControl w={{ base: "100%", md: "220px" }}>
              <FormLabel>Область</FormLabel>
              <Select
                value={scope}
                onChange={(event) => setScope(event.target.value as CalendarScope)}
              >
                <option value="project">Календарь проекта</option>
                <option value="my">Мой календарь</option>
              </Select>
            </FormControl>
            <FormControl w={{ base: "100%", md: "170px" }}>
              <FormLabel>Дата</FormLabel>
              <Input
                type="date"
                value={toYmd(anchorDate)}
                onChange={(event) => setAnchorDate(new Date(event.target.value))}
              />
            </FormControl>
          </HStack>

          <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={3}>
            <FormControl>
              <FormLabel>Проект</FormLabel>
              <Input
                placeholder="Поиск проекта"
                value={projectSearch}
                onChange={(event) => setProjectSearch(event.target.value)}
                mb={2}
                isDisabled={scope === "my"}
              />
              <Select
                value={projectId}
                onChange={(event) => setProjectId(event.target.value)}
                isDisabled={scope === "my"}
              >
                <option value="">Все проекты</option>
                {filteredProjects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Департамент</FormLabel>
              <Input
                placeholder="Поиск департамента"
                value={departmentSearch}
                onChange={(event) => setDepartmentSearch(event.target.value)}
                mb={2}
              />
              <Select
                value={departmentId}
                onChange={(event) => setDepartmentId(event.target.value)}
              >
                <option value="">Все департаменты</option>
                {filteredDepartments.map((department) => (
                  <option key={department.id} value={department.id}>
                    {department.name}
                  </option>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Box>

        <Box
          borderWidth="1px"
          borderColor="ui.border"
          borderRadius="md"
          p={4}
          bg="white"
        >
          <Text fontWeight="700" mb={2}>
            Легенда
          </Text>
          <Text fontSize="sm" color="ui.darkSlate">
            Зеленый: в срок, желтый: срок близко, красный: просрочено.
            Закрытые задачи отображаются зачеркнутыми.
          </Text>
        </Box>
      </Grid>

      {isLoading ? <Spinner /> : mode === "month" ? renderMonth() : renderWeekOrDay()}

      <Drawer isOpen={dayDrawer.isOpen} placement="right" onClose={dayDrawer.onClose} size="xl">
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Задачи на {selectedDay || "-"}</DrawerHeader>
          <DrawerBody>
            {dayTabs.length > 0 && (
              <HStack spacing={2} overflowX="auto" pb={2} mb={3}>
                {dayTabs.map((dayKey) => {
                  const bucket = bucketsByDay.get(dayKey)
                  const isActive = selectedDay === dayKey
                  const formatted = new Date(dayKey).toLocaleDateString("ru-RU", {
                    day: "2-digit",
                    month: "2-digit",
                  })
                  return (
                    <Button
                      key={dayKey}
                      size="sm"
                      variant={isActive ? "primary" : "subtle"}
                      onClick={() => setSelectedDay(dayKey)}
                      whiteSpace="nowrap"
                    >
                      {formatted} ({bucket?.total_count ?? 0})
                    </Button>
                  )
                })}
              </HStack>
            )}

            {!selectedBucket?.total_count && (
              <Text color="ui.muted">Нет задач на выбранный день</Text>
            )}
            {(selectedBucket?.total_count ?? 0) > 0 && (
              <VStack align="stretch" spacing={2}>
                {(selectedBucket?.tasks ?? []).map((task) => (
                  <Box
                    key={task.id}
                    borderWidth="1px"
                    borderColor="ui.border"
                    borderRadius="10px"
                    borderLeftWidth="4px"
                    borderLeftColor={taskAccentColor(task)}
                    bg={taskCardBackground(task)}
                    px={3}
                    py={2.5}
                  >
                    <HStack justify="space-between" align="start" gap={3}>
                      <Box minW={0}>
                        <Text
                          as={task.closed_at ? "s" : undefined}
                          fontWeight="700"
                          noOfLines={1}
                        >
                          <Link
                            to="/tasks/$taskId"
                            params={{ taskId: String(task.id) }}
                            onClick={() => dayDrawer.onClose()}
                          >
                            {task.title}
                          </Link>
                        </Text>
                        <Text fontSize="sm" color="ui.muted" noOfLines={1}>
                          {task.project_name || `Проект #${task.project_id}`} •{" "}
                          {task.assignee_name || "Без исполнителя"}
                        </Text>
                      </Box>
                      <VStack spacing={1} align="end">
                        <Badge
                          borderRadius="full"
                          bg={taskAccentColor(task)}
                          color="white"
                        >
                          {taskDeadlineLabel(task)}
                        </Badge>
                        <Badge borderRadius="full">
                          {task.status_name || "Без статуса"}
                        </Badge>
                      </VStack>
                    </HStack>
                    <Text fontSize="xs" color="ui.darkSlate" mt={1}>
                      Срок: {new Date(task.due_date).toLocaleString("ru-RU")}
                    </Text>
                  </Box>
                ))}
              </VStack>
            )}
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </Container>
  )
}

function toYmd(value: Date): string {
  const year = value.getFullYear()
  const month = `${value.getMonth() + 1}`.padStart(2, "0")
  const day = `${value.getDate()}`.padStart(2, "0")
  return `${year}-${month}-${day}`
}

function startOfWeekMonday(value: Date): Date {
  const day = new Date(value)
  const dayOfWeek = (day.getDay() + 6) % 7
  day.setDate(day.getDate() - dayOfWeek)
  day.setHours(0, 0, 0, 0)
  return day
}

function endOfWeekSunday(value: Date): Date {
  const day = new Date(value)
  const dayOfWeek = (day.getDay() + 6) % 7
  day.setDate(day.getDate() + (6 - dayOfWeek))
  day.setHours(23, 59, 59, 999)
  return day
}

function shiftDate(current: Date, mode: CalendarViewMode, direction: -1 | 1): Date {
  const next = new Date(current)
  if (mode === "day") {
    next.setDate(next.getDate() + direction)
    return next
  }
  if (mode === "week") {
    next.setDate(next.getDate() + direction * 7)
    return next
  }
  return new Date(next.getFullYear(), next.getMonth() + direction, 1)
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1)
}

function calendarCellColor(bucket?: CalendarViewBucket): string {
  if (!bucket?.total_count) return "#FFFFFF"
  if (bucket.overdue_count > 0) return "#FDECEC"
  return "#F4FBF5"
}

function taskRowColor(task: {
  closed_at?: string | null
  is_overdue: boolean
  computed_deadline_state: "green" | "yellow" | "red"
  closed_overdue: boolean
}): string {
  if (task.closed_at && task.closed_overdue) return "#C62828"
  if (task.closed_at) return "#6b7280"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#C62828"
  if (task.computed_deadline_state === "yellow") return "#B7791F"
  return "#2F855A"
}

function taskAccentColor(task: CalendarDayTask): string {
  if (task.closed_at && task.closed_overdue) return "#C62828"
  if (task.closed_at) return "#6b7280"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#C62828"
  if (task.computed_deadline_state === "yellow") return "#B7791F"
  return "#2F855A"
}

function taskCardBackground(task: CalendarDayTask): string {
  if (task.closed_at) return "#F7F8FA"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#FFF4F4"
  if (task.computed_deadline_state === "yellow") return "#FFF8E8"
  return "#F3FBF5"
}

function taskDeadlineLabel(task: CalendarDayTask): string {
  if (task.closed_at && task.closed_overdue) return "Закрыта с просрочкой"
  if (task.closed_at) return "Закрыта"
  if (task.is_overdue || task.computed_deadline_state === "red") return "Просрочено"
  if (task.computed_deadline_state === "yellow") return "Срок близко"
  return "В срок"
}
