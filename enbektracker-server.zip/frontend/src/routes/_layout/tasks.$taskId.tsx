import {
  Badge,
  Box,
  Button,
  Checkbox,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Heading,
  Input,
  Select,
  Table,
  Textarea,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  VStack,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { createFileRoute, useNavigate } from "@tanstack/react-router"
import { type ReactNode, useEffect, useMemo, useState } from "react"

import RichTextContent, {
  htmlToText,
} from "../../components/Common/RichTextContent"
import RichTextEditor from "../../components/Common/RichTextEditor"
import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"

export const Route = createFileRoute("/_layout/tasks/$taskId")({
  component: TaskDetailPage,
})

function TaskDetailPage() {
  const { taskId } = Route.useParams()
  const id = Number(taskId)
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const showToast = useCustomToast()
  const closeTaskOverlay = () => {
    navigate({ to: "/tasks" })
  }

  const { data: task } = useQuery({
    queryKey: ["task", id],
    queryFn: () => trackerApi.getTask(id),
  })

  const { data: projectData } = useQuery({
    queryKey: ["project", task?.project_id],
    queryFn: () => trackerApi.getProject(task?.project_id as number),
    enabled: Boolean(task?.project_id),
  })

  const { data: usersData } = useQuery({
    queryKey: ["tracker-users"],
    queryFn: () => trackerApi.listUsers(),
    retry: false,
  })

  const usersById = useMemo(
    () =>
      new Map(
        (usersData?.data ?? []).map((user) => [
          user.id,
          user.full_name || user.email,
        ]),
      ),
    [usersData?.data],
  )

  const { data: projectMembersData } = useQuery({
    queryKey: ["project-members", task?.project_id],
    queryFn: () => trackerApi.listProjectMembers(task?.project_id as number),
    enabled: Boolean(task?.project_id),
  })

  const { data: statusesData } = useQuery({
    queryKey: ["project-statuses", task?.project_id],
    queryFn: () => trackerApi.getProjectStatuses(Number(task?.project_id)),
    enabled: !!task?.project_id,
  })

  const { data: commentsData } = useQuery({
    queryKey: ["task-comments", id],
    queryFn: () => trackerApi.listTaskComments(id),
  })

  const { data: attachmentsData } = useQuery({
    queryKey: ["task-attachments", id],
    queryFn: () => trackerApi.listTaskAttachments(id),
  })

  const { data: historyData } = useQuery({
    queryKey: ["task-history", id],
    queryFn: () => trackerApi.taskHistory(id),
  })

  const lastHistoryEntry = historyData?.data[0]

  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    assignee_id: "",
    controller_id: "",
    due_date: "",
    workflow_status_id: "",
  })

  const [commentText, setCommentText] = useState("")
  const [closeComment, setCloseComment] = useState("")
  const [selectedCloseAttachmentIds, setSelectedCloseAttachmentIds] = useState<
    number[]
  >([])
  const [fileToUpload, setFileToUpload] = useState<File | null>(null)

  useEffect(() => {
    if (!task) return
    setEditForm({
      title: task.title,
      description: task.description,
      assignee_id: task.assignee_id ? String(task.assignee_id) : "",
      controller_id: task.controller_id ? String(task.controller_id) : "",
      due_date: task.due_date.slice(0, 16),
      workflow_status_id: String(task.workflow_status_id),
    })
  }, [task])

  const attachmentIdSet = useMemo(
    () => new Set(selectedCloseAttachmentIds),
    [selectedCloseAttachmentIds],
  )
  const memberOptions = useMemo(() => {
    const members =
      projectMembersData?.data.filter((member) => member.is_active) ?? []
    return members.map((member) => {
      const displayName =
        usersById.get(member.user_id) || `Пользователь #${member.user_id}`
      return {
        id: member.user_id,
        role: member.role,
        label: `${displayName} (${member.role})`,
      }
    })
  }, [projectMembersData?.data, usersById])

  const refreshAll = () => {
    queryClient.invalidateQueries({ queryKey: ["task", id] })
    queryClient.invalidateQueries({ queryKey: ["tasks"] })
    queryClient.invalidateQueries({ queryKey: ["task-comments", id] })
    queryClient.invalidateQueries({ queryKey: ["task-attachments", id] })
    queryClient.invalidateQueries({ queryKey: ["task-history", id] })
  }

  const updateMutation = useMutation({
    mutationFn: () =>
      trackerApi.updateTask(id, {
        title: editForm.title,
        description: editForm.description,
        assignee_id: editForm.assignee_id ? Number(editForm.assignee_id) : null,
        controller_id: editForm.controller_id
          ? Number(editForm.controller_id)
          : null,
        due_date: new Date(editForm.due_date).toISOString(),
        workflow_status_id: Number(editForm.workflow_status_id),
      }),
    onSuccess: () => {
      showToast.success("Успешно", "Задача обновлена")
      refreshAll()
    },
    onError: (error) => showToast.error("Не удалось обновить задачу", error),
  })

  const addCommentMutation = useMutation({
    mutationFn: () => trackerApi.addTaskComment(id, commentText),
    onSuccess: () => {
      setCommentText("")
      showToast.success("Успешно", "Комментарий добавлен")
      refreshAll()
    },
    onError: (error) =>
      showToast.error("Не удалось добавить комментарий", error),
  })

  const uploadMutation = useMutation({
    mutationFn: () => {
      if (!fileToUpload) throw new Error("Файл не выбран")
      return trackerApi.uploadAttachment(id, fileToUpload)
    },
    onSuccess: (attachment) => {
      setFileToUpload(null)
      setSelectedCloseAttachmentIds((prev) =>
        prev.includes(attachment.id) ? prev : [...prev, attachment.id],
      )
      showToast.success("Успешно", "Файл загружен")
      refreshAll()
    },
    onError: (error) => showToast.error("Не удалось загрузить файл", error),
  })

  const deleteAttachmentMutation = useMutation({
    mutationFn: (attachmentId: number) => trackerApi.deleteAttachment(attachmentId),
    onSuccess: () => {
      showToast.success("Успешно", "Вложение удалено")
      refreshAll()
    },
    onError: (error) => showToast.error("Не удалось удалить вложение", error),
  })

  const closeMutation = useMutation({
    mutationFn: () =>
      trackerApi.closeTask(id, {
        comment: closeComment || undefined,
        attachment_ids: selectedCloseAttachmentIds,
      }),
    onSuccess: () => {
      setCloseComment("")
      setSelectedCloseAttachmentIds([])
      showToast.success("Успешно", "Задача закрыта")
      refreshAll()
    },
    onError: (error) => showToast.error("Не удалось закрыть задачу", error),
  })

  const downloadAttachment = async (
    attachmentId: number,
    fallbackFileName: string,
  ) => {
    try {
      const { blob, fileName } = await trackerApi.downloadAttachment(
        attachmentId,
      )
      const objectUrl = URL.createObjectURL(blob)
      const anchor = document.createElement("a")
      anchor.href = objectUrl
      anchor.download = fileName || fallbackFileName || `attachment-${attachmentId}`
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      URL.revokeObjectURL(objectUrl)
    } catch (error) {
      showToast.error("Не удалось получить вложение", error)
    }
  }

  if (!task) {
    return (
      <Box
        position="fixed"
        inset={0}
        bg="blackAlpha.500"
        zIndex={1400}
        display="flex"
        justifyContent="center"
        alignItems="flex-start"
        px={{ base: 2, md: 6 }}
        py={{ base: 3, md: 8 }}
        onClick={closeTaskOverlay}
      >
        <Box
          w="100%"
          maxW="860px"
          bg="white"
          borderRadius="14px"
          borderWidth="1px"
          borderColor="ui.border"
          boxShadow="2xl"
          p={4}
          onClick={(event) => event.stopPropagation()}
        >
          <HStack justify="space-between" mb={2}>
            <Heading size="sm">Загрузка задачи #{id}</Heading>
            <Button size="sm" variant="subtle" onClick={closeTaskOverlay}>
              Закрыть
            </Button>
          </HStack>
          <Text>Загрузка...</Text>
        </Box>
      </Box>
    )
  }

  return (
    <Box
      position="fixed"
      inset={0}
      bg="blackAlpha.500"
      zIndex={1400}
      display="flex"
      justifyContent="center"
      alignItems="flex-start"
      px={{ base: 2, md: 6 }}
      py={{ base: 3, md: 8 }}
      onClick={closeTaskOverlay}
    >
      <Box
        role="dialog"
        aria-modal="true"
        w="100%"
        maxW="min(1080px, 94vw)"
        maxH="88vh"
        overflowY="auto"
        bg="white"
        borderRadius="16px"
        borderWidth="1px"
        borderColor="ui.border"
        boxShadow="2xl"
        p={0}
        onClick={(event) => event.stopPropagation()}
      >
        <HStack
          justify="space-between"
          align="start"
          mb={0}
          flexWrap="wrap"
          gap={3}
          position="sticky"
          top={0}
          zIndex={2}
          bg="linear-gradient(120deg, #12375A 0%, #1D5D91 100%)"
          color="white"
          px={{ base: 3, md: 5 }}
          py={{ base: 3, md: 4 }}
          borderBottomWidth="1px"
          borderColor="rgba(255,255,255,0.24)"
        >
          <Box>
            <Heading size="md" mb={1}>
              {task.title}
            </Heading>
            <Text color="whiteAlpha.900" fontSize="sm">
              Задача #{task.id}
            </Text>
            <Text color="whiteAlpha.800" fontSize="xs" mt={1}>
              Последнее обновление:{" "}
              {formatLastUpdate(lastHistoryEntry, usersById)}
            </Text>
          </Box>
          <HStack spacing={2} flexWrap="wrap">
            <Badge
              colorScheme={badgeByState(task.computed_deadline_state)}
              borderRadius="full"
            >
              {deadlineLabel(task.computed_deadline_state)}
            </Badge>
            <Badge borderRadius="full" colorScheme="blue">
              {task.status_name || task.workflow_status_name || "status"}
            </Badge>
            <Button size="sm" colorScheme="blackAlpha" onClick={closeTaskOverlay}>
              Закрыть
            </Button>
          </HStack>
        </HStack>

        <Box px={{ base: 3, md: 5 }} py={{ base: 3, md: 4 }}>
          <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4}>
        <GridItem>
          <Panel title="Данные задачи">
            <Table size="sm" variant="simple">
              <Tbody>
                <Tr>
                  <Td>Проект</Td>
                  <Td>{task.project_name || task.project_id}</Td>
                </Tr>
                <Tr>
                  <Td>Состояние задачи</Td>
                  <Td>
                    {task.status_name || task.workflow_status_name || "-"}
                  </Td>
                </Tr>
                <Tr>
                  <Td>Состояние по сроку</Td>
                  <Td>{deadlineLabel(task.computed_deadline_state)}</Td>
                </Tr>
                <Tr>
                  <Td>Срок</Td>
                  <Td>{formatDateTime(task.due_date)}</Td>
                </Tr>
                <Tr>
                  <Td>Исполнитель</Td>
                  <Td>{task.assignee_name || task.assignee_id || "-"}</Td>
                </Tr>
                <Tr>
                  <Td>Контроллер</Td>
                  <Td>{task.controller_name || task.controller_id || "-"}</Td>
                </Tr>
                <Tr>
                  <Td>Создана</Td>
                  <Td>{formatDateTime(task.created_at)}</Td>
                </Tr>
                <Tr>
                  <Td>Обновлена</Td>
                  <Td>{formatDateTime(task.updated_at)}</Td>
                </Tr>
                <Tr>
                  <Td>Закрыта</Td>
                  <Td>
                    {task.closed_at ? formatDateTime(task.closed_at) : "-"}
                  </Td>
                </Tr>
              </Tbody>
            </Table>
            <Box mt={4}>
              <Text fontSize="xs" color="ui.muted" mb={2}>
                Описание
              </Text>
              <RichTextContent value={task.description} />
            </Box>
          </Panel>
        </GridItem>

        <GridItem>
          <Panel title="Действия по задаче">
            <VStack spacing={3} align="stretch">
              <FormControl>
                <FormLabel>Название</FormLabel>
                <Input
                  value={editForm.title}
                  onChange={(e) =>
                    setEditForm((p) => ({ ...p, title: e.target.value }))
                  }
                />
              </FormControl>
              <FormControl>
                <FormLabel>Описание</FormLabel>
                <RichTextEditor
                  value={editForm.description}
                  onChange={(next) =>
                    setEditForm((p) => ({ ...p, description: next }))
                  }
                  minH="180px"
                />
              </FormControl>
              <FormControl>
                <FormLabel>Исполнитель</FormLabel>
                <Select
                  value={editForm.assignee_id}
                  onChange={(e) =>
                    setEditForm((p) => ({ ...p, assignee_id: e.target.value }))
                  }
                >
                  <option value="">Не назначен</option>
                  {memberOptions.map((member) => (
                    <option
                      key={`assignee-${member.id}-${member.role}`}
                      value={member.id}
                    >
                      {member.label}
                    </option>
                  ))}
                </Select>
              </FormControl>
              <FormControl>
                <FormLabel>Контроллер</FormLabel>
                <Select
                  value={editForm.controller_id}
                  onChange={(e) =>
                    setEditForm((p) => ({
                      ...p,
                      controller_id: e.target.value,
                    }))
                  }
                >
                  <option value="">Не назначен</option>
                  {memberOptions
                    .filter(
                      (member) =>
                        member.role === "controller" ||
                        member.role === "manager",
                    )
                    .map((member) => (
                      <option
                        key={`controller-${member.id}-${member.role}`}
                        value={member.id}
                      >
                        {member.label}
                      </option>
                    ))}
                </Select>
              </FormControl>
              <HStack>
                <FormControl>
                  <FormLabel>Срок</FormLabel>
                  <Input
                    type="datetime-local"
                    value={editForm.due_date}
                    onChange={(e) =>
                      setEditForm((p) => ({ ...p, due_date: e.target.value }))
                    }
                    />
                </FormControl>
              </HStack>
              <FormControl>
                <FormLabel>Состояние задачи</FormLabel>
                <Select
                  value={editForm.workflow_status_id}
                  onChange={(e) =>
                    setEditForm((p) => ({
                      ...p,
                      workflow_status_id: e.target.value,
                    }))
                  }
                >
                  {statusesData?.data.map((status) => (
                    <option key={status.id} value={status.id}>
                      {status.name}
                    </option>
                  ))}
                </Select>
              </FormControl>
              <Button
                variant="primary"
                onClick={() => updateMutation.mutate()}
                isLoading={updateMutation.isPending}
                isDisabled={
                  !editForm.title.trim() ||
                  !htmlToText(editForm.description).trim()
                }
              >
                Сохранить изменения
              </Button>

              <Box borderTopWidth="1px" pt={3}>
                <Text fontSize="sm" fontWeight="600" mb={2}>
                  Закрытие
                </Text>
                <Text fontSize="xs" color="gray.600" mb={2}>
                  Политика проекта:{" "}
                  {projectData?.require_close_comment
                    ? "комментарий обязателен"
                    : "комментарий опционален"}
                  ;{" "}
                  {projectData?.require_close_attachment
                    ? "вложение обязательно"
                    : "вложение опционально"}
                </Text>
                <FormControl>
                  <FormLabel>Комментарий закрытия</FormLabel>
                  <Input
                    value={closeComment}
                    onChange={(e) => setCloseComment(e.target.value)}
                  />
                </FormControl>
                <FormControl mt={2}>
                  <FormLabel>Вложения для закрытия</FormLabel>
                  <VStack
                    align="stretch"
                    spacing={1}
                    maxH="130px"
                    overflowY="auto"
                    borderWidth="1px"
                    borderRadius="8px"
                    p={2}
                  >
                    {attachmentsData?.data.length ? (
                      attachmentsData.data.map((attachment) => (
                        <Checkbox
                          key={attachment.id}
                          isChecked={attachmentIdSet.has(attachment.id)}
                          onChange={(e) => {
                            setSelectedCloseAttachmentIds((prev) => {
                              if (e.target.checked)
                                return [...prev, attachment.id]
                              return prev.filter(
                                (item) => item !== attachment.id,
                              )
                            })
                          }}
                        >
                          {attachment.file_name} (#{attachment.id})
                        </Checkbox>
                      ))
                    ) : (
                      <Text color="gray.500" fontSize="xs">
                        Нет вложений
                      </Text>
                    )}
                  </VStack>
                </FormControl>
                <Button
                  mt={2}
                  colorScheme="red"
                  onClick={() => closeMutation.mutate()}
                  isLoading={closeMutation.isPending}
                >
                  Закрыть задачу
                </Button>
              </Box>
            </VStack>
          </Panel>
        </GridItem>

        <GridItem>
          <Panel title="История изменений">
            <Table size="sm">
              <Thead>
                <Tr>
                  <Th>Дата</Th>
                  <Th>Кто</Th>
                  <Th>Действие</Th>
                  <Th>Изменение</Th>
                </Tr>
              </Thead>
              <Tbody>
                {historyData?.data.map((entry) => (
                  <Tr key={entry.id}>
                    <Td>{formatDateTime(entry.created_at)}</Td>
                    <Td>
                      {usersById.get(entry.actor_id) || `#${entry.actor_id}`}
                    </Td>
                    <Td>{humanizeAction(entry.action)}</Td>
                    <Td>
                      {entry.field_name || "-"}: {entry.old_value || "-"} →{" "}
                      {entry.new_value || "-"}
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Panel>
        </GridItem>

        <GridItem>
          <Panel title="Комментарии">
            <HStack mb={3} align="start">
              <FormControl>
                <FormLabel>Новый комментарий</FormLabel>
                <Textarea
                  placeholder="Добавьте комментарий по задаче"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  minH="90px"
                />
              </FormControl>
              <Button
                onClick={() => addCommentMutation.mutate()}
                isDisabled={!commentText.trim()}
                mt={8}
              >
                Добавить
              </Button>
            </HStack>
            <VStack align="stretch" spacing={2} maxH="280px" overflowY="auto">
              {commentsData?.data.map((comment) => (
                <Box
                  key={comment.id}
                  borderWidth="1px"
                  borderRadius="8px"
                  p={3}
                >
                  <Text fontSize="sm">{comment.comment}</Text>
                  <Text fontSize="xs" color="gray.500" mt={1}>
                    {usersById.get(comment.author_id) ||
                      `Автор #${comment.author_id}`}{" "}
                    • {formatDateTime(comment.created_at)}
                  </Text>
                </Box>
              ))}
              {!commentsData?.data.length && (
                <Text fontSize="sm" color="ui.muted">
                  Комментариев пока нет.
                </Text>
              )}
            </VStack>
          </Panel>
        </GridItem>

        <GridItem>
          <Panel title="Вложения">
            <HStack mb={3} align="end">
              <FormControl>
                <FormLabel>Файл</FormLabel>
                <Input
                  type="file"
                  onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                />
              </FormControl>
              <Button
                onClick={() => uploadMutation.mutate()}
                isLoading={uploadMutation.isPending}
              >
                Загрузить
              </Button>
            </HStack>
            <Table size="sm">
              <Thead>
                <Tr>
                  <Th>ID</Th>
                  <Th>Файл</Th>
                  <Th>Размер</Th>
                  <Th>Действия</Th>
                </Tr>
              </Thead>
              <Tbody>
                {attachmentsData?.data.map((attachment) => (
                  <Tr key={attachment.id}>
                    <Td>{attachment.id}</Td>
                    <Td>{attachment.file_name}</Td>
                    <Td>{formatBytes(attachment.size_bytes)}</Td>
                    <Td>
                      <HStack spacing={2}>
                        <Button
                          size="xs"
                          onClick={() =>
                            downloadAttachment(attachment.id, attachment.file_name)
                          }
                        >
                          Скачать
                        </Button>
                        <Button
                          size="xs"
                          variant="danger"
                          onClick={() => deleteAttachmentMutation.mutate(attachment.id)}
                          isLoading={
                            deleteAttachmentMutation.isPending &&
                            deleteAttachmentMutation.variables === attachment.id
                          }
                        >
                          Удалить
                        </Button>
                      </HStack>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Panel>
        </GridItem>
          </Grid>
        </Box>
      </Box>
    </Box>
  )
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="10px"
      p={4}
      bg="white"
      boxShadow="sm"
    >
      <Heading
        size="sm"
        mb={3}
        textTransform="uppercase"
        letterSpacing="0.04em"
      >
        {title}
      </Heading>
      {children}
    </Box>
  )
}

function badgeByState(state: "green" | "yellow" | "red") {
  if (state === "red") return "red"
  if (state === "yellow") return "yellow"
  return "green"
}

function deadlineLabel(state: "green" | "yellow" | "red") {
  if (state === "red") return "Просрочено"
  if (state === "yellow") return "Срок близко"
  return "В срок"
}

function formatDateTime(value: string): string {
  return new Date(value).toLocaleString()
}

function formatBytes(value: number): string {
  if (value < 1024) return `${value} B`
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`
  return `${(value / (1024 * 1024)).toFixed(1)} MB`
}

function formatLastUpdate(
  entry:
    | {
        actor_id: number
        action: string
        created_at: string
      }
    | undefined,
  usersById: Map<number, string>,
): string {
  if (!entry) return "нет данных"
  const actor = usersById.get(entry.actor_id) || `#${entry.actor_id}`
  return `${actor} • ${humanizeAction(entry.action)} • ${formatDateTime(
    entry.created_at,
  )}`
}

function humanizeAction(action: string): string {
  const map: Record<string, string> = {
    created: "Создание",
    updated: "Обновление",
    due_date_changed: "Изменен срок",
    status_changed: "Изменен статус",
    assignee_changed: "Изменен исполнитель",
    closed: "Закрытие",
    reopened: "Переоткрытие",
    comment_added: "Добавлен комментарий",
    attachment_added: "Добавлено вложение",
  }
  return map[action] || action
}
