import {
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Heading,
  Input,
  Select,
  Stat,
  StatLabel,
  StatNumber,
  Switch,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
} from "@chakra-ui/react"
import { useQuery } from "@tanstack/react-query"
import { createFileRoute } from "@tanstack/react-router"
import { type ReactNode, useMemo, useState } from "react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"
import type { ReportTaskRow } from "../../types/tracker"

export const Route = createFileRoute("/_layout/reports")({
  component: ReportsPage,
})

function ReportsPage() {
  const showToast = useCustomToast()
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [projectId, setProjectId] = useState("")
  const [departmentId, setDepartmentId] = useState("")
  const [assigneeId, setAssigneeId] = useState("")
  const [statusId, setStatusId] = useState("")
  const [overdueOnly, setOverdueOnly] = useState(false)
  const [isDownloading, setIsDownloading] = useState<null | "csv" | "xlsx">(
    null,
  )
  const [previewPage, setPreviewPage] = useState(1)
  const [previewPageSize, setPreviewPageSize] = useState(20)

  const { data: projectsData } = useQuery({
    queryKey: ["projects-for-reports"],
    queryFn: () =>
      trackerApi.listProjects({
        page: 1,
        page_size: 200,
        sort_by: "name",
        sort_order: "asc",
      }),
  })

  const { data: departmentsData } = useQuery({
    queryKey: ["departments-for-reports"],
    queryFn: () => trackerApi.listDepartments(),
  })

  const { data: usersData } = useQuery({
    queryKey: ["tracker-users"],
    queryFn: () => trackerApi.listUsers(),
    retry: false,
  })

  const projectNumber = projectId ? Number(projectId) : undefined

  const { data: statusesData } = useQuery({
    queryKey: ["report-statuses", projectNumber],
    queryFn: () => trackerApi.getProjectStatuses(projectNumber as number),
    enabled: Boolean(projectNumber),
  })

  const params = useMemo(
    () => ({
      date_from: dateFrom || undefined,
      date_to: dateTo || undefined,
      project_id: projectId ? Number(projectId) : undefined,
      department_id: departmentId ? Number(departmentId) : undefined,
      assignee_id: assigneeId ? Number(assigneeId) : undefined,
      workflow_status_id: statusId ? Number(statusId) : undefined,
      overdue_only: overdueOnly || undefined,
    }),
    [
      assigneeId,
      dateFrom,
      dateTo,
      departmentId,
      overdueOnly,
      projectId,
      statusId,
    ],
  )

  const { data: rows = [] } = useQuery({
    queryKey: ["reports-tasks", params],
    queryFn: () => trackerApi.reportTasks(params),
  })

  const pagedRows = useMemo(() => {
    const from = (previewPage - 1) * previewPageSize
    return rows.slice(from, from + previewPageSize)
  }, [rows, previewPage, previewPageSize])

  const totalPages = Math.max(1, Math.ceil(rows.length / previewPageSize))

  const tasksByDepartment = useMemo(
    () => aggregateRows(rows, "department_name").slice(0, 12),
    [rows],
  )
  const tasksByProject = useMemo(
    () => aggregateRows(rows, "project_name").slice(0, 12),
    [rows],
  )
  const tasksByStatus = useMemo(() => {
    const map = new Map<string, number>()
    for (const row of rows) {
      const statusName = row.status_name || "Без статуса"
      map.set(statusName, (map.get(statusName) ?? 0) + 1)
    }
    return [...map.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
  }, [rows])

  const tasksByAssignee = useMemo(() => {
    const map = new Map<string, number>()
    for (const row of rows) {
      const assignee = row.assignee_name || "Не назначен"
      map.set(assignee, (map.get(assignee) ?? 0) + 1)
    }
    return [...map.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 12)
  }, [rows])

  const tasksByDeadlineState = useMemo(() => {
    const now = new Date()
    const totals = {
      green: 0,
      yellow: 0,
      red: 0,
    }

    for (const row of rows) {
      if (row.is_overdue) {
        totals.red += 1
        continue
      }

      const due = new Date(row.due_date)
      const diffDays = Math.ceil(
        (due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24),
      )

      if (diffDays <= 2) {
        totals.yellow += 1
      } else {
        totals.green += 1
      }
    }

    return [
      { name: "В срок", count: totals.green, color: "#2E7D32" },
      { name: "Критично", count: totals.yellow, color: "#F9A825" },
      { name: "Просрочено", count: totals.red, color: "#C62828" },
    ]
  }, [rows])

  const downloadReport = async (kind: "csv" | "xlsx") => {
    try {
      setIsDownloading(kind)
      const token = localStorage.getItem("access_token") || ""
      const url =
        kind === "csv"
          ? trackerApi.reportCsvUrl(params)
          : trackerApi.reportXlsxUrl(params)
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      if (!response.ok) {
        const text = await response.text()
        throw new Error(text || `Ошибка экспорта (${response.status})`)
      }
      const blob = await response.blob()
      const objectUrl = URL.createObjectURL(blob)
      const anchor = document.createElement("a")
      anchor.href = objectUrl
      anchor.download =
        kind === "csv" ? "tasks-report.csv" : "tasks-report.xlsx"
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      URL.revokeObjectURL(objectUrl)
      showToast.success("Успешно", `Отчёт ${kind.toUpperCase()} выгружен`)
    } catch (error) {
      showToast.error("Не удалось выгрузить отчёт", error)
    } finally {
      setIsDownloading(null)
    }
  }

  return (
    <Container maxW="full" py={6}>
      <Heading size="lg" mb={5}>
        Отчёты
      </Heading>

      <Grid templateColumns={{ base: "1fr", xl: "330px 1fr" }} gap={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            p={4}
            bg="white"
            position={{ xl: "sticky" }}
            top={4}
            boxShadow="sm"
          >
            <Heading
              size="sm"
              mb={3}
              textTransform="uppercase"
              letterSpacing="0.04em"
            >
              Фильтры
            </Heading>
            <VFilter label="С даты">
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </VFilter>
            <VFilter label="По дату">
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </VFilter>
            <VFilter label="Проект">
              <Select
                value={projectId}
                onChange={(e) => {
                  setProjectId(e.target.value)
                  setStatusId("")
                }}
              >
                <option value="">Все</option>
                {projectsData?.data.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </Select>
            </VFilter>
            <VFilter label="Департамент">
              <Select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
              >
                <option value="">Все</option>
                {departmentsData?.data.map((department) => (
                  <option key={department.id} value={department.id}>
                    {department.name}
                  </option>
                ))}
              </Select>
            </VFilter>
            <VFilter label="Исполнитель">
              <Select
                value={assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
              >
                <option value="">Все</option>
                {usersData?.data.map((user) => (
                  <option key={user.id} value={user.id}>
                    {`${user.full_name || user.email} (#${user.id})`}
                  </option>
                ))}
              </Select>
            </VFilter>
            <VFilter label="Состояние задачи">
              <Select
                value={statusId}
                onChange={(e) => setStatusId(e.target.value)}
                isDisabled={!projectNumber}
              >
                <option value="">Все</option>
                {statusesData?.data.map((status) => (
                  <option key={status.id} value={status.id}>
                    {status.name}
                  </option>
                ))}
              </Select>
            </VFilter>
            <FormControl>
              <FormLabel>Только просроченные</FormLabel>
              <Switch
                isChecked={overdueOnly}
                onChange={(e) => setOverdueOnly(e.target.checked)}
              />
            </FormControl>
            <HStack mt={4}>
              <Button
                onClick={() => downloadReport("csv")}
                isLoading={isDownloading === "csv"}
              >
                CSV
              </Button>
              <Button
                onClick={() => downloadReport("xlsx")}
                isLoading={isDownloading === "xlsx"}
              >
                XLSX
              </Button>
            </HStack>
          </Box>
        </GridItem>

        <GridItem>
          <Grid
            templateColumns={{ base: "1fr", md: "repeat(3, 1fr)" }}
            gap={3}
            mb={4}
          >
            <Stat
              borderWidth="1px"
              borderColor="ui.border"
              borderRadius="12px"
              p={3}
              bg="white"
              boxShadow="sm"
            >
              <StatLabel>Всего задач в выборке</StatLabel>
              <StatNumber>{rows.length}</StatNumber>
            </Stat>
            <Stat
              borderWidth="1px"
              borderColor="ui.border"
              borderRadius="12px"
              p={3}
              bg="white"
              boxShadow="sm"
            >
              <StatLabel>Просроченных</StatLabel>
              <StatNumber>
                {rows.filter((row) => row.is_overdue).length}
              </StatNumber>
            </Stat>
            <Stat
              borderWidth="1px"
              borderColor="ui.border"
              borderRadius="12px"
              p={3}
              bg="white"
              boxShadow="sm"
            >
              <StatLabel>Проектов</StatLabel>
              <StatNumber>
                {new Set(rows.map((row) => row.project_name)).size}
              </StatNumber>
            </Stat>
          </Grid>

          <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
            <ChartPanel title="Задачи по департаментам и срокам">
              <ChartBox>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={300}>
                  <BarChart data={tasksByDepartment}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" hide />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="total"
                      name="Всего"
                      fill="#1E3A5F"
                      radius={[6, 6, 0, 0]}
                    />
                    <Bar
                      dataKey="overdue"
                      name="Просрочено"
                      fill="#C62828"
                      radius={[6, 6, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </ChartBox>
            </ChartPanel>

            <ChartPanel title="Объем задач по проектам">
              <ChartBox>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={300}>
                  <BarChart data={tasksByProject}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" hide />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="total"
                      name="Всего"
                      fill="#2A76D2"
                      radius={[6, 6, 0, 0]}
                    />
                    <Bar
                      dataKey="overdue"
                      name="Просрочено"
                      fill="#F97316"
                      radius={[6, 6, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </ChartBox>
            </ChartPanel>
          </Grid>

          <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
            <ChartPanel title="Распределение задач по состоянию">
              <ChartBox>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={300}>
                  <PieChart>
                    <Tooltip />
                    <Legend />
                    <Pie
                      data={tasksByStatus}
                      dataKey="count"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={102}
                      label
                    >
                      {tasksByStatus.map((entry, index) => (
                        <Cell
                          key={`${entry.name}-${index}`}
                          fill={pieColors[index % pieColors.length]}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </ChartBox>
            </ChartPanel>

            <ChartPanel title="Распределение задач по срокам">
              <ChartBox>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={300}>
                  <PieChart>
                    <Tooltip />
                    <Legend />
                    <Pie
                      data={tasksByDeadlineState}
                      dataKey="count"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={102}
                      label
                    >
                      {tasksByDeadlineState.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </ChartBox>
            </ChartPanel>
          </Grid>

          <Grid templateColumns={{ base: "1fr", xl: "1fr" }} gap={4} mb={4}>
            <ChartPanel title="Распределение задач по исполнителям">
              <ChartBox h="320px">
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={320}>
                  <BarChart
                    data={tasksByAssignee}
                    layout="vertical"
                    margin={{ left: 8 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" allowDecimals={false} />
                    <YAxis type="category" dataKey="name" width={170} />
                    <Tooltip />
                    <Bar
                      dataKey="count"
                      name="Задач"
                      fill="#2F855A"
                      radius={[0, 6, 6, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </ChartBox>
            </ChartPanel>
          </Grid>

          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            overflow="hidden"
            bg="white"
            boxShadow="sm"
          >
            <Box p={3} borderBottomWidth="1px" bg="gray.50">
              <HStack justify="space-between">
                <Text fontWeight="600">Таблица задач (preview)</Text>
                <HStack>
                  <Select
                    size="sm"
                    value={previewPageSize}
                    onChange={(e) => {
                      setPreviewPageSize(Number(e.target.value))
                      setPreviewPage(1)
                    }}
                    w="120px"
                  >
                    {[20, 50, 100].map((size) => (
                      <option key={size} value={size}>
                        {size} / стр.
                      </option>
                    ))}
                  </Select>
                  <Button
                    size="sm"
                    onClick={() => setPreviewPage((p) => Math.max(1, p - 1))}
                  >
                    Назад
                  </Button>
                  <Text fontSize="sm">
                    {previewPage}/{totalPages}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() =>
                      setPreviewPage((p) => Math.min(totalPages, p + 1))
                    }
                  >
                    Вперёд
                  </Button>
                </HStack>
              </HStack>
            </Box>

            <Box overflowX="auto">
              <Table size="sm">
                <Thead>
                  <Tr>
                    <Th>ID</Th>
                    <Th>Задача</Th>
                    <Th>Проект</Th>
                    <Th>Департамент</Th>
                    <Th>Исполнитель</Th>
                    <Th>Состояние</Th>
                    <Th>Срок</Th>
                    <Th>Просрочено</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {pagedRows.map((row) => (
                    <Tr key={`${row.task_id}-${row.due_date}`}>
                      <Td>{row.task_id}</Td>
                      <Td>{row.title}</Td>
                      <Td>{row.project_name}</Td>
                      <Td>{row.department_name || "-"}</Td>
                      <Td>{row.assignee_name || "-"}</Td>
                      <Td>{row.status_name}</Td>
                      <Td>{new Date(row.due_date).toLocaleDateString()}</Td>
                      <Td>{row.is_overdue ? "Да" : "Нет"}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>
          </Box>
        </GridItem>
      </Grid>
    </Container>
  )
}

function VFilter({ label, children }: { label: string; children: ReactNode }) {
  return (
    <FormControl mb={3}>
      <FormLabel>{label}</FormLabel>
      {children}
    </FormControl>
  )
}

function ChartPanel({
  title,
  children,
}: { title: string; children: ReactNode }) {
  return (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="12px"
      p={4}
      bg="white"
      boxShadow="sm"
    >
      <Heading
        size="sm"
        mb={3}
        textTransform="uppercase"
        letterSpacing="0.04em"
      >
        {title}
      </Heading>
      {children}
    </Box>
  )
}

function ChartBox({
  children,
  h = "300px",
}: {
  children: ReactNode
  h?: string
}) {
  return (
    <Box minW={0} w="100%" h={h}>
      {children}
    </Box>
  )
}

function aggregateRows(
  rows: ReportTaskRow[],
  key: "project_name" | "department_name",
): Array<{ name: string; total: number; overdue: number }> {
  const map = new Map<
    string,
    { name: string; total: number; overdue: number }
  >()
  for (const row of rows) {
    const groupName =
      key === "project_name"
        ? row.project_name || "Без проекта"
        : row.department_name || "Без департамента"

    const current = map.get(groupName) ?? {
      name: groupName,
      total: 0,
      overdue: 0,
    }

    current.total += 1
    if (row.is_overdue) {
      current.overdue += 1
    }

    map.set(groupName, current)
  }

  return [...map.values()].sort((a, b) => b.total - a.total)
}

const pieColors = [
  "#1E3A5F",
  "#2E7D32",
  "#F9A825",
  "#C62828",
  "#0D9488",
  "#7C3AED",
  "#6D4C41",
]
