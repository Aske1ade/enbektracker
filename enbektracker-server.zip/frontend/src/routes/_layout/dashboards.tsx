import {
  Badge,
  Box,
  Container,
  Grid,
  GridItem,
  HStack,
  Heading,
  Stat,
  StatHelpText,
  StatLabel,
  StatNumber,
  Text,
} from "@chakra-ui/react"
import { useQuery } from "@tanstack/react-query"
import { createFileRoute } from "@tanstack/react-router"
import { useMemo } from "react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  PolarAngleAxis,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import { trackerApi } from "../../services/trackerApi"

export const Route = createFileRoute("/_layout/dashboards")({
  component: DashboardsPage,
})

function DashboardsPage() {
  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: trackerApi.dashboardSummary,
  })

  const { data: distributions, isLoading: distributionsLoading } = useQuery({
    queryKey: ["dashboard-distributions"],
    queryFn: trackerApi.dashboardDistributions,
  })

  const deadlineInTimeCount =
    (summary?.deadline_in_time_count ?? 0) +
    (summary?.closed_in_time_count ?? 0)
  const overdueCount =
    (summary?.deadline_overdue_count ?? 0) +
    (summary?.closed_overdue_count ?? 0)

  const departmentsBars = distributions?.departments ?? []
  const projectsBars = distributions?.projects ?? []
  const statusPie = useMemo(
    () => (distributions?.statuses ?? []).filter((item) => item.count > 0),
    [distributions?.statuses],
  )

  const topExecutorsPie = useMemo(
    () =>
      (summary?.top_executors ?? [])
        .filter((item) => item.count > 0)
        .slice(0, 5),
    [summary?.top_executors],
  )
  const topOverdueExecutorsPie = useMemo(
    () =>
      (summary?.top_overdue_executors ?? [])
        .filter((item) => item.count > 0)
        .slice(0, 5),
    [summary?.top_overdue_executors],
  )

  const closedPercent = useMemo(() => {
    const total = summary?.total_tasks ?? 0
    const closed =
      (summary?.closed_in_time_count ?? 0) +
      (summary?.closed_overdue_count ?? 0)
    if (!total) return 0
    return Math.round((closed / total) * 100)
  }, [summary])

  const closedInTimePercent = useMemo(() => {
    const closed =
      (summary?.closed_in_time_count ?? 0) +
      (summary?.closed_overdue_count ?? 0)
    if (!closed) return 0
    return Math.round(((summary?.closed_in_time_count ?? 0) / closed) * 100)
  }, [summary])

  return (
    <Container maxW="full" py={6}>
      <Heading size="lg" mb={1}>
        Дашборды
      </Heading>
      <Text color="gray.600" mb={5}>
        Сводка по задачам, распределения и ключевые показатели исполнения
      </Text>

      <Grid
        templateColumns={{ base: "1fr", md: "repeat(3, minmax(0, 1fr))" }}
        gap={4}
        mb={5}
      >
        <MetricCard
          label="Общее количество задач"
          value={summary?.total_tasks ?? 0}
          helpText="По текущему контуру доступа"
          isLoading={summaryLoading}
        />
        <MetricCard
          label="Задачи по сроку"
          value={deadlineInTimeCount}
          helpText="Открытые в срок + закрытые в срок"
          color="#2F855A"
          isLoading={summaryLoading}
        />
        <MetricCard
          label="Просроченные задачи"
          value={overdueCount}
          helpText="Открытые просроченные + закрытые с просрочкой"
          color="#C53030"
          isLoading={summaryLoading}
        />
      </Grid>

      <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
        <GridItem minW={0}>
          <Panel title="Распределение по состоянию задач">
            <ChartBox h="340px">
              {distributionsLoading || !statusPie.length ? (
                <CenterText text="Нет данных по состояниям" />
              ) : (
                <ResponsiveContainer
                  width="100%"
                  height="100%"
                  minWidth={0}
                  minHeight={340}
                  debounce={40}
                >
                  <PieChart>
                    <Tooltip />
                    <Legend />
                    <Pie
                      data={statusPie}
                      dataKey="count"
                      nameKey="status_name"
                      cx="50%"
                      cy="50%"
                      outerRadius={115}
                      label
                    >
                      {statusPie.map((entry, index) => (
                        <Cell
                          key={`${entry.status_code ?? entry.status_name}-${entry.status_id}`}
                          fill={chartColors[index % chartColors.length]}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              )}
            </ChartBox>
          </Panel>
        </GridItem>

        <GridItem minW={0}>
          <Panel title="Индикаторы закрытия">
            <ChartBox h="340px">
              <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={3} h="100%">
                <RadialIndicator
                  label="Закрыто от всех"
                  value={closedPercent}
                  color="#1E3A5F"
                />
                <RadialIndicator
                  label="Закрыто в срок"
                  value={closedInTimePercent}
                  color="#2F855A"
                />
              </Grid>
            </ChartBox>
          </Panel>
        </GridItem>
      </Grid>

      <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
        <GridItem minW={0}>
          <Panel title="Количество задач по департаментам">
            <ChartBox h="320px">
              {!departmentsBars.length ? (
                <CenterText text="Нет данных по департаментам" />
              ) : (
                <ResponsiveContainer
                  width="100%"
                  height="100%"
                  minWidth={0}
                  minHeight={320}
                  debounce={40}
                >
                  <BarChart
                    data={departmentsBars}
                    layout="vertical"
                    margin={{ left: 16, right: 8 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" allowDecimals={false} />
                    <YAxis
                      type="category"
                      dataKey="department_name"
                      width={170}
                    />
                    <Tooltip />
                    <Bar dataKey="count" name="Задач" radius={[0, 6, 6, 0]}>
                      {departmentsBars.map((entry, index) => (
                        <Cell
                          key={`${entry.department_name}-${index}`}
                          fill={chartColors[index % chartColors.length]}
                          cursor="pointer"
                          onClick={() => {
                            if (!entry.department_id) return
                            openTasksWithFilters({
                              departmentId: entry.department_id,
                            })
                          }}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </ChartBox>
          </Panel>
        </GridItem>

        <GridItem minW={0}>
          <Panel title="Объём задач по проектам">
            <ChartBox h="320px">
              {!projectsBars.length ? (
                <CenterText text="Нет данных по проектам" />
              ) : (
                <ResponsiveContainer
                  width="100%"
                  height="100%"
                  minWidth={0}
                  minHeight={320}
                  debounce={40}
                >
                  <BarChart
                    data={projectsBars}
                    layout="vertical"
                    margin={{ left: 16, right: 8 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" allowDecimals={false} />
                    <YAxis type="category" dataKey="project_name" width={170} />
                    <Tooltip />
                    <Bar dataKey="count" name="Задач" radius={[0, 6, 6, 0]}>
                      {projectsBars.map((entry, index) => (
                        <Cell
                          key={`${entry.project_id}-${index}`}
                          fill={chartColors[(index + 2) % chartColors.length]}
                          cursor="pointer"
                          onClick={() => {
                            openTasksWithFilters({
                              projectId: entry.project_id,
                            })
                          }}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </ChartBox>
          </Panel>
        </GridItem>
      </Grid>

      <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
        <GridItem minW={0}>
          <Panel title="ТОП исполнителей (5)">
            <ChartBox h="300px">
              {!topExecutorsPie.length ? (
                <CenterText text="Нет активных исполнителей" />
              ) : (
                <ResponsiveContainer
                  width="100%"
                  height="100%"
                  minWidth={0}
                  minHeight={300}
                  debounce={40}
                >
                  <PieChart>
                    <Tooltip />
                    <Legend />
                    <Pie
                      data={topExecutorsPie}
                      dataKey="count"
                      nameKey="user_name"
                      cx="50%"
                      cy="50%"
                      outerRadius={108}
                      label
                    >
                      {topExecutorsPie.map((entry, index) => (
                        <Cell
                          key={`${entry.user_id}-${index}`}
                          fill={chartColors[index % chartColors.length]}
                          cursor="pointer"
                          onClick={() => {
                            openTasksWithFilters({ assigneeId: entry.user_id })
                          }}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              )}
            </ChartBox>
          </Panel>
        </GridItem>

        <GridItem minW={0}>
          <Panel title="ТОП исполнителей по просроченным задачам (5)">
            <ChartBox h="300px">
              {!topOverdueExecutorsPie.length ? (
                <CenterText text="Просроченных задач нет" />
              ) : (
                <ResponsiveContainer
                  width="100%"
                  height="100%"
                  minWidth={0}
                  minHeight={300}
                  debounce={40}
                >
                  <PieChart>
                    <Tooltip />
                    <Legend />
                    <Pie
                      data={topOverdueExecutorsPie}
                      dataKey="count"
                      nameKey="user_name"
                      cx="50%"
                      cy="50%"
                      outerRadius={108}
                      label
                    >
                      {topOverdueExecutorsPie.map((entry, index) => (
                        <Cell
                          key={`${entry.user_id}-${index}`}
                          fill={chartColors[(index + 3) % chartColors.length]}
                          cursor="pointer"
                          onClick={() => {
                            openTasksWithFilters({
                              assigneeId: entry.user_id,
                              overdueOnly: true,
                            })
                          }}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              )}
            </ChartBox>
          </Panel>
        </GridItem>
      </Grid>

      <HStack mt={4} spacing={2}>
        <Badge bg="#E6F5EA" color="#1C6B35" borderRadius="full">
          По сроку: {deadlineInTimeCount}
        </Badge>
        <Badge bg="#FDE7E7" color="#A61B1B" borderRadius="full">
          Просроченные: {overdueCount}
        </Badge>
      </HStack>
    </Container>
  )
}

function MetricCard({
  label,
  value,
  helpText,
  color,
  isLoading,
}: {
  label: string
  value: number
  helpText: string
  color?: string
  isLoading: boolean
}) {
  return (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="10px"
      p={4}
      bg="white"
      boxShadow="sm"
    >
      <Stat>
        <StatLabel>{label}</StatLabel>
        <StatNumber>{isLoading ? "..." : value}</StatNumber>
        <StatHelpText>{helpText}</StatHelpText>
      </Stat>
      {color ? <Box mt={2} h="4px" borderRadius="sm" bg={color} /> : null}
    </Box>
  )
}

function Panel({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <Box
      borderWidth="1px"
      borderColor="ui.border"
      borderRadius="10px"
      p={4}
      bg="white"
      boxShadow="sm"
    >
      <Heading
        size="sm"
        mb={3}
        textTransform="uppercase"
        letterSpacing="0.04em"
      >
        {title}
      </Heading>
      {children}
    </Box>
  )
}

function ChartBox({ h, children }: { h: string; children: React.ReactNode }) {
  return (
    <Box minW={0} minH={h} w="100%" h={h}>
      {children}
    </Box>
  )
}

function CenterText({ text }: { text: string }) {
  return (
    <Box h="100%" display="flex" alignItems="center" justifyContent="center">
      <Text color="ui.muted">{text}</Text>
    </Box>
  )
}

const chartColors = [
  "#1E3A5F",
  "#2E7D32",
  "#F9A825",
  "#C62828",
  "#0D9488",
  "#6D4C41",
  "#7C3AED",
]

function RadialIndicator({
  label,
  value,
  color,
}: {
  label: string
  value: number
  color: string
}) {
  return (
    <Box position="relative" h="100%">
      <ResponsiveContainer
        width="100%"
        height="100%"
        minWidth={0}
        minHeight={220}
        debounce={40}
      >
        <RadialBarChart
          cx="50%"
          cy="50%"
          innerRadius="60%"
          outerRadius="92%"
          barSize={16}
          data={[{ name: label, value }]}
          startAngle={90}
          endAngle={-270}
        >
          <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
          <RadialBar dataKey="value" fill={color} cornerRadius={8} />
        </RadialBarChart>
      </ResponsiveContainer>
      <Box
        position="absolute"
        inset={0}
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        pointerEvents="none"
      >
        <Text fontSize="2xl" fontWeight="700" lineHeight="1">
          {value}%
        </Text>
        <Text fontSize="xs" color="gray.600" mt={1} textAlign="center">
          {label}
        </Text>
      </Box>
    </Box>
  )
}

function openTasksWithFilters(params: {
  projectId?: number
  departmentId?: number
  assigneeId?: number
  overdueOnly?: boolean
}) {
  const query = new URLSearchParams()
  query.set("from", "dashboard")
  if (params.projectId) query.set("projectId", String(params.projectId))
  if (params.departmentId)
    query.set("departmentId", String(params.departmentId))
  if (params.assigneeId) query.set("assigneeId", String(params.assigneeId))
  if (params.overdueOnly) query.set("overdueOnly", "true")
  const search = query.toString()
  window.location.assign(`/tasks${search ? `?${search}` : ""}`)
}
