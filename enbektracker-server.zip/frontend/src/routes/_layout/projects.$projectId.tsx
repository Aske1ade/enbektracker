import {
  Badge,
  Box,
  Button,
  Checkbox,
  CheckboxGroup,
  Container,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  DrawerOverlay,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Heading,
  Input,
  NumberInput,
  NumberInputField,
  Select,
  Spinner,
  Switch,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  VStack,
  useDisclosure,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { Link, createFileRoute } from "@tanstack/react-router"
import { useEffect, useMemo, useState } from "react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"
import type { CalendarDayTask, CalendarViewBucket } from "../../types/tracker"

export const Route = createFileRoute("/_layout/projects/$projectId")({
  component: ProjectDetailPage,
})

function ProjectDetailPage() {
  const { projectId } = Route.useParams()
  const projectNumber = Number(projectId)
  const queryClient = useQueryClient()
  const showToast = useCustomToast()
  const dayDrawer = useDisclosure()

  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: ["project", projectNumber],
    queryFn: () => trackerApi.getProject(projectNumber),
  })

  const { data: statusesData, isLoading: statusesLoading } = useQuery({
    queryKey: ["project-statuses", projectNumber],
    queryFn: () => trackerApi.getProjectStatuses(projectNumber),
  })

  const { data: membersData, isLoading: membersLoading } = useQuery({
    queryKey: ["project-members", projectNumber],
    queryFn: () => trackerApi.listProjectMembers(projectNumber),
  })

  const { data: accessGroupsData, isLoading: accessGroupsLoading } = useQuery({
    queryKey: ["project-access-groups", projectNumber],
    queryFn: () => trackerApi.getProjectAccessGroups(projectNumber),
  })

  const { data: projectDepartmentsData, isLoading: projectDepartmentsLoading } =
    useQuery({
      queryKey: ["project-departments", projectNumber],
      queryFn: () => trackerApi.getProjectDepartments(projectNumber),
    })

  const { data: departmentsData, isLoading: departmentsLoading } = useQuery({
    queryKey: ["departments-for-project-card"],
    queryFn: () => trackerApi.listDepartments(),
  })

  const { data: blocksData, isLoading: blocksLoading } = useQuery({
    queryKey: ["blocks-for-project-card"],
    queryFn: () => trackerApi.listBlocks(),
    retry: false,
  })

  const [policyForm, setPolicyForm] = useState({
    name: "",
    description: "",
    require_close_comment: false,
    require_close_attachment: false,
    deadline_yellow_days: 3,
    deadline_normal_days: 5,
  })
  const [selectedDepartmentIds, setSelectedDepartmentIds] = useState<number[]>(
    [],
  )
  const [selectedBlockId, setSelectedBlockId] = useState("")
  const [calendarMode, setCalendarMode] = useState<"day" | "week" | "month">(
    "month",
  )
  const [calendarDate, setCalendarDate] = useState(() =>
    new Date().toISOString().slice(0, 10),
  )
  const [selectedDay, setSelectedDay] = useState<string | null>(null)

  useEffect(() => {
    if (!project) return
    setPolicyForm({
      name: project.name,
      description: project.description || "",
      require_close_comment: project.require_close_comment,
      require_close_attachment: project.require_close_attachment,
      deadline_yellow_days: project.deadline_yellow_days,
      deadline_normal_days: project.deadline_normal_days,
    })
    setSelectedBlockId(project.block_id ? String(project.block_id) : "")
  }, [project])

  useEffect(() => {
    if (!projectDepartmentsData?.data) return
    setSelectedDepartmentIds(
      projectDepartmentsData.data.map((item) => item.department_id),
    )
  }, [projectDepartmentsData?.data])

  const updateProjectMutation = useMutation({
    mutationFn: () =>
      trackerApi.updateProject(projectNumber, {
        name: policyForm.name,
        description: policyForm.description || null,
        require_close_comment: policyForm.require_close_comment,
        require_close_attachment: policyForm.require_close_attachment,
        deadline_yellow_days: policyForm.deadline_yellow_days,
        deadline_normal_days: policyForm.deadline_normal_days,
      }),
    onSuccess: () => {
      showToast.success("Успешно", "Настройки проекта обновлены")
      queryClient.invalidateQueries({ queryKey: ["project", projectNumber] })
      queryClient.invalidateQueries({ queryKey: ["projects"] })
    },
    onError: (error) =>
      showToast.error("Не удалось обновить настройки проекта", error),
  })

  const updateDepartmentsMutation = useMutation({
    mutationFn: () =>
      trackerApi.replaceProjectDepartments(
        projectNumber,
        selectedDepartmentIds,
      ),
    onSuccess: () => {
      showToast.success("Успешно", "Департаменты проекта обновлены")
      queryClient.invalidateQueries({
        queryKey: ["project-departments", projectNumber],
      })
      queryClient.invalidateQueries({ queryKey: ["project", projectNumber] })
      queryClient.invalidateQueries({ queryKey: ["projects"] })
    },
    onError: (error) =>
      showToast.error("Не удалось обновить департаменты проекта", error),
  })

  const updateBlockMutation = useMutation({
    mutationFn: () =>
      trackerApi.updateProject(projectNumber, {
        block_id: selectedBlockId ? Number(selectedBlockId) : null,
      }),
    onSuccess: () => {
      showToast.success("Успешно", "Блок проекта обновлён")
      queryClient.invalidateQueries({ queryKey: ["project", projectNumber] })
      queryClient.invalidateQueries({ queryKey: ["projects"] })
    },
    onError: (error) =>
      showToast.error("Не удалось обновить блок проекта", error),
  })

  const { data: projectCalendar, isLoading: projectCalendarLoading } = useQuery({
    queryKey: [
      "project-wall-calendar",
      projectNumber,
      calendarMode,
      calendarDate,
    ],
    queryFn: () =>
      trackerApi.calendarView({
        date: calendarDate,
        mode: calendarMode,
        scope: "project",
        project_id: projectNumber,
      }),
  })

  const participantLoad = useMemo(() => {
    const counts = new Map<string, number>()
    for (const bucket of projectCalendar?.data ?? []) {
      for (const task of bucket.tasks) {
        const name = task.assignee_name || "Не назначен"
        counts.set(name, (counts.get(name) ?? 0) + 1)
      }
    }
    return [...counts.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 12)
  }, [projectCalendar?.data])

  const bucketsByDay = useMemo(() => {
    const map = new Map<string, CalendarViewBucket>()
    for (const bucket of projectCalendar?.data ?? []) {
      map.set(String(bucket.day).slice(0, 10), bucket)
    }
    return map
  }, [projectCalendar?.data])

  const selectedBucket = selectedDay ? bucketsByDay.get(selectedDay) : undefined
  const dayTabs = useMemo(
    () =>
      (projectCalendar?.data ?? [])
        .map((bucket) => String(bucket.day).slice(0, 10))
        .sort((a, b) => a.localeCompare(b)),
    [projectCalendar?.data],
  )

  const calendarTotals = useMemo(() => {
    const buckets = projectCalendar?.data ?? []
    let total = 0
    let overdue = 0
    let closed = 0
    for (const bucket of buckets) {
      total += bucket.total_count
      overdue += bucket.overdue_count
      closed += bucket.closed_count
    }
    return { total, overdue, closed, active: Math.max(0, total - closed) }
  }, [projectCalendar?.data])

  const anchorDate = useMemo(
    () => new Date(`${calendarDate}T00:00:00`),
    [calendarDate],
  )
  const monthStart = useMemo(
    () => new Date(anchorDate.getFullYear(), anchorDate.getMonth(), 1),
    [anchorDate],
  )
  const monthEnd = useMemo(
    () => new Date(anchorDate.getFullYear(), anchorDate.getMonth() + 1, 0),
    [anchorDate],
  )
  const gridStart = useMemo(() => startOfWeekMonday(monthStart), [monthStart])
  const gridEnd = useMemo(() => endOfWeekSunday(monthEnd), [monthEnd])
  const gridDays = useMemo(() => {
    const days: Date[] = []
    const current = new Date(gridStart)
    while (current <= gridEnd) {
      days.push(new Date(current))
      current.setDate(current.getDate() + 1)
    }
    return days
  }, [gridStart, gridEnd])

  const calendarHeaderLabel = useMemo(() => {
    if (calendarMode === "day") {
      return anchorDate.toLocaleDateString("ru-RU", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      })
    }
    if (calendarMode === "week") {
      const from = projectCalendar?.date_from
      const to = projectCalendar?.date_to
      if (!from || !to) return "Неделя"
      return `${new Date(from).toLocaleDateString("ru-RU")} - ${new Date(
        to,
      ).toLocaleDateString("ru-RU")}`
    }
    return capitalize(
      anchorDate.toLocaleDateString("ru-RU", {
        month: "long",
        year: "numeric",
      }),
    )
  }, [anchorDate, calendarMode, projectCalendar?.date_from, projectCalendar?.date_to])

  return (
    <Container maxW="full" py={6}>
      <Box
        mb={5}
        borderWidth="1px"
        borderColor="#154A77"
        borderRadius="16px"
        px={{ base: 4, md: 6 }}
        py={{ base: 4, md: 5 }}
        bg="linear-gradient(120deg, #12385C 0%, #1D5D91 100%)"
        color="white"
        boxShadow="lg"
      >
        <HStack justify="space-between" align="start" flexWrap="wrap" gap={4}>
          <Box>
            <Text fontSize="xs" textTransform="uppercase" letterSpacing="0.08em" color="whiteAlpha.800">
              Проектная стена
            </Text>
            <Heading size="lg" mt={1}>
              {project?.name || `Проект #${projectId}`}
            </Heading>
            <Text mt={2} color="whiteAlpha.900" maxW="820px">
              {project?.description || "Описание проекта не заполнено"}
            </Text>
            <HStack mt={3} spacing={2} flexWrap="wrap">
              <Badge borderRadius="full" colorScheme="blue">
                ID: {projectId}
              </Badge>
              <Badge borderRadius="full" colorScheme="cyan">
                {project?.organization_name || "Без организации"}
              </Badge>
              <Badge borderRadius="full" colorScheme="purple">
                {project?.block_name || "Без группы"}
              </Badge>
            </HStack>
          </Box>
          <Grid templateColumns="repeat(2, minmax(0, 1fr))" gap={2} minW="260px">
            <Box bg="whiteAlpha.180" borderRadius="12px" px={3} py={2}>
              <Text fontSize="xs" color="whiteAlpha.800">
                Участники
              </Text>
              <Text fontSize="xl" fontWeight="700">
                {membersData?.count ?? 0}
              </Text>
            </Box>
            <Box bg="whiteAlpha.180" borderRadius="12px" px={3} py={2}>
              <Text fontSize="xs" color="whiteAlpha.800">
                Команды
              </Text>
              <Text fontSize="xl" fontWeight="700">
                {accessGroupsData?.count ?? 0}
              </Text>
            </Box>
            <Box bg="whiteAlpha.180" borderRadius="12px" px={3} py={2}>
              <Text fontSize="xs" color="whiteAlpha.800">
                Задач в периоде
              </Text>
              <Text fontSize="xl" fontWeight="700">
                {calendarTotals.total}
              </Text>
            </Box>
            <Box bg="whiteAlpha.180" borderRadius="12px" px={3} py={2}>
              <Text fontSize="xs" color="whiteAlpha.800">
                Просроченные
              </Text>
              <Text fontSize="xl" fontWeight="700">
                {calendarTotals.overdue}
              </Text>
            </Box>
          </Grid>
        </HStack>
      </Box>

      {projectLoading ? (
        <Spinner />
      ) : (
        <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
          <GridItem>
            <Box
              borderWidth="1px"
              borderColor="ui.border"
              borderRadius="md"
              p={4}
              bg="white"
            >
              <Text fontSize="xs" color="ui.muted" mb={1}>
                НАЗВАНИЕ
              </Text>
              <Text fontSize="lg" fontWeight="700">
                {project?.name || "-"}
              </Text>
              <Text mt={3} color="gray.700" fontSize="sm">
                {project?.description || "Описание не заполнено"}
              </Text>
            </Box>
          </GridItem>
          <GridItem>
            <Box
              borderWidth="1px"
              borderColor="ui.border"
              borderRadius="md"
              p={4}
              bg="white"
            >
              <Text fontSize="xs" color="ui.muted" mb={2}>
                УПРАВЛЕНИЕ ПОЛИТИКАМИ
              </Text>
              <Grid templateColumns="1fr 1fr" gap={3}>
                <GridItem colSpan={2}>
                  <FormControl>
                    <FormLabel>Название проекта</FormLabel>
                    <Input
                      value={policyForm.name}
                      onChange={(e) =>
                        setPolicyForm((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                    />
                  </FormControl>
                </GridItem>
                <GridItem colSpan={2}>
                  <FormControl>
                    <FormLabel>Описание</FormLabel>
                    <Input
                      value={policyForm.description}
                      onChange={(e) =>
                        setPolicyForm((prev) => ({
                          ...prev,
                          description: e.target.value,
                        }))
                      }
                    />
                  </FormControl>
                </GridItem>
                <Box>
                  <FormControl display="flex" justifyContent="space-between">
                    <FormLabel m={0}>Комментарий обязателен</FormLabel>
                    <Switch
                      isChecked={policyForm.require_close_comment}
                      onChange={(e) =>
                        setPolicyForm((prev) => ({
                          ...prev,
                          require_close_comment: e.target.checked,
                        }))
                      }
                    />
                  </FormControl>
                </Box>
                <Box>
                  <FormControl display="flex" justifyContent="space-between">
                    <FormLabel m={0}>Вложение обязательно</FormLabel>
                    <Switch
                      isChecked={policyForm.require_close_attachment}
                      onChange={(e) =>
                        setPolicyForm((prev) => ({
                          ...prev,
                          require_close_attachment: e.target.checked,
                        }))
                      }
                    />
                  </FormControl>
                </Box>
                <FormControl>
                  <FormLabel>Жёлтый порог (дн.)</FormLabel>
                  <NumberInput
                    min={1}
                    value={policyForm.deadline_yellow_days}
                    onChange={(_, value) =>
                      setPolicyForm((prev) => ({
                        ...prev,
                        deadline_yellow_days: Number.isNaN(value) ? 1 : value,
                      }))
                    }
                  >
                    <NumberInputField />
                  </NumberInput>
                </FormControl>
                <FormControl>
                  <FormLabel>Зелёный порог (дн.)</FormLabel>
                  <NumberInput
                    min={2}
                    value={policyForm.deadline_normal_days}
                    onChange={(_, value) =>
                      setPolicyForm((prev) => ({
                        ...prev,
                        deadline_normal_days: Number.isNaN(value) ? 2 : value,
                      }))
                    }
                  >
                    <NumberInputField />
                  </NumberInput>
                </FormControl>
              </Grid>
              <HStack mt={3} justify="space-between">
                <HStack>
                  <Badge
                    borderRadius="sm"
                    colorScheme={
                      policyForm.require_close_comment ? "red" : "green"
                    }
                  >
                    Комментарий{" "}
                    {policyForm.require_close_comment
                      ? "обязателен"
                      : "опционален"}
                  </Badge>
                  <Badge
                    borderRadius="sm"
                    colorScheme={
                      policyForm.require_close_attachment ? "red" : "green"
                    }
                  >
                    Вложение{" "}
                    {policyForm.require_close_attachment
                      ? "обязательно"
                      : "опционально"}
                  </Badge>
                </HStack>
                <Button
                  size="sm"
                  onClick={() => updateProjectMutation.mutate()}
                  isLoading={updateProjectMutation.isPending}
                >
                  Сохранить
                </Button>
              </HStack>
            </Box>
          </GridItem>
        </Grid>
      )}

      <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4} mb={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            p={4}
            bg="white"
          >
            <Text fontWeight="700" mb={3}>
              Департаменты проекта
            </Text>
            {departmentsLoading || projectDepartmentsLoading ? (
              <Spinner />
            ) : (
              <>
                <CheckboxGroup
                  value={selectedDepartmentIds.map(String)}
                  onChange={(values) =>
                    setSelectedDepartmentIds(
                      values.map((value) => Number(value)),
                    )
                  }
                >
                  <Grid
                    templateColumns={{ base: "1fr", lg: "1fr 1fr" }}
                    gap={2}
                  >
                    {(departmentsData?.data ?? []).map((department) => (
                      <Checkbox
                        key={department.id}
                        value={String(department.id)}
                      >
                        {department.name}
                      </Checkbox>
                    ))}
                  </Grid>
                </CheckboxGroup>
                <HStack mt={3} justify="space-between">
                  <Text color="ui.muted" fontSize="sm">
                    Выбрано: {selectedDepartmentIds.length}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => updateDepartmentsMutation.mutate()}
                    isLoading={updateDepartmentsMutation.isPending}
                  >
                    Сохранить департаменты
                  </Button>
                </HStack>
              </>
            )}
          </Box>
        </GridItem>

        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            p={4}
            bg="white"
          >
            <Text fontWeight="700" mb={3}>
              Привязка к блоку
            </Text>
            {blocksLoading ? (
              <Spinner />
            ) : (
              <>
                <FormControl>
                  <FormLabel>Блок</FormLabel>
                  <Select
                    value={selectedBlockId}
                    onChange={(e) => setSelectedBlockId(e.target.value)}
                  >
                    <option value="">Без блока</option>
                    {(blocksData?.data ?? []).map((block) => (
                      <option key={block.id} value={block.id}>
                        {block.name}
                      </option>
                    ))}
                  </Select>
                </FormControl>
                <HStack mt={3} justify="space-between">
                  <Text color="ui.muted" fontSize="sm">
                    Текущий блок: {project?.block_name || "не задан"}
                  </Text>
                  <Button
                    size="sm"
                    onClick={() => updateBlockMutation.mutate()}
                    isLoading={updateBlockMutation.isPending}
                  >
                    Сохранить блок
                  </Button>
                </HStack>
              </>
            )}
          </Box>
        </GridItem>
      </Grid>

      <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            overflow="hidden"
            bg="white"
          >
            <Box px={4} py={3} borderBottomWidth="1px" borderColor="ui.border">
              <Text fontWeight="700">Участники проекта</Text>
            </Box>
            {membersLoading ? (
              <Spinner m={4} />
            ) : (
              <Table size="sm">
                <Thead>
                  <Tr>
                    <Th>Пользователь</Th>
                    <Th>Email</Th>
                    <Th>Роль</Th>
                    <Th>Статус</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {(membersData?.data ?? []).map((member) => (
                    <Tr key={member.id}>
                      <Td>
                        {member.user_name || `Пользователь #${member.user_id}`}
                      </Td>
                      <Td>{member.user_email || "-"}</Td>
                      <Td>{projectMemberRoleLabel(member.role)}</Td>
                      <Td>
                        <Badge
                          borderRadius="sm"
                          colorScheme={member.is_active ? "green" : "gray"}
                        >
                          {member.is_active ? "Активен" : "Отключён"}
                        </Badge>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </Box>
        </GridItem>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            overflow="hidden"
            bg="white"
          >
            <Box px={4} py={3} borderBottomWidth="1px" borderColor="ui.border">
              <Text fontWeight="700">Workflow-статусы</Text>
            </Box>
            {statusesLoading ? (
              <Spinner m={4} />
            ) : (
              <Table size="sm">
                <Thead>
                  <Tr>
                    <Th>Порядок</Th>
                    <Th>Название</Th>
                    <Th>Код</Th>
                    <Th>Тип</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {(statusesData?.data ?? []).map((status) => (
                    <Tr key={status.id}>
                      <Td>{status.order}</Td>
                      <Td>{status.name}</Td>
                      <Td>{status.code || "-"}</Td>
                      <Td>
                        <Badge
                          borderRadius="sm"
                          colorScheme={status.is_final ? "purple" : "blue"}
                        >
                          {status.is_final ? "Финальный" : "Рабочий"}
                        </Badge>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </Box>
        </GridItem>
      </Grid>

      <Grid templateColumns="1fr" gap={4} mt={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            overflow="hidden"
            bg="white"
          >
            <Box px={4} py={3} borderBottomWidth="1px" borderColor="ui.border">
              <Text fontWeight="700">Команды/группы проекта</Text>
            </Box>
            {accessGroupsLoading ? (
              <Spinner m={4} />
            ) : (
              <Table size="sm">
                <Thead>
                  <Tr>
                    <Th>Группа</Th>
                    <Th>Организация</Th>
                    <Th>Роль</Th>
                    <Th>Статус</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {(accessGroupsData?.data ?? []).map((group) => (
                    <Tr key={`${group.group_id}-${group.role_key}`}>
                      <Td>{group.group_name || `Группа #${group.group_id}`}</Td>
                      <Td>{group.organization_id ? `#${group.organization_id}` : "-"}</Td>
                      <Td>{group.role_title}</Td>
                      <Td>
                        <Badge
                          borderRadius="sm"
                          colorScheme={group.is_active ? "green" : "gray"}
                        >
                          {group.is_active ? "Активен" : "Отключён"}
                        </Badge>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            )}
          </Box>
        </GridItem>
      </Grid>

      <Grid templateColumns={{ base: "1fr", md: "repeat(4, 1fr)" }} gap={3} mt={4}>
        <Box borderWidth="1px" borderColor="ui.border" borderRadius="md" p={3} bg="white">
          <Text fontSize="xs" color="ui.muted">ЗАДАЧ В ПЕРИОДЕ</Text>
          <Text fontSize="2xl" fontWeight="700">{calendarTotals.total}</Text>
        </Box>
        <Box borderWidth="1px" borderColor="ui.border" borderRadius="md" p={3} bg="white">
          <Text fontSize="xs" color="ui.muted">АКТИВНЫЕ</Text>
          <Text fontSize="2xl" fontWeight="700">{calendarTotals.active}</Text>
        </Box>
        <Box borderWidth="1px" borderColor="ui.border" borderRadius="md" p={3} bg="white">
          <Text fontSize="xs" color="ui.muted">ПРОСРОЧЕННЫЕ</Text>
          <Text fontSize="2xl" fontWeight="700" color="#B42318">
            {calendarTotals.overdue}
          </Text>
        </Box>
        <Box borderWidth="1px" borderColor="ui.border" borderRadius="md" p={3} bg="white">
          <Text fontSize="xs" color="ui.muted">ЗАКРЫТЫЕ</Text>
          <Text fontSize="2xl" fontWeight="700">{calendarTotals.closed}</Text>
        </Box>
      </Grid>

      <Grid templateColumns={{ base: "1fr", xl: "1.35fr 1fr" }} gap={4} mt={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            p={4}
            bg="white"
          >
            <HStack justify="space-between" mb={3} flexWrap="wrap" gap={2}>
              <Text fontWeight="700">Календарь проекта</Text>
              <HStack>
                <Button
                  size="xs"
                  onClick={() =>
                    setCalendarDate((prev) =>
                      shiftCalendarDate(prev, calendarMode, -1),
                    )
                  }
                >
                  ←
                </Button>
                <Text minW="220px" textAlign="center" fontWeight="700" fontSize="sm">
                  {calendarHeaderLabel}
                </Text>
                <Button
                  size="xs"
                  onClick={() =>
                    setCalendarDate((prev) =>
                      shiftCalendarDate(prev, calendarMode, 1),
                    )
                  }
                >
                  →
                </Button>
                <Select
                  size="sm"
                  value={calendarMode}
                  onChange={(event) =>
                    setCalendarMode(event.target.value as "day" | "week" | "month")
                  }
                  w="120px"
                >
                  <option value="day">День</option>
                  <option value="week">Неделя</option>
                  <option value="month">Месяц</option>
                </Select>
                <Input
                  size="sm"
                  type="date"
                  value={calendarDate}
                  onChange={(event) => setCalendarDate(event.target.value)}
                  w="150px"
                />
              </HStack>
            </HStack>

            {projectCalendarLoading ? (
              <Spinner />
            ) : calendarMode === "month" ? (
              <Box
                borderWidth="1px"
                borderColor="ui.border"
                borderRadius="md"
                overflow="hidden"
              >
                <Grid templateColumns="repeat(7, minmax(0, 1fr))" borderBottomWidth="1px" borderColor="ui.border">
                  {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((dayName) => (
                    <Box
                      key={dayName}
                      p={2}
                      borderRightWidth="1px"
                      borderColor="ui.border"
                      fontSize="12px"
                      textTransform="uppercase"
                      fontWeight="700"
                      color="ui.muted"
                    >
                      {dayName}
                    </Box>
                  ))}
                </Grid>
                <Grid templateColumns="repeat(7, minmax(0, 1fr))">
                  {gridDays.map((day, index) => {
                    const dayKey = toYmd(day)
                    const bucket = bucketsByDay.get(dayKey)
                    const inCurrentMonth = day.getMonth() === anchorDate.getMonth()
                    const preview = bucket?.tasks.slice(0, 4) ?? []
                    const totalCount = bucket?.total_count ?? 0
                    return (
                      <Box
                        key={`${dayKey}-${index}`}
                        minH="148px"
                        borderRightWidth={(index + 1) % 7 === 0 ? "0" : "1px"}
                        borderBottomWidth="1px"
                        borderColor="ui.border"
                        p={2}
                        bg={calendarCellColor(bucket)}
                        opacity={inCurrentMonth ? 1 : 0.42}
                        cursor={totalCount > 0 ? "pointer" : "default"}
                        onClick={() => {
                          if (!totalCount) return
                          setSelectedDay(dayKey)
                          dayDrawer.onOpen()
                        }}
                      >
                        <Text fontSize="sm" fontWeight="700" mb={1}>
                          {day.getDate()}
                        </Text>
                        {preview.map((task) => (
                          <Text
                            key={task.id}
                            as={task.closed_at ? "s" : undefined}
                            fontSize="xs"
                            color={projectTaskColor(task)}
                            noOfLines={1}
                          >
                            {task.title}
                          </Text>
                        ))}
                        {totalCount > preview.length ? (
                          <Text
                            fontSize="xs"
                            color="ui.muted"
                            mt={1}
                            textDecoration="underline"
                            onClick={(event) => {
                              event.stopPropagation()
                              setCalendarDate(dayKey)
                              setCalendarMode("day")
                            }}
                          >
                            +{totalCount - preview.length} задач
                          </Text>
                        ) : null}
                      </Box>
                    )
                  })}
                </Grid>
              </Box>
            ) : (
              <Table size="sm">
                <Thead>
                  <Tr>
                    <Th>Дата</Th>
                    <Th>Всего</Th>
                    <Th>Проср.</Th>
                    <Th>Закрыто</Th>
                    <Th>Задачи</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {(projectCalendar?.data ?? []).map((bucket) => {
                    const dayKey = String(bucket.day).slice(0, 10)
                    return (
                      <Tr key={dayKey}>
                        <Td>{new Date(dayKey).toLocaleDateString("ru-RU")}</Td>
                        <Td>{bucket.total_count}</Td>
                        <Td>{bucket.overdue_count}</Td>
                        <Td>{bucket.closed_count}</Td>
                        <Td>
                          {bucket.tasks.map((task) => (
                            <Text
                              key={task.id}
                              as={task.closed_at ? "s" : undefined}
                              fontSize="xs"
                              color={projectTaskColor(task)}
                              noOfLines={1}
                            >
                              <Link
                                to="/tasks/$taskId"
                                params={{ taskId: String(task.id) }}
                                onClick={() => dayDrawer.onClose()}
                              >
                                {task.title}
                              </Link>
                            </Text>
                          ))}
                          {!bucket.tasks.length ? (
                            <Text fontSize="xs" color="ui.muted">
                              Нет задач
                            </Text>
                          ) : null}
                        </Td>
                      </Tr>
                    )
                  })}
                </Tbody>
              </Table>
            )}
          </Box>
        </GridItem>

        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="md"
            p={4}
            bg="white"
          >
            <Text fontWeight="700" mb={3}>
              Распределение задач по участникам проекта
            </Text>
            <Box h="320px" minH="320px" minW={0} w="100%">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={320} debounce={40}>
                <BarChart data={participantLoad} layout="vertical" margin={{ left: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" allowDecimals={false} />
                  <YAxis type="category" dataKey="name" width={150} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#2F855A" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Box>
          </Box>
        </GridItem>
      </Grid>

      <Drawer isOpen={dayDrawer.isOpen} placement="right" onClose={dayDrawer.onClose} size="xl">
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Задачи проекта на {selectedDay || "-"}</DrawerHeader>
          <DrawerBody>
            {dayTabs.length > 0 && (
              <HStack spacing={2} overflowX="auto" pb={2} mb={3}>
                {dayTabs.map((dayKey) => {
                  const bucket = bucketsByDay.get(dayKey)
                  const isActive = selectedDay === dayKey
                  const formatted = new Date(dayKey).toLocaleDateString("ru-RU", {
                    day: "2-digit",
                    month: "2-digit",
                  })
                  return (
                    <Button
                      key={dayKey}
                      size="sm"
                      variant={isActive ? "primary" : "subtle"}
                      onClick={() => setSelectedDay(dayKey)}
                      whiteSpace="nowrap"
                    >
                      {formatted} ({bucket?.total_count ?? 0})
                    </Button>
                  )
                })}
              </HStack>
            )}

            {!selectedBucket?.total_count && (
              <Text color="ui.muted">Нет задач на выбранный день</Text>
            )}
            {(selectedBucket?.total_count ?? 0) > 0 && (
              <VStack align="stretch" spacing={2}>
                {(selectedBucket?.tasks ?? []).map((task) => (
                  <Box
                    key={task.id}
                    borderWidth="1px"
                    borderColor="ui.border"
                    borderRadius="10px"
                    borderLeftWidth="4px"
                    borderLeftColor={projectTaskAccentColor(task)}
                    bg={projectTaskCardBackground(task)}
                    px={3}
                    py={2.5}
                  >
                    <HStack justify="space-between" align="start" gap={3}>
                      <Box minW={0}>
                        <Text
                          as={task.closed_at ? "s" : undefined}
                          fontWeight="700"
                          noOfLines={1}
                        >
                          <Link
                            to="/tasks/$taskId"
                            params={{ taskId: String(task.id) }}
                            onClick={() => dayDrawer.onClose()}
                          >
                            {task.title}
                          </Link>
                        </Text>
                        <Text fontSize="sm" color="ui.muted" noOfLines={1}>
                          {task.assignee_name || "Без исполнителя"} •{" "}
                          {task.status_name || "Без статуса"}
                        </Text>
                      </Box>
                      <VStack spacing={1} align="end">
                        <Badge
                          borderRadius="full"
                          bg={projectTaskAccentColor(task)}
                          color="white"
                        >
                          {projectTaskDeadlineLabel(task)}
                        </Badge>
                        <Text fontSize="xs" color="ui.darkSlate">
                          {new Date(task.due_date).toLocaleString("ru-RU")}
                        </Text>
                      </VStack>
                    </HStack>
                  </Box>
                ))}
              </VStack>
            )}
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </Container>
  )
}

function projectMemberRoleLabel(role: string): string {
  if (role === "manager") return "Руководитель"
  if (role === "controller") return "Контроллер"
  return "Исполнитель"
}

function shiftCalendarDate(
  rawDate: string,
  mode: "day" | "week" | "month",
  direction: -1 | 1,
): string {
  const value = new Date(rawDate)
  if (mode === "day") {
    value.setDate(value.getDate() + direction)
  } else if (mode === "week") {
    value.setDate(value.getDate() + direction * 7)
  } else {
    value.setMonth(value.getMonth() + direction)
  }
  return value.toISOString().slice(0, 10)
}

function toYmd(value: Date): string {
  const year = value.getFullYear()
  const month = `${value.getMonth() + 1}`.padStart(2, "0")
  const day = `${value.getDate()}`.padStart(2, "0")
  return `${year}-${month}-${day}`
}

function startOfWeekMonday(value: Date): Date {
  const day = new Date(value)
  const dayOfWeek = (day.getDay() + 6) % 7
  day.setDate(day.getDate() - dayOfWeek)
  day.setHours(0, 0, 0, 0)
  return day
}

function endOfWeekSunday(value: Date): Date {
  const day = new Date(value)
  const dayOfWeek = (day.getDay() + 6) % 7
  day.setDate(day.getDate() + (6 - dayOfWeek))
  day.setHours(23, 59, 59, 999)
  return day
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1)
}

function calendarCellColor(bucket?: CalendarViewBucket): string {
  if (!bucket?.total_count) return "#FFFFFF"
  if (bucket.overdue_count > 0) return "#FDECEC"
  return "#F4FBF5"
}

function projectTaskColor(task: {
  closed_at?: string | null
  is_overdue: boolean
  computed_deadline_state: "green" | "yellow" | "red"
  closed_overdue: boolean
}): string {
  if (task.closed_at && task.closed_overdue) return "#C62828"
  if (task.closed_at) return "#6b7280"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#C62828"
  if (task.computed_deadline_state === "yellow") return "#B7791F"
  return "#2F855A"
}

function projectTaskAccentColor(task: CalendarDayTask): string {
  if (task.closed_at && task.closed_overdue) return "#C62828"
  if (task.closed_at) return "#6b7280"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#C62828"
  if (task.computed_deadline_state === "yellow") return "#B7791F"
  return "#2F855A"
}

function projectTaskCardBackground(task: CalendarDayTask): string {
  if (task.closed_at) return "#F7F8FA"
  if (task.is_overdue || task.computed_deadline_state === "red") return "#FFF4F4"
  if (task.computed_deadline_state === "yellow") return "#FFF8E8"
  return "#F3FBF5"
}

function projectTaskDeadlineLabel(task: CalendarDayTask): string {
  if (task.closed_at && task.closed_overdue) return "Закрыта с просрочкой"
  if (task.closed_at) return "Закрыта"
  if (task.is_overdue || task.computed_deadline_state === "red") return "Просрочено"
  if (task.computed_deadline_state === "yellow") return "Срок близко"
  return "В срок"
}
