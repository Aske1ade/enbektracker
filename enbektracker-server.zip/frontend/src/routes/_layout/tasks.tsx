import {
  Badge,
  Box,
  Button,
  Checkbox,
  Collapse,
  Container,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  DrawerOverlay,
  FormControl,
  FormLabel,
  HStack,
  Heading,
  Icon,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
  Switch,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  VStack,
  Spinner,
  useDisclosure,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { Link, Outlet, createFileRoute } from "@tanstack/react-router"
import {
  type ColumnSizingState,
  type SortingState,
  type VisibilityState,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { useEffect, useMemo, useState } from "react"
import { FiAlertCircle, FiCheckCircle, FiClock, FiFilter } from "react-icons/fi"

import { htmlToText } from "../../components/Common/RichTextContent"
import RichTextEditor from "../../components/Common/RichTextEditor"
import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"
import type {
  Project,
  ProjectStatus,
  Task,
  TrackerUser,
} from "../../types/tracker"

export const Route = createFileRoute("/_layout/tasks")({
  component: TasksPage,
})

type TaskFilters = {
  search: string
  projectId?: number
  departmentId?: number
  assigneeId?: number
  statusId?: number
  overdueOnly: boolean
}

type TaskTableSettings = {
  columnVisibility: VisibilityState
  columnSizing: ColumnSizingState
}

type SmartQueryResult = {
  plainSearch?: string
  projectId?: number
  departmentId?: number
  assigneeId?: number
  statusId?: number
  overdueOnly?: boolean
}

const TASK_TABLE_SETTINGS_KEY = "tracker.tasks.table.v3"
const TASK_FILTER_STATE_KEY = "tracker.tasks.filters.v3"

const DEFAULT_FILTERS: TaskFilters = {
  search: "",
  overdueOnly: false,
}

const DEFAULT_SETTINGS: TaskTableSettings = {
  columnVisibility: {
    id: false,
    title: true,
    department_name: true,
    project_name: true,
    assignee_name: true,
    status_name: true,
    deadline_state: true,
    due_date: true,
    updated_at: true,
  },
  columnSizing: {},
}

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return { ...fallback, ...JSON.parse(raw) }
  } catch {
    return fallback
  }
}

function TasksPage() {
  const modal = useDisclosure()
  const taskDrawer = useDisclosure()
  const showToast = useCustomToast()
  const queryClient = useQueryClient()

  const initialSettings = useMemo(
    () => readStorage(TASK_TABLE_SETTINGS_KEY, DEFAULT_SETTINGS),
    [],
  )
  const initialFilters = useMemo(
    () => readStorage(TASK_FILTER_STATE_KEY, DEFAULT_FILTERS),
    [],
  )

  const [filters, setFilters] = useState<TaskFilters>(initialFilters)
  const [sorting, setSorting] = useState<SortingState>([
    { id: "updated_at", desc: true },
  ])
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 20 })
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>(
    initialSettings.columnVisibility,
  )
  const [columnSizing, setColumnSizing] = useState<ColumnSizingState>(
    initialSettings.columnSizing,
  )
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null)

  const { data: projectsData } = useQuery({
    queryKey: ["projects-for-tasks"],
    queryFn: () =>
      trackerApi.listProjects({
        page: 1,
        page_size: 200,
        sort_by: "name",
        sort_order: "asc",
      }),
  })

  const { data: usersData } = useQuery({
    queryKey: ["tracker-users"],
    queryFn: () => trackerApi.listUsers(),
    retry: false,
  })

  const { data: departmentsData } = useQuery({
    queryKey: ["departments-for-tasks"],
    queryFn: () => trackerApi.listDepartments(),
  })

  const { data: filterStatusesData } = useQuery({
    queryKey: ["task-filter-statuses", filters.projectId],
    queryFn: () => trackerApi.getProjectStatuses(filters.projectId as number),
    enabled: Boolean(filters.projectId),
  })

  const smartQuery = useMemo(
    () =>
      parseSmartQuery(filters.search, {
        projects: projectsData?.data ?? [],
        users: usersData?.data ?? [],
        statuses: filterStatusesData?.data ?? [],
        departments: departmentsData?.data ?? [],
      }),
    [
      filters.search,
      projectsData?.data,
      usersData?.data,
      filterStatusesData?.data,
      departmentsData?.data,
    ],
  )

  const queryParams = useMemo(() => {
    const activeSort = sorting[0]
    const sortBy = mapSortField(activeSort?.id || "updated_at")
    return {
      search: smartQuery.plainSearch || undefined,
      project_id: filters.projectId ?? smartQuery.projectId,
      department_id: filters.departmentId ?? smartQuery.departmentId,
      assignee_id: filters.assigneeId ?? smartQuery.assigneeId,
      workflow_status_id: filters.statusId ?? smartQuery.statusId,
      overdue_only:
        filters.overdueOnly || smartQuery.overdueOnly ? true : undefined,
      sort_by: sortBy,
      sort_order: (activeSort?.desc ? "desc" : "asc") as "asc" | "desc",
      page: pagination.pageIndex + 1,
      page_size: pagination.pageSize,
    }
  }, [filters, pagination, smartQuery, sorting])

  const { data: tasksData, isLoading } = useQuery({
    queryKey: ["tasks", queryParams],
    queryFn: () => trackerApi.listTasks(queryParams),
  })

  const [form, setForm] = useState({
    title: "",
    description: "",
    project_id: 0,
    assignee_id: "",
    controller_id: "",
    due_date: "",
    workflow_status_id: 0,
  })
  const [createFiles, setCreateFiles] = useState<File[]>([])

  const { data: selectedTask, isLoading: selectedTaskLoading } = useQuery({
    queryKey: ["task", selectedTaskId],
    queryFn: () => trackerApi.getTask(selectedTaskId as number),
    enabled: selectedTaskId !== null,
  })
  const { data: selectedTaskHistory } = useQuery({
    queryKey: ["task-history", selectedTaskId],
    queryFn: () => trackerApi.taskHistory(selectedTaskId as number),
    enabled: selectedTaskId !== null,
  })
  const { data: selectedTaskComments } = useQuery({
    queryKey: ["task-comments", selectedTaskId],
    queryFn: () => trackerApi.listTaskComments(selectedTaskId as number),
    enabled: selectedTaskId !== null,
  })
  const { data: selectedTaskAttachments } = useQuery({
    queryKey: ["task-attachments", selectedTaskId],
    queryFn: () => trackerApi.listTaskAttachments(selectedTaskId as number),
    enabled: selectedTaskId !== null,
  })

  const selectedProjectId = Number(form.project_id || 0)

  const { data: statusesData } = useQuery({
    queryKey: ["project-statuses", selectedProjectId],
    queryFn: () => trackerApi.getProjectStatuses(selectedProjectId),
    enabled: selectedProjectId > 0,
  })

  const { data: projectMembersData } = useQuery({
    queryKey: ["project-members", selectedProjectId],
    queryFn: () => trackerApi.listProjectMembers(selectedProjectId),
    enabled: selectedProjectId > 0,
  })

  const memberOptions = useMemo(() => {
    const usersById = new Map(
      (usersData?.data ?? []).map((user) => [user.id, user]),
    )
    const members =
      projectMembersData?.data.filter((member) => member.is_active) ?? []
    return members.map((member) => {
      const user = usersById.get(member.user_id)
      const displayName = user
        ? user.full_name || user.email
        : `Пользователь #${member.user_id}`
      return {
        id: member.user_id,
        role: member.role,
        label: `${displayName} (${member.role})`,
      }
    })
  }, [projectMembersData, usersData])

  const createMutation = useMutation({
    mutationFn: async () => {
      const created = await trackerApi.createTask({
        title: form.title,
        description: form.description,
        project_id: Number(form.project_id),
        assignee_id: form.assignee_id ? Number(form.assignee_id) : null,
        controller_id: form.controller_id ? Number(form.controller_id) : null,
        due_date: new Date(form.due_date).toISOString(),
        workflow_status_id: Number(form.workflow_status_id),
      })

      const failedUploads: string[] = []
      for (const file of createFiles) {
        try {
          await trackerApi.uploadAttachment(created.id, file)
        } catch {
          failedUploads.push(file.name)
        }
      }
      return { created, failedUploads }
    },
    onSuccess: ({ failedUploads }) => {
      if (failedUploads.length) {
        showToast.error(
          "Задача создана частично",
          `Не удалось загрузить файлы: ${failedUploads.join(", ")}`,
        )
      } else {
        showToast.success("Успешно", "Задача создана")
      }
      queryClient.invalidateQueries({ queryKey: ["tasks"] })
      modal.onClose()
      setForm({
        title: "",
        description: "",
        project_id: 0,
        assignee_id: "",
        controller_id: "",
        due_date: "",
        workflow_status_id: 0,
      })
      setCreateFiles([])
    },
    onError: (error) => {
      showToast.error("Не удалось создать задачу", error)
    },
  })

  useEffect(() => {
    localStorage.setItem(
      TASK_TABLE_SETTINGS_KEY,
      JSON.stringify({ columnVisibility, columnSizing }),
    )
  }, [columnVisibility, columnSizing])

  useEffect(() => {
    localStorage.setItem(TASK_FILTER_STATE_KEY, JSON.stringify(filters))
  }, [filters])

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const rawTaskId = params.get("taskId")
    if (!rawTaskId) return
    const parsed = Number(rawTaskId)
    if (Number.isNaN(parsed) || parsed <= 0) return
    setSelectedTaskId(parsed)
    taskDrawer.onOpen()
  }, [])

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const source = params.get("from")
    const projectId = params.get("projectId")
    const departmentId = params.get("departmentId")
    const assigneeId = params.get("assigneeId")
    const overdueOnly = params.get("overdueOnly")

    const nextProjectId = parsePositiveInt(projectId)
    const nextDepartmentId = parsePositiveInt(departmentId)
    const nextAssigneeId = parsePositiveInt(assigneeId)
    const nextOverdueOnly =
      overdueOnly === "true" || overdueOnly === "1" || overdueOnly === "да"

    const hasIncomingFilters =
      nextProjectId !== undefined ||
      nextDepartmentId !== undefined ||
      nextAssigneeId !== undefined ||
      nextOverdueOnly

    if (!hasIncomingFilters && source !== "dashboard") return

    setFilters({
      ...DEFAULT_FILTERS,
      projectId: nextProjectId,
      departmentId: nextDepartmentId,
      assigneeId: nextAssigneeId,
      overdueOnly: nextOverdueOnly,
    })
    setPagination((prev) => ({ ...prev, pageIndex: 0 }))
    setShowAdvancedFilters(hasIncomingFilters)
  }, [])

  useEffect(() => {
    const url = new URL(window.location.href)
    if (selectedTaskId) {
      url.searchParams.set("taskId", String(selectedTaskId))
    } else {
      url.searchParams.delete("taskId")
    }
    window.history.replaceState({}, "", url)
  }, [selectedTaskId])

  const columnHelper = createColumnHelper<Task>()
  const columns = useMemo(
    () => [
      columnHelper.accessor("id", {
        id: "id",
        header: "ID",
        size: 70,
        minSize: 60,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("title", {
        id: "title",
        header: "Наименование задачи",
        size: 360,
        minSize: 240,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => (
          <Text fontWeight="700" fontSize="sm" noOfLines={1}>
            {info.row.original.title}
          </Text>
        ),
      }),
      columnHelper.accessor("department_name", {
        id: "department_name",
        header: "Департамент",
        size: 180,
        minSize: 130,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => info.getValue() || "-",
      }),
      columnHelper.accessor("project_name", {
        id: "project_name",
        header: "Проект",
        size: 200,
        minSize: 140,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => info.getValue() || `#${info.row.original.project_id}`,
      }),
      columnHelper.accessor("assignee_name", {
        id: "assignee_name",
        header: "Исполнитель",
        size: 190,
        minSize: 140,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => info.getValue() || "-",
      }),
      columnHelper.accessor("status_name", {
        id: "status_name",
        header: "Состояние задачи",
        size: 155,
        minSize: 125,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => {
          const value =
            info.getValue() || info.row.original.workflow_status_name || "-"
          return <Badge borderRadius="full">{value}</Badge>
        },
      }),
      columnHelper.display({
        id: "deadline_state",
        header: "Состояние по сроку",
        size: 155,
        minSize: 125,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => (
          <Badge
            colorScheme={deadlineBadgeColor(resolveDeadlineState(info.row.original))}
            borderRadius="full"
          >
            {deadlineBadgeLabel(resolveDeadlineState(info.row.original))}
          </Badge>
        ),
      }),
      columnHelper.accessor("due_date", {
        id: "due_date",
        header: "Срок",
        size: 145,
        minSize: 120,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => formatDate(info.getValue()),
      }),
      columnHelper.accessor("updated_at", {
        id: "updated_at",
        header: "Последнее обновление",
        size: 180,
        minSize: 150,
        enableResizing: true,
        enableSorting: true,
        cell: (info) => formatDateTime(info.getValue()),
      }),
    ],
    [columnHelper],
  )

  const table = useReactTable({
    data: tasksData?.data ?? [],
    columns,
    getCoreRowModel: getCoreRowModel(),
    manualSorting: true,
    manualPagination: true,
    pageCount: Math.max(
      1,
      Math.ceil((tasksData?.total ?? 0) / pagination.pageSize),
    ),
    state: {
      sorting,
      pagination,
      columnVisibility,
      columnSizing,
    },
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    onColumnVisibilityChange: setColumnVisibility,
    onColumnSizingChange: setColumnSizing,
    columnResizeMode: "onChange",
    enableColumnResizing: true,
  })

  const totalRows = tasksData?.total ?? 0
  const fromRow =
    totalRows === 0 ? 0 : pagination.pageIndex * pagination.pageSize + 1
  const toRow = Math.min(
    totalRows,
    (pagination.pageIndex + 1) * pagination.pageSize,
  )

  const plainDescription = htmlToText(form.description)
  const closeTaskDrawer = () => {
    const url = new URL(window.location.href)
    url.searchParams.delete("taskId")
    window.history.replaceState({}, "", url)
    setSelectedTaskId(null)
    taskDrawer.onClose()
  }

  const downloadAttachment = async (
    attachmentId: number,
    fallbackFileName: string,
  ) => {
    try {
      const { blob, fileName } = await trackerApi.downloadAttachment(
        attachmentId,
      )
      const objectUrl = URL.createObjectURL(blob)
      const anchor = document.createElement("a")
      anchor.href = objectUrl
      anchor.download = fileName || fallbackFileName || `attachment-${attachmentId}`
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      URL.revokeObjectURL(objectUrl)
    } catch (error) {
      showToast.error("Не удалось скачать вложение", error)
    }
  }

  return (
    <Container maxW="full" py={6}>
      <HStack justify="space-between" mb={4} align="center" flexWrap="wrap">
        <Box>
          <Heading size="lg">Задачи</Heading>
          <Text color="ui.muted" fontSize="sm">
            Умный поиск: project:Название assignee:Имя department:Название
            status:Название overdue:true
          </Text>
        </Box>
        <Button variant="primary" onClick={modal.onOpen}>
          Создать задачу
        </Button>
      </HStack>

      <Box
        borderWidth="1px"
        borderColor="ui.border"
        borderRadius="10px"
        p={4}
        mb={4}
        bg="white"
        boxShadow="sm"
      >
        <HStack spacing={3} align="end" flexWrap="wrap">
          <FormControl flex="1" minW="280px">
            <FormLabel>Поиск</FormLabel>
            <Input
              value={filters.search}
              onChange={(e) => {
                setFilters((prev) => ({ ...prev, search: e.target.value }))
                setPagination((prev) => ({ ...prev, pageIndex: 0 }))
              }}
              placeholder="Поиск по задаче, проекту, исполнителю, департаменту"
            />
          </FormControl>

          <FormControl w={{ base: "100%", md: "170px" }}>
            <FormLabel>Просроченные</FormLabel>
            <Switch
              isChecked={filters.overdueOnly}
              onChange={(e) => {
                setFilters((prev) => ({
                  ...prev,
                  overdueOnly: e.target.checked,
                }))
                setPagination((prev) => ({ ...prev, pageIndex: 0 }))
              }}
            />
          </FormControl>

          <Button
            leftIcon={<FiFilter />}
            variant="subtle"
            onClick={() => setShowAdvancedFilters((s) => !s)}
          >
            Фильтры
          </Button>
        </HStack>

        <Collapse in={showAdvancedFilters} animateOpacity>
          <Box
            mt={4}
            display="grid"
            gridTemplateColumns={{ base: "1fr", md: "1fr 1fr", xl: "1fr 1fr 1fr 1fr" }}
            gap={3}
          >
            <FormControl>
              <FormLabel>Проект</FormLabel>
              <Select
                value={filters.projectId ?? ""}
                onChange={(e) => {
                  setFilters((prev) => ({
                    ...prev,
                    projectId: e.target.value
                      ? Number(e.target.value)
                      : undefined,
                    statusId: undefined,
                  }))
                  setPagination((prev) => ({ ...prev, pageIndex: 0 }))
                }}
              >
                <option value="">Все проекты</option>
                {projectsData?.data.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Департамент</FormLabel>
              <Select
                value={filters.departmentId ?? ""}
                onChange={(e) => {
                  setFilters((prev) => ({
                    ...prev,
                    departmentId: e.target.value
                      ? Number(e.target.value)
                      : undefined,
                  }))
                  setPagination((prev) => ({ ...prev, pageIndex: 0 }))
                }}
              >
                <option value="">Все департаменты</option>
                {departmentsData?.data.map((department) => (
                  <option key={department.id} value={department.id}>
                    {department.name}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Состояние задачи</FormLabel>
              <Select
                value={filters.statusId ?? ""}
                onChange={(e) => {
                  setFilters((prev) => ({
                    ...prev,
                    statusId: e.target.value
                      ? Number(e.target.value)
                      : undefined,
                  }))
                  setPagination((prev) => ({ ...prev, pageIndex: 0 }))
                }}
                isDisabled={!filters.projectId}
              >
                <option value="">Все состояния</option>
                {filterStatusesData?.data.map((status) => (
                  <option key={status.id} value={status.id}>
                    {status.name}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Исполнитель</FormLabel>
              <Select
                value={filters.assigneeId ?? ""}
                onChange={(e) => {
                  setFilters((prev) => ({
                    ...prev,
                    assigneeId: e.target.value
                      ? Number(e.target.value)
                      : undefined,
                  }))
                  setPagination((prev) => ({ ...prev, pageIndex: 0 }))
                }}
              >
                <option value="">Все исполнители</option>
                {usersData?.data.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.full_name || user.email}
                  </option>
                ))}
              </Select>
            </FormControl>
          </Box>

          <HStack mt={3} spacing={2} flexWrap="wrap">
            {table.getAllLeafColumns().map((column) => (
              <Checkbox
                key={column.id}
                isChecked={column.getIsVisible()}
                onChange={column.getToggleVisibilityHandler()}
                size="sm"
              >
                {String(column.columnDef.header)}
              </Checkbox>
            ))}
          </HStack>
        </Collapse>

        <HStack mt={3} spacing={2}>
          <Badge bg="#E6F5EA" color="#1C6B35" borderRadius="full">
            <Icon as={FiCheckCircle} mr={1} /> В срок
          </Badge>
          <Badge bg="#FFF2D6" color="#A46200" borderRadius="full">
            <Icon as={FiClock} mr={1} /> Критично
          </Badge>
          <Badge bg="#FDE7E7" color="#A61B1B" borderRadius="full">
            <Icon as={FiAlertCircle} mr={1} /> Просрочено
          </Badge>
        </HStack>
      </Box>

      <Box
        borderWidth="1px"
        borderColor="ui.border"
        borderRadius="10px"
        overflow="hidden"
        bg="white"
        boxShadow="sm"
      >
        <Box overflowX="auto" maxH="68vh" overflowY="auto" minW={0}>
          <Table size="sm" sx={{ tableLayout: "fixed" }}>
            <Thead>
              {table.getHeaderGroups().map((headerGroup) => (
                <Tr key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    const sorted = header.column.getIsSorted()
                    return (
                      <Th
                        key={header.id}
                        w={`${header.getSize()}px`}
                        minW={`${header.column.columnDef.minSize ?? 80}px`}
                        position="sticky"
                        top={0}
                        bg="ui.secondary"
                        zIndex={2}
                        py="6px"
                        userSelect="none"
                      >
                        <Box
                          display="flex"
                          alignItems="center"
                          justifyContent="space-between"
                          cursor={
                            header.column.getCanSort() ? "pointer" : "default"
                          }
                          onClick={
                            header.column.getCanSort()
                              ? header.column.getToggleSortingHandler()
                              : undefined
                          }
                          gap={1}
                          position="relative"
                        >
                          <Text
                            fontSize="xs"
                            textTransform="uppercase"
                            letterSpacing="0.03em"
                          >
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext(),
                                )}
                          </Text>
                          <Text fontSize="xs" color="gray.500">
                            {sorted === "asc"
                              ? "▲"
                              : sorted === "desc"
                                ? "▼"
                                : ""}
                          </Text>
                        </Box>
                        {header.column.getCanResize() && (
                          <Box
                            onMouseDown={header.getResizeHandler()}
                            onTouchStart={header.getResizeHandler()}
                            position="absolute"
                            right={0}
                            top={0}
                            h="100%"
                            w="6px"
                            cursor="col-resize"
                            zIndex={3}
                          />
                        )}
                      </Th>
                    )
                  })}
                </Tr>
              ))}
            </Thead>
            <Tbody>
              {isLoading && (
                <Tr>
                  <Td colSpan={table.getAllLeafColumns().length}>
                    <Text py={4}>Загрузка...</Text>
                  </Td>
                </Tr>
              )}
              {!isLoading && table.getRowModel().rows.length === 0 && (
                <Tr>
                  <Td colSpan={table.getAllLeafColumns().length}>
                    <Text py={4}>Нет данных</Text>
                  </Td>
                </Tr>
              )}
              {!isLoading &&
                table.getRowModel().rows.map((row) => (
                  <Tr
                    key={row.id}
                    bg={deadlineRowColor(resolveDeadlineState(row.original))}
                    _hover={{
                      bg: deadlineRowHoverColor(resolveDeadlineState(row.original)),
                    }}
                    cursor="pointer"
                    onClick={() => {
                      setSelectedTaskId(row.original.id)
                      taskDrawer.onOpen()
                    }}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <Td
                        key={cell.id}
                        py="6px"
                        borderColor="gray.200"
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext(),
                        )}
                      </Td>
                    ))}
                  </Tr>
                ))}
            </Tbody>
          </Table>
        </Box>

        <HStack
          justify="space-between"
          p={3}
          borderTopWidth="1px"
          borderColor="ui.border"
          bg="white"
        >
          <Text fontSize="sm" color="gray.600">
            {fromRow}-{toRow} из {totalRows}
          </Text>
          <HStack>
            <Select
              size="sm"
              value={pagination.pageSize}
              onChange={(e) =>
                setPagination({
                  pageIndex: 0,
                  pageSize: Number(e.target.value),
                })
              }
              w="110px"
            >
              {[10, 20, 50, 100].map((size) => (
                <option key={size} value={size}>
                  {size} / стр.
                </option>
              ))}
            </Select>
            <Button
              size="sm"
              onClick={() => table.previousPage()}
              isDisabled={!table.getCanPreviousPage()}
            >
              Назад
            </Button>
            <Text fontSize="sm">
              {pagination.pageIndex + 1} / {table.getPageCount()}
            </Text>
            <Button
              size="sm"
              onClick={() => table.nextPage()}
              isDisabled={!table.getCanNextPage()}
            >
              Вперёд
            </Button>
          </HStack>
        </HStack>
      </Box>

      <Drawer
        isOpen={taskDrawer.isOpen}
        placement="right"
        onClose={closeTaskDrawer}
        size="xl"
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>
            {selectedTask ? `Задача #${selectedTask.id}` : "Карточка задачи"}
          </DrawerHeader>
          <DrawerBody>
            {selectedTaskLoading ? (
              <HStack py={4}>
                <Spinner size="sm" />
                <Text>Загрузка задачи…</Text>
              </HStack>
            ) : !selectedTask ? (
              <Text>Задача не найдена</Text>
            ) : (
              <VStack align="stretch" spacing={4}>
                <Box>
                  <HStack justify="space-between" align="start">
                    <Box>
                      <Text fontWeight="700">{selectedTask.title}</Text>
                      <Text fontSize="sm" color="ui.muted">
                        {selectedTask.project_name || `Проект #${selectedTask.project_id}`}
                      </Text>
                    </Box>
                    <Badge colorScheme={deadlineBadgeColor(resolveDeadlineState(selectedTask))}>
                      {deadlineBadgeLabel(resolveDeadlineState(selectedTask))}
                    </Badge>
                  </HStack>
                  <Text fontSize="sm" mt={2} color="ui.darkSlate">
                    {htmlToText(selectedTask.description)}
                  </Text>
                </Box>

                <Box borderWidth="1px" borderColor="ui.border" borderRadius="8px" p={3}>
                  <Text fontWeight="600" mb={2}>
                    Параметры
                  </Text>
                  <Text fontSize="sm">Состояние: {selectedTask.status_name || selectedTask.workflow_status_name || "-"}</Text>
                  <Text fontSize="sm">Исполнитель: {selectedTask.assignee_name || "-"}</Text>
                  <Text fontSize="sm">Департамент: {selectedTask.department_name || "-"}</Text>
                  <Text fontSize="sm">Срок: {formatDateTime(selectedTask.due_date)}</Text>
                  <Text fontSize="sm">Последняя активность: {selectedTask.last_activity_at ? formatDateTime(selectedTask.last_activity_at) : "-"}</Text>
                  <Text fontSize="sm">Кто обновил: {selectedTask.last_activity_by || "-"}</Text>
                </Box>

                <Box borderWidth="1px" borderColor="ui.border" borderRadius="8px" p={3}>
                  <Text fontWeight="600" mb={2}>
                    Вложения ({selectedTaskAttachments?.count ?? 0})
                  </Text>
                  <VStack align="stretch" spacing={1}>
                    {(selectedTaskAttachments?.data ?? []).slice(0, 5).map((attachment) => (
                      <HStack key={attachment.id} justify="space-between">
                        <Text fontSize="sm" noOfLines={1}>
                          {attachment.file_name}
                        </Text>
                        <Button
                          size="xs"
                          onClick={() =>
                            downloadAttachment(attachment.id, attachment.file_name)
                          }
                        >
                          Скачать
                        </Button>
                      </HStack>
                    ))}
                    {!selectedTaskAttachments?.count && (
                      <Text fontSize="sm" color="ui.muted">
                        Вложений нет
                      </Text>
                    )}
                  </VStack>
                </Box>

                <Box borderWidth="1px" borderColor="ui.border" borderRadius="8px" p={3}>
                  <Text fontWeight="600" mb={2}>
                    Последние комментарии
                  </Text>
                  <VStack align="stretch" spacing={2}>
                    {(selectedTaskComments?.data ?? []).slice(0, 4).map((comment) => (
                      <Box key={comment.id} borderWidth="1px" borderColor="ui.border" borderRadius="6px" p={2}>
                        <Text fontSize="sm">{comment.comment}</Text>
                        <Text fontSize="xs" color="ui.muted">
                          {formatDateTime(comment.created_at)}
                        </Text>
                      </Box>
                    ))}
                    {!selectedTaskComments?.count && (
                      <Text fontSize="sm" color="ui.muted">
                        Комментариев пока нет
                      </Text>
                    )}
                  </VStack>
                </Box>

                <Box borderWidth="1px" borderColor="ui.border" borderRadius="8px" p={3}>
                  <Text fontWeight="600" mb={2}>
                    История ({selectedTaskHistory?.count ?? 0})
                  </Text>
                  <VStack align="stretch" spacing={1}>
                    {(selectedTaskHistory?.data ?? []).slice(0, 6).map((item) => (
                      <Text key={item.id} fontSize="sm">
                        {formatDateTime(item.created_at)} • {humanizeAction(item.action)}{" "}
                        {item.field_name ? `(${item.field_name})` : ""}
                      </Text>
                    ))}
                    {!selectedTaskHistory?.count && (
                      <Text fontSize="sm" color="ui.muted">
                        История пуста
                      </Text>
                    )}
                  </VStack>
                </Box>

                <Button
                  as={Link}
                  to="/tasks/$taskId"
                  params={{ taskId: String(selectedTask.id) }}
                  onClick={closeTaskDrawer}
                  variant="subtle"
                >
                  Открыть полную карточку
                </Button>
              </VStack>
            )}
          </DrawerBody>
        </DrawerContent>
      </Drawer>

      <Modal
        isOpen={modal.isOpen}
        onClose={modal.onClose}
        size="4xl"
        isCentered
      >
        <ModalOverlay />
        <ModalContent borderRadius="10px">
          <ModalHeader>Создание задачи</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Box display="grid" gridTemplateColumns="1fr" gap={3}>
              <FormControl isRequired>
                <FormLabel>Название задачи</FormLabel>
                <Input
                  value={form.title}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, title: e.target.value }))
                  }
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Описание задачи</FormLabel>
                <RichTextEditor
                  value={form.description}
                  onChange={(next) =>
                    setForm((prev) => ({
                      ...prev,
                      description: next,
                    }))
                  }
                  minH="220px"
                  placeholder="Используйте форматирование: жирный текст, списки, чек-листы"
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Проект</FormLabel>
                <Select
                  value={form.project_id}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      project_id: Number(e.target.value),
                      workflow_status_id: 0,
                      assignee_id: "",
                      controller_id: "",
                    }))
                  }
                >
                  <option value={0} disabled>
                    Выберите проект
                  </option>
                  {projectsData?.data.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </Select>
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Состояние задачи</FormLabel>
                <Select
                  value={form.workflow_status_id}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      workflow_status_id: Number(e.target.value),
                    }))
                  }
                  isDisabled={!selectedProjectId}
                >
                  <option value={0} disabled>
                    Выберите состояние
                  </option>
                  {statusesData?.data.map((status) => (
                    <option key={status.id} value={status.id}>
                      {status.name}
                    </option>
                  ))}
                </Select>
              </FormControl>

              <Box
                display="grid"
                gridTemplateColumns={{ base: "1fr", md: "1fr 1fr" }}
                gap={3}
              >
                <FormControl>
                  <FormLabel>Исполнитель</FormLabel>
                  <Select
                    value={form.assignee_id}
                    onChange={(e) =>
                      setForm((prev) => ({
                        ...prev,
                        assignee_id: e.target.value,
                      }))
                    }
                    isDisabled={!selectedProjectId}
                  >
                    <option value="">Не назначен</option>
                    {memberOptions.map((member) => (
                      <option
                        key={`assignee-${member.id}-${member.role}`}
                        value={member.id}
                      >
                        {member.label}
                      </option>
                    ))}
                  </Select>
                </FormControl>

                <FormControl>
                  <FormLabel>Контроллер</FormLabel>
                  <Select
                    value={form.controller_id}
                    onChange={(e) =>
                      setForm((prev) => ({
                        ...prev,
                        controller_id: e.target.value,
                      }))
                    }
                    isDisabled={!selectedProjectId}
                  >
                    <option value="">Не назначен</option>
                    {memberOptions
                      .filter(
                        (member) =>
                          member.role === "controller" ||
                          member.role === "manager",
                      )
                      .map((member) => (
                        <option
                          key={`controller-${member.id}-${member.role}`}
                          value={member.id}
                        >
                          {member.label}
                        </option>
                      ))}
                  </Select>
                </FormControl>
              </Box>

              <Box
                display="grid"
                gridTemplateColumns={{ base: "1fr", md: "1fr" }}
                gap={3}
              >
                <FormControl isRequired>
                  <FormLabel>Срок</FormLabel>
                  <Input
                    type="datetime-local"
                    value={form.due_date}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, due_date: e.target.value }))
                    }
                    />
                </FormControl>

                <FormControl>
                  <FormLabel>Вложения</FormLabel>
                  <Input
                    type="file"
                    multiple
                    onChange={(event) => {
                      const files = event.target.files
                      setCreateFiles(files ? Array.from(files) : [])
                    }}
                  />
                  <Text mt={1} fontSize="xs" color="ui.muted">
                    {createFiles.length
                      ? `Выбрано файлов: ${createFiles.length}`
                      : "Файлы можно прикрепить сразу при создании"}
                  </Text>
                </FormControl>
              </Box>
            </Box>
          </ModalBody>
          <ModalFooter gap={3}>
            <Button
              variant="primary"
              onClick={() => createMutation.mutate()}
              isLoading={createMutation.isPending}
              isDisabled={
                !form.title.trim() ||
                !plainDescription.trim() ||
                !form.project_id ||
                !form.workflow_status_id ||
                !form.due_date
              }
            >
              Создать
            </Button>
            <Button onClick={modal.onClose}>Отмена</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      <Outlet />
    </Container>
  )
}

function parseSmartQuery(
  query: string,
  data: {
    projects: Project[]
    users: TrackerUser[]
    statuses: ProjectStatus[]
    departments: Array<{ id: number; name: string }>
  },
): SmartQueryResult {
  if (!query.trim()) return {}

  const tokens = query.trim().split(/\s+/)
  const rest: string[] = []
  const result: SmartQueryResult = {}

  for (const token of tokens) {
    const [rawKey, ...rawValueParts] = token.split(":")
    if (!rawValueParts.length) {
      rest.push(token)
      continue
    }

    const key = rawKey.toLowerCase()
    const value = rawValueParts.join(":").trim()

    if (key === "project") {
      const numeric = Number(value)
      if (!Number.isNaN(numeric) && numeric > 0) {
        result.projectId = numeric
      } else {
        const match = data.projects.find((project) =>
          project.name.toLowerCase().includes(value.toLowerCase()),
        )
        if (match) result.projectId = match.id
      }
      continue
    }

    if (key === "assignee") {
      const numeric = Number(value)
      if (!Number.isNaN(numeric) && numeric > 0) {
        result.assigneeId = numeric
      } else {
        const match = data.users.find((user) => {
          const fullName = (user.full_name || "").toLowerCase()
          const email = user.email.toLowerCase()
          const queryValue = value.toLowerCase()
          return fullName.includes(queryValue) || email.includes(queryValue)
        })
        if (match) result.assigneeId = match.id
      }
      continue
    }

    if (key === "status") {
      const numeric = Number(value)
      if (!Number.isNaN(numeric) && numeric > 0) {
        result.statusId = numeric
      } else {
        const match = data.statuses.find((status) =>
          status.name.toLowerCase().includes(value.toLowerCase()),
        )
        if (match) result.statusId = match.id
      }
      continue
    }

    if (key === "department") {
      const numeric = Number(value)
      if (!Number.isNaN(numeric) && numeric > 0) {
        result.departmentId = numeric
      } else {
        const match = data.departments.find((department) =>
          department.name.toLowerCase().includes(value.toLowerCase()),
        )
        if (match) result.departmentId = match.id
      }
      continue
    }

    if (key === "overdue") {
      result.overdueOnly = ["1", "true", "yes", "y", "да"].includes(
        value.toLowerCase(),
      )
      continue
    }

    rest.push(token)
  }

  if (rest.length) {
    result.plainSearch = rest.join(" ")
  }

  return result
}

function formatDate(value: string): string {
  return new Date(value).toLocaleDateString()
}

function formatDateTime(value: string): string {
  return new Date(value).toLocaleString()
}

function mapSortField(value: string): string {
  const mapping: Record<string, string> = {
    deadline_state: "due_date",
    workflow_status_name: "status_name",
  }
  return mapping[value] || value
}

function parsePositiveInt(value: string | null): number | undefined {
  if (!value) return undefined
  const parsed = Number(value)
  if (!Number.isInteger(parsed) || parsed <= 0) return undefined
  return parsed
}

function deadlineBadgeColor(state: "green" | "yellow" | "red") {
  if (state === "red") return "red"
  if (state === "yellow") return "yellow"
  return "green"
}

function deadlineBadgeLabel(state: "green" | "yellow" | "red") {
  if (state === "red") return "Просрочено"
  if (state === "yellow") return "Срок близко"
  return "В срок"
}

function deadlineRowColor(state: "green" | "yellow" | "red") {
  if (state === "red") return "#FAD7D7"
  if (state === "yellow") return "#FFE7A8"
  return "#CDEFD8"
}

function deadlineRowHoverColor(state: "green" | "yellow" | "red") {
  if (state === "red") return "#F5C0C0"
  if (state === "yellow") return "#FFD97A"
  return "#B4E7C4"
}

function resolveDeadlineState(task: Task): "green" | "yellow" | "red" {
  if (task.closed_overdue) return "red"
  return task.computed_deadline_state
}

function humanizeAction(action: string): string {
  const map: Record<string, string> = {
    created: "Создание",
    updated: "Обновление",
    due_date_changed: "Изменён срок",
    status_changed: "Изменён статус",
    assignee_changed: "Изменён исполнитель",
    closed: "Закрытие",
    reopened: "Переоткрытие",
    comment_added: "Комментарий",
    attachment_added: "Вложение",
  }
  return map[action] || action
}
