import {
  Badge,
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  Heading,
  HStack,
  Input,
  Text,
  VStack,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { createFileRoute } from "@tanstack/react-router"
import { useEffect, useMemo, useState } from "react"

import useCustomToast from "../../hooks/useCustomToast"
import { trackerApi } from "../../services/trackerApi"

export const Route = createFileRoute("/_layout/blocks")({
  component: GroupManagementPage,
})

function GroupManagementPage() {
  const showToast = useCustomToast()
  const queryClient = useQueryClient()

  const [selectedOrganizationId, setSelectedOrganizationId] = useState<
    number | null
  >(null)
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null)

  const [organizationForm, setOrganizationForm] = useState({
    name: "",
    code: "",
    description: "",
  })

  const [groupForm, setGroupForm] = useState({
    name: "",
    code: "",
    description: "",
  })

  const { data: organizationsData, isLoading: organizationsLoading } = useQuery({
    queryKey: ["organizations"],
    queryFn: () => trackerApi.listOrganizations(),
  })

  useEffect(() => {
    const organizations = organizationsData?.data ?? []
    if (!organizations.length) {
      setSelectedOrganizationId(null)
      return
    }
    setSelectedOrganizationId((prev) => {
      if (prev && organizations.some((item) => item.id === prev)) {
        return prev
      }
      return organizations[0].id
    })
  }, [organizationsData?.data])

  const { data: groupsData, isLoading: groupsLoading } = useQuery({
    queryKey: ["organization-groups", selectedOrganizationId],
    queryFn: () => trackerApi.getOrganizationGroups(selectedOrganizationId as number),
    enabled: selectedOrganizationId !== null,
  })

  useEffect(() => {
    const groups = groupsData?.data ?? []
    if (!groups.length) {
      setSelectedGroupId(null)
      return
    }
    setSelectedGroupId((prev) => {
      if (prev && groups.some((item) => item.id === prev)) {
        return prev
      }
      return groups[0].id
    })
  }, [groupsData?.data])

  const { data: groupMembersData, isLoading: groupMembersLoading } = useQuery({
    queryKey: ["group-members", selectedGroupId],
    queryFn: () => trackerApi.listOrganizationGroupMembers(selectedGroupId as number),
    enabled: selectedGroupId !== null,
  })

  const selectedOrganization = useMemo(
    () =>
      (organizationsData?.data ?? []).find(
        (organization) => organization.id === selectedOrganizationId,
      ),
    [organizationsData?.data, selectedOrganizationId],
  )

  const selectedGroup = useMemo(
    () => (groupsData?.data ?? []).find((group) => group.id === selectedGroupId),
    [groupsData?.data, selectedGroupId],
  )

  const createOrganizationMutation = useMutation({
    mutationFn: () =>
      trackerApi.createOrganization({
        name: organizationForm.name,
        code: organizationForm.code || null,
        description: organizationForm.description || null,
      }),
    onSuccess: (created) => {
      setOrganizationForm({ name: "", code: "", description: "" })
      queryClient.invalidateQueries({ queryKey: ["organizations"] })
      setSelectedOrganizationId(created.id)
      showToast.success("Успешно", "Организация создана")
    },
    onError: (error) => showToast.error("Не удалось создать организацию", error),
  })

  const createGroupMutation = useMutation({
    mutationFn: () =>
      trackerApi.createOrganizationGroup(selectedOrganizationId as number, {
        name: groupForm.name,
        code: groupForm.code || null,
        description: groupForm.description || null,
      }),
    onSuccess: () => {
      setGroupForm({ name: "", code: "", description: "" })
      queryClient.invalidateQueries({
        queryKey: ["organization-groups", selectedOrganizationId],
      })
      showToast.success("Успешно", "Группа создана")
    },
    onError: (error) => showToast.error("Не удалось создать группу", error),
  })

  return (
    <Container maxW="full" py={6}>
      <Heading size="lg" mb={1}>
        Управление группами
      </Heading>
      <Text color="ui.muted" mb={5}>
        Создавайте организации и группы внутри них. Это заменяет старый экран
        «Блоки проектов».
      </Text>

      <Grid templateColumns={{ base: "1fr", xl: "360px 1fr" }} gap={4}>
        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            p={4}
            bg="white"
            boxShadow="sm"
            mb={4}
          >
            <Heading size="sm" mb={3}>
              Создать организацию
            </Heading>
            <VStack spacing={3} align="stretch">
              <FormControl isRequired>
                <FormLabel>Название</FormLabel>
                <Input
                  value={organizationForm.name}
                  onChange={(e) =>
                    setOrganizationForm((prev) => ({
                      ...prev,
                      name: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormControl>
                <FormLabel>Код</FormLabel>
                <Input
                  value={organizationForm.code}
                  onChange={(e) =>
                    setOrganizationForm((prev) => ({
                      ...prev,
                      code: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormControl>
                <FormLabel>Описание</FormLabel>
                <Input
                  value={organizationForm.description}
                  onChange={(e) =>
                    setOrganizationForm((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <Button
                onClick={() => createOrganizationMutation.mutate()}
                isLoading={createOrganizationMutation.isPending}
                isDisabled={!organizationForm.name.trim()}
              >
                Создать организацию
              </Button>
            </VStack>
          </Box>

          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            bg="white"
            boxShadow="sm"
            overflow="hidden"
          >
            <Box px={4} py={3} borderBottomWidth="1px" borderColor="ui.border">
              <Text fontWeight="700">Организации</Text>
            </Box>
            <VStack align="stretch" spacing={0}>
              {organizationsLoading && (
                <Text px={4} py={4} color="ui.muted">
                  Загрузка...
                </Text>
              )}
              {(organizationsData?.data ?? []).map((organization) => (
                <Box
                  key={organization.id}
                  px={4}
                  py={3}
                  borderTopWidth="1px"
                  borderColor="ui.border"
                  cursor="pointer"
                  bg={
                    selectedOrganizationId === organization.id
                      ? "ui.secondary"
                      : "transparent"
                  }
                  _hover={{ bg: "#F8FAFD" }}
                  onClick={() => setSelectedOrganizationId(organization.id)}
                >
                  <Text fontWeight="600">{organization.name}</Text>
                  <HStack spacing={2} mt={1}>
                    <Badge borderRadius="full">Группы: {organization.groups_count}</Badge>
                    <Badge borderRadius="full">Проекты: {organization.projects_count}</Badge>
                  </HStack>
                </Box>
              ))}
            </VStack>
          </Box>
        </GridItem>

        <GridItem>
          <Box
            borderWidth="1px"
            borderColor="ui.border"
            borderRadius="12px"
            p={4}
            bg="white"
            boxShadow="sm"
            mb={4}
          >
            <Heading size="sm" mb={1}>
              {selectedOrganization
                ? `Группы организации: ${selectedOrganization.name}`
                : "Группы"}
            </Heading>
            <Text color="ui.muted" mb={4}>
              Добавляйте департаменты/группы в выбранную организацию.
            </Text>

            <Grid templateColumns={{ base: "1fr", md: "1.2fr 1fr 1fr auto" }} gap={3}>
              <FormControl isRequired>
                <FormLabel>Название группы</FormLabel>
                <Input
                  value={groupForm.name}
                  onChange={(e) =>
                    setGroupForm((prev) => ({ ...prev, name: e.target.value }))
                  }
                  placeholder="Например, Департамент аналитики"
                />
              </FormControl>
              <FormControl>
                <FormLabel>Код</FormLabel>
                <Input
                  value={groupForm.code}
                  onChange={(e) =>
                    setGroupForm((prev) => ({ ...prev, code: e.target.value }))
                  }
                />
              </FormControl>
              <FormControl>
                <FormLabel>Описание</FormLabel>
                <Input
                  value={groupForm.description}
                  onChange={(e) =>
                    setGroupForm((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <Button
                mt={{ base: 0, md: 8 }}
                onClick={() => createGroupMutation.mutate()}
                isLoading={createGroupMutation.isPending}
                isDisabled={!selectedOrganizationId || !groupForm.name.trim()}
              >
                Создать группу
              </Button>
            </Grid>
          </Box>

          <Grid templateColumns={{ base: "1fr", xl: "1fr 1fr" }} gap={4}>
            <GridItem>
              <Box
                borderWidth="1px"
                borderColor="ui.border"
                borderRadius="12px"
                bg="white"
                boxShadow="sm"
                overflow="hidden"
              >
                <Box
                  px={4}
                  py={3}
                  borderBottomWidth="1px"
                  borderColor="ui.border"
                >
                  <Text fontWeight="700">Список групп</Text>
                </Box>
                <VStack align="stretch" spacing={0}>
                  {groupsLoading && (
                    <Text px={4} py={4} color="ui.muted">
                      Загрузка...
                    </Text>
                  )}
                  {!groupsLoading && !(groupsData?.data ?? []).length && (
                    <Text px={4} py={4} color="ui.muted">
                      В выбранной организации пока нет групп.
                    </Text>
                  )}
                  {(groupsData?.data ?? []).map((group) => (
                    <Box
                      key={group.id}
                      px={4}
                      py={3}
                      borderTopWidth="1px"
                      borderColor="ui.border"
                      cursor="pointer"
                      bg={selectedGroupId === group.id ? "ui.secondary" : "transparent"}
                      _hover={{ bg: "#F8FAFD" }}
                      onClick={() => setSelectedGroupId(group.id)}
                    >
                      <Text fontWeight="600">{group.name}</Text>
                      <Text fontSize="sm" color="ui.muted" noOfLines={2}>
                        {group.description || "Описание не указано"}
                      </Text>
                    </Box>
                  ))}
                </VStack>
              </Box>
            </GridItem>

            <GridItem>
              <Box
                borderWidth="1px"
                borderColor="ui.border"
                borderRadius="12px"
                bg="white"
                boxShadow="sm"
                overflow="hidden"
              >
                <Box
                  px={4}
                  py={3}
                  borderBottomWidth="1px"
                  borderColor="ui.border"
                >
                  <Text fontWeight="700">
                    {selectedGroup
                      ? `Участники: ${selectedGroup.name}`
                      : "Участники группы"}
                  </Text>
                </Box>
                <VStack align="stretch" spacing={0}>
                  {groupMembersLoading && (
                    <Text px={4} py={4} color="ui.muted">
                      Загрузка...
                    </Text>
                  )}
                  {!groupMembersLoading && !(groupMembersData?.data ?? []).length && (
                    <Text px={4} py={4} color="ui.muted">
                      У этой группы пока нет участников.
                    </Text>
                  )}
                  {(groupMembersData?.data ?? []).map((member) => (
                    <Box
                      key={member.user_id}
                      px={4}
                      py={3}
                      borderTopWidth="1px"
                      borderColor="ui.border"
                    >
                      <Text fontWeight="600">{member.user_name || member.user_email}</Text>
                      <Text fontSize="sm" color="ui.muted">
                        {member.user_email}
                      </Text>
                    </Box>
                  ))}
                </VStack>
              </Box>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
    </Container>
  )
}
