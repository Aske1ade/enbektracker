import {
  Badge,
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Heading,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
  Switch,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tooltip,
  Tr,
  useDisclosure,
} from "@chakra-ui/react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { createFileRoute } from "@tanstack/react-router"
import { useMemo, useState } from "react"

import useCustomToast from "../../hooks/useCustomToast"
import {
  type AdminUserCreatePayload,
  type AdminUserUpdatePayload,
  trackerApi,
} from "../../services/trackerApi"
import type { TrackerUser } from "../../types/tracker"

export const Route = createFileRoute("/_layout/admin")({
  component: AdminPage,
})

type UserFormState = {
  email: string
  full_name: string
  password: string
  is_active: boolean
  is_superuser: boolean
  system_role: "user" | "system_admin"
  department_id: string
}

const emptyUserForm: UserFormState = {
  email: "",
  full_name: "",
  password: "",
  is_active: true,
  is_superuser: false,
  system_role: "user",
  department_id: "",
}

const ROLE_META: Record<
  UserFormState["system_role"],
  { label: string; hint: string }
> = {
  user: {
    label: "Пользователь",
    hint: "Стандартный пользователь с доступом через назначения ролей в проектах.",
  },
  system_admin: {
    label: "Системный администратор",
    hint: "Полный доступ к администрированию системы и проектных настроек.",
  },
}

function normalizeSystemRole(
  role: string | undefined | null,
): UserFormState["system_role"] {
  if (role === "system_admin" || role === "admin" || role === "manager") {
    return "system_admin"
  }
  return "user"
}

function AdminPage() {
  const showToast = useCustomToast()
  const queryClient = useQueryClient()
  const createModal = useDisclosure()
  const editModal = useDisclosure()
  const [search, setSearch] = useState("")
  const [newUser, setNewUser] = useState<UserFormState>(emptyUserForm)
  const [editingUser, setEditingUser] = useState<TrackerUser | null>(null)
  const [editForm, setEditForm] = useState<UserFormState>(emptyUserForm)

  const { data: usersData, isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => trackerApi.listUsers(),
  })

  const { data: departmentsData } = useQuery({
    queryKey: ["departments-for-admin"],
    queryFn: () => trackerApi.listDepartments(),
  })

  const { data: demoData, isLoading: demoDataLoading } = useQuery({
    queryKey: ["admin-demo-data"],
    queryFn: () => trackerApi.getDemoDataStatus(),
  })

  const filteredUsers = useMemo(() => {
    const rows = usersData?.data ?? []
    if (!search.trim()) return rows
    const q = search.trim().toLowerCase()
    return rows.filter(
      (user) =>
        user.email.toLowerCase().includes(q) ||
        (user.full_name || "").toLowerCase().includes(q) ||
        (user.system_role || "").toLowerCase().includes(q) ||
        ROLE_META[normalizeSystemRole(user.system_role)].label
          .toLowerCase()
          .includes(q),
    )
  }, [usersData, search])

  const createMutation = useMutation({
    mutationFn: (payload: AdminUserCreatePayload) =>
      trackerApi.adminCreateUser(payload),
    onSuccess: () => {
      showToast.success("Успешно", "Пользователь создан")
      createModal.onClose()
      setNewUser(emptyUserForm)
      queryClient.invalidateQueries({ queryKey: ["admin-users"] })
    },
    onError: (error) =>
      showToast.error("Не удалось создать пользователя", error),
  })

  const updateMutation = useMutation({
    mutationFn: ({
      userId,
      payload,
    }: {
      userId: number
      payload: AdminUserUpdatePayload
    }) => trackerApi.adminUpdateUser(userId, payload),
    onSuccess: () => {
      showToast.success("Успешно", "Пользователь обновлён")
      editModal.onClose()
      setEditingUser(null)
      queryClient.invalidateQueries({ queryKey: ["admin-users"] })
    },
    onError: (error) =>
      showToast.error("Не удалось обновить пользователя", error),
  })

  const deleteMutation = useMutation({
    mutationFn: (userId: number) => trackerApi.adminDeleteUser(userId),
    onSuccess: () => {
      showToast.success("Успешно", "Пользователь удалён")
      queryClient.invalidateQueries({ queryKey: ["admin-users"] })
    },
    onError: (error) =>
      showToast.error("Не удалось удалить пользователя", error),
  })

  const desktopTestMutation = useMutation({
    mutationFn: ({
      userId,
      mode,
    }: {
      userId: number
      mode: "single" | "full"
    }) => trackerApi.adminSendDesktopEventsTest(userId, mode),
    onSuccess: (result) => {
      showToast.success(
        "Тестовые события отправлены",
        `Создано desktop-событий: ${result.created_count}`,
      )
    },
    onError: (error) =>
      showToast.error("Не удалось отправить тестовые события", error),
  })

  const demoDataMutation = useMutation({
    mutationFn: (enabled: boolean) => trackerApi.setDemoDataEnabled(enabled),
    onSuccess: (data, enabled) => {
      queryClient.setQueryData(["admin-demo-data"], data)
      queryClient.invalidateQueries({ queryKey: ["admin-users"] })
      queryClient.invalidateQueries({ queryKey: ["departments-for-admin"] })
      queryClient.invalidateQueries({ queryKey: ["projects-for-calendar"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard-projects"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard-departments"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard-summary"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard-trends"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard-report-rows"] })
      queryClient.invalidateQueries({ queryKey: ["reports-projects"] })
      queryClient.invalidateQueries({ queryKey: ["reports-users"] })
      queryClient.invalidateQueries({ queryKey: ["reports-departments"] })
      queryClient.invalidateQueries({ queryKey: ["report-tasks"] })
      queryClient.invalidateQueries({ queryKey: ["tasks-list"] })
      queryClient.invalidateQueries({ queryKey: ["projects-list"] })
      queryClient.invalidateQueries({ queryKey: ["projects-list-for-tasks"] })
      queryClient.invalidateQueries({ queryKey: ["calendar-summary"] })
      queryClient.invalidateQueries({ queryKey: ["calendar-day"] })

      if (enabled) {
        showToast.success("Успешно", "Система заполнена демо-данными")
      } else {
        showToast.success("Успешно", "Демо-данные удалены")
      }
    },
    onError: (error) =>
      showToast.error("Не удалось переключить демо-данные", error),
  })

  return (
    <Container maxW="full" py={6}>
      <HStack justify="space-between" mb={4} align="start">
        <Box>
          <Heading size="lg" mb={1}>
            Администрирование пользователей
          </Heading>
          <Text color="gray.600">
            Управление ролями, департаментами и активностью пользователей
          </Text>
        </Box>
        <Button onClick={createModal.onOpen}>Добавить пользователя</Button>
      </HStack>

      <Box
        borderWidth="1px"
        borderColor="ui.border"
        borderRadius="md"
        p={4}
        bg="white"
        mb={4}
      >
        <HStack justify="space-between" align="start" mb={3}>
          <Box>
            <Text fontWeight="700">Демо-данные системы</Text>
            <Text color="gray.600" fontSize="sm">
              Переключатель создаёт/удаляет только тестовые сущности демо-набора{" "}
              <b>{demoData?.marker || "Текущий batch"}</b>
            </Text>
          </Box>
          <FormControl
            display="flex"
            alignItems="center"
            justifyContent="flex-end"
            maxW="320px"
          >
            <FormLabel m={0} mr={3}>
              Заполнить тестовыми данными
            </FormLabel>
            <Switch
              isChecked={Boolean(demoData?.enabled)}
              isDisabled={demoDataLoading || demoDataMutation.isPending}
              onChange={(event) =>
                demoDataMutation.mutate(event.target.checked)
              }
            />
          </FormControl>
        </HStack>

        <HStack spacing={2} flexWrap="wrap" mb={3}>
          <Badge borderRadius="sm" colorScheme="blue">
            Департаменты: {demoData?.departments_count ?? 0}
          </Badge>
          <Badge borderRadius="sm" colorScheme="purple">
            Пользователи: {demoData?.users_count ?? 0}
          </Badge>
          <Badge borderRadius="sm" colorScheme="cyan">
            Проекты: {demoData?.projects_count ?? 0}
          </Badge>
          <Badge borderRadius="sm" colorScheme="orange">
            Задачи: {demoData?.tasks_count ?? 0}
          </Badge>
        </HStack>

        {Boolean(demoData?.enabled) &&
          (demoData?.credentials?.length ?? 0) > 0 && (
            <Box borderWidth="1px" borderColor="ui.border" borderRadius="md">
              <Box px={3} py={2} borderBottomWidth="1px" bg="gray.50">
                <Text fontWeight="600" fontSize="sm">
                  Готовые demo-пользователи для показа
                </Text>
              </Box>
              <Box overflowX="auto">
                <Table size="sm">
                  <Thead>
                    <Tr>
                      <Th>Email</Th>
                      <Th>ФИО</Th>
                      <Th>Роль</Th>
                      <Th>Департамент</Th>
                      <Th>Пароль</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {demoData?.credentials.map((credential) => (
                      <Tr key={credential.email}>
                        <Td>{credential.email}</Td>
                        <Td>{credential.full_name || "-"}</Td>
                        <Td>
                          <Tooltip
                            label={
                              ROLE_META[normalizeSystemRole(credential.system_role)]
                                .hint
                            }
                            hasArrow
                            placement="top-start"
                          >
                            <Text as="span" cursor="help">
                              {
                                ROLE_META[normalizeSystemRole(credential.system_role)]
                                  .label
                              }
                            </Text>
                          </Tooltip>
                        </Td>
                        <Td>{credential.department_name || "-"}</Td>
                        <Td>
                          <Badge borderRadius="sm" colorScheme="green">
                            {credential.password}
                          </Badge>
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              </Box>
            </Box>
          )}
      </Box>

      <Box
        borderWidth="1px"
        borderColor="ui.border"
        borderRadius="md"
        p={4}
        bg="white"
        mb={4}
      >
        <Grid templateColumns={{ base: "1fr", md: "1fr 220px" }} gap={3}>
          <GridItem>
            <FormControl>
              <FormLabel>Поиск</FormLabel>
              <Input
                placeholder="email / ФИО / роль"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </FormControl>
          </GridItem>
          <GridItem>
            <Text fontSize="xs" color="ui.muted" mt={8}>
              Найдено: {filteredUsers.length}
            </Text>
          </GridItem>
        </Grid>
      </Box>

      <Box
        borderWidth="1px"
        borderColor="ui.border"
        borderRadius="md"
        overflow="hidden"
        bg="white"
      >
        <Box overflowX="auto">
          <Table size="sm">
            <Thead>
              <Tr>
                <Th>ID</Th>
                <Th>Пользователь</Th>
                <Th>Email</Th>
                <Th>Роль</Th>
                <Th>Департамент</Th>
                <Th>Статус</Th>
                <Th>Admin</Th>
                <Th>Действия</Th>
              </Tr>
            </Thead>
            <Tbody>
              {isLoading && (
                <Tr>
                  <Td colSpan={8}>Загрузка...</Td>
                </Tr>
              )}
              {!isLoading &&
                filteredUsers.map((user) => (
                  <Tr key={user.id}>
                    <Td>{user.id}</Td>
                    <Td>{user.full_name || "-"}</Td>
                    <Td>{user.email}</Td>
                    <Td>
                      <Tooltip
                        label={
                          ROLE_META[normalizeSystemRole(user.system_role)].hint
                        }
                        hasArrow
                        placement="top-start"
                      >
                        <Text as="span" cursor="help">
                          {ROLE_META[normalizeSystemRole(user.system_role)].label}
                        </Text>
                      </Tooltip>
                    </Td>
                    <Td>
                      {departmentsData?.data.find(
                        (dep) => dep.id === user.department_id,
                      )?.name || "-"}
                    </Td>
                    <Td>
                      <Badge
                        borderRadius="sm"
                        colorScheme={user.is_active ? "green" : "gray"}
                      >
                        {user.is_active ? "Активен" : "Отключён"}
                      </Badge>
                    </Td>
                    <Td>{user.is_superuser ? "Да" : "Нет"}</Td>
                    <Td>
                      <HStack spacing={2}>
                        <Button
                          size="xs"
                          colorScheme="blue"
                          variant="outline"
                          onClick={() =>
                            desktopTestMutation.mutate({
                              userId: user.id,
                              mode: "full",
                            })
                          }
                          isLoading={
                            desktopTestMutation.isPending &&
                            desktopTestMutation.variables?.userId === user.id
                          }
                        >
                          Тест desktop
                        </Button>
                        <Button
                          size="xs"
                          variant="subtle"
                          onClick={() => {
                            setEditingUser(user)
                            setEditForm({
                              email: user.email,
                              full_name: user.full_name || "",
                              password: "",
                              is_active: user.is_active,
                              is_superuser: user.is_superuser,
                              system_role: normalizeSystemRole(user.system_role),
                              department_id: user.department_id
                                ? String(user.department_id)
                                : "",
                            })
                            editModal.onOpen()
                          }}
                        >
                          Изменить
                        </Button>
                        <Button
                          size="xs"
                          colorScheme="red"
                          variant="outline"
                          onClick={() => deleteMutation.mutate(user.id)}
                          isLoading={deleteMutation.isPending}
                        >
                          Удалить
                        </Button>
                      </HStack>
                    </Td>
                  </Tr>
                ))}
            </Tbody>
          </Table>
        </Box>
      </Box>

      <Modal isOpen={createModal.isOpen} onClose={createModal.onClose}>
        <ModalOverlay />
        <ModalContent borderRadius="md">
          <ModalHeader>Новый пользователь</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <UserForm
              value={newUser}
              departments={departmentsData?.data ?? []}
              onChange={setNewUser}
              isEdit={false}
            />
          </ModalBody>
          <ModalFooter gap={3}>
            <Button
              onClick={() =>
                createMutation.mutate({
                  email: newUser.email,
                  full_name: newUser.full_name || undefined,
                  password: newUser.password,
                  is_active: newUser.is_active,
                  is_superuser: newUser.is_superuser,
                  system_role: newUser.system_role,
                  department_id: newUser.department_id
                    ? Number(newUser.department_id)
                    : null,
                })
              }
              isLoading={createMutation.isPending}
              isDisabled={!newUser.email || !newUser.password}
            >
              Создать
            </Button>
            <Button variant="subtle" onClick={createModal.onClose}>
              Отмена
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      <Modal isOpen={editModal.isOpen} onClose={editModal.onClose}>
        <ModalOverlay />
        <ModalContent borderRadius="md">
          <ModalHeader>Изменить пользователя</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <UserForm
              value={editForm}
              departments={departmentsData?.data ?? []}
              onChange={setEditForm}
              isEdit
            />
          </ModalBody>
          <ModalFooter gap={3}>
            <Button
              onClick={() => {
                if (!editingUser) return
                updateMutation.mutate({
                  userId: editingUser.id,
                  payload: {
                    email: editForm.email,
                    full_name: editForm.full_name || null,
                    password: editForm.password || null,
                    is_active: editForm.is_active,
                    is_superuser: editForm.is_superuser,
                    system_role: editForm.system_role,
                    department_id: editForm.department_id
                      ? Number(editForm.department_id)
                      : null,
                  },
                })
              }}
              isLoading={updateMutation.isPending}
              isDisabled={!editForm.email}
            >
              Сохранить
            </Button>
            <Button variant="subtle" onClick={editModal.onClose}>
              Отмена
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Container>
  )
}

function UserForm({
  value,
  departments,
  onChange,
  isEdit,
}: {
  value: UserFormState
  departments: Array<{ id: number; name: string }>
  onChange: (next: UserFormState) => void
  isEdit: boolean
}) {
  return (
    <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={3}>
      <GridItem colSpan={{ base: 1, md: 2 }}>
        <FormControl isRequired>
          <FormLabel>Email</FormLabel>
          <Input
            value={value.email}
            onChange={(e) => onChange({ ...value, email: e.target.value })}
            type="email"
          />
        </FormControl>
      </GridItem>
      <GridItem colSpan={{ base: 1, md: 2 }}>
        <FormControl>
          <FormLabel>ФИО</FormLabel>
          <Input
            value={value.full_name}
            onChange={(e) => onChange({ ...value, full_name: e.target.value })}
          />
        </FormControl>
      </GridItem>
      <GridItem colSpan={{ base: 1, md: 2 }}>
        <FormControl isRequired={!isEdit}>
          <FormLabel>
            {isEdit ? "Новый пароль (опционально)" : "Пароль"}
          </FormLabel>
          <Input
            type="password"
            value={value.password}
            onChange={(e) => onChange({ ...value, password: e.target.value })}
          />
        </FormControl>
      </GridItem>
      <GridItem>
        <FormControl>
          <FormLabel>Системная роль</FormLabel>
          <Select
            value={value.system_role}
            onChange={(e) =>
              onChange({
                ...value,
                system_role: e.target.value as UserFormState["system_role"],
              })
            }
          >
            <option value="user">Пользователь</option>
            <option value="system_admin">Системный администратор</option>
          </Select>
          <Text mt={1} fontSize="xs" color="ui.muted">
            {ROLE_META[value.system_role].hint}
          </Text>
        </FormControl>
      </GridItem>
      <GridItem>
        <FormControl>
          <FormLabel>Департамент</FormLabel>
          <Select
            value={value.department_id}
            onChange={(e) =>
              onChange({ ...value, department_id: e.target.value })
            }
          >
            <option value="">Не задан</option>
            {departments.map((department) => (
              <option key={department.id} value={department.id}>
                {department.name}
              </option>
            ))}
          </Select>
        </FormControl>
      </GridItem>
      <GridItem>
        <FormControl display="flex" justifyContent="space-between" mt={2}>
          <FormLabel m={0}>Активен</FormLabel>
          <Switch
            isChecked={value.is_active}
            onChange={(e) =>
              onChange({ ...value, is_active: e.target.checked })
            }
          />
        </FormControl>
      </GridItem>
      <GridItem>
        <FormControl display="flex" justifyContent="space-between" mt={2}>
          <FormLabel m={0}>Superuser (полный системный доступ)</FormLabel>
          <Switch
            isChecked={value.is_superuser}
            onChange={(e) =>
              onChange({ ...value, is_superuser: e.target.checked })
            }
          />
        </FormControl>
      </GridItem>
    </Grid>
  )
}
