export type TaskDeadlineState = "green" | "yellow" | "red"
export type TaskUrgencyState = "overdue" | "critical" | "normal" | "reserve"
export type TaskSystemStatus = "new" | "in_progress" | "blocked" | "done"

export interface Department {
  id: number
  name: string
  code?: string | null
  description?: string | null
}

export interface TrackerUser {
  id: number
  email: string
  full_name?: string | null
  is_active: boolean
  is_superuser: boolean
  system_role?:
    | "user"
    | "system_admin"
    | "executor"
    | "controller"
    | "manager"
    | "admin"
  primary_group_id?: number | null
  department_id?: number | null
  department_name?: string | null
  created_at?: string
  updated_at?: string
}

export interface Project {
  id: number
  name: string
  description?: string | null
  organization_id?: number | null
  organization_name?: string | null
  department_id?: number | null
  department_name?: string | null
  department_names?: string[]
  block_id?: number | null
  block_name?: string | null
  require_close_comment: boolean
  require_close_attachment: boolean
  deadline_yellow_days: number
  deadline_normal_days: number
  owner_name?: string | null
  members_count?: number | null
  tasks_count?: number | null
  created_at?: string
  updated_at?: string
}

export interface ProjectStatus {
  id: number
  project_id: number
  name: string
  code?: TaskSystemStatus | null
  color?: string | null
  order: number
  is_default: boolean
  is_final: boolean
}

export interface ProjectMember {
  id: number
  project_id: number
  user_id: number
  user_name?: string | null
  user_email?: string | null
  role: "executor" | "controller" | "manager"
  is_active: boolean
}

export interface ProjectAccessUser {
  user_id: number
  user_name?: string | null
  user_email?: string | null
  role_key: "reader" | "contributor" | "project_admin"
  role_title: string
  is_active: boolean
}

export interface ProjectAccessGroup {
  group_id: number
  group_name?: string | null
  organization_id?: number | null
  role_key: "reader" | "contributor" | "project_admin"
  role_title: string
  is_active: boolean
}

export interface ProjectWall {
  project: Project
  calendar: CalendarViewResponse
  participants: Array<{
    user_id?: number | null
    user_name: string
    tasks_count: number
  }>
  groups: Array<{
    group_id: number
    group_name?: string | null
    organization_id?: number | null
    role_key: "reader" | "contributor" | "project_admin"
    role_title: string
  }>
}

export interface ProjectDepartmentLink {
  department_id: number
  department_name?: string | null
}

export interface WorkBlock {
  id: number
  name: string
  code?: string | null
  description?: string | null
  departments_count: number
  projects_count: number
  managers_count: number
  created_at: string
  updated_at: string
}

export interface Organization {
  id: number
  name: string
  code?: string | null
  description?: string | null
  groups_count: number
  projects_count: number
  managers_count: number
  created_at: string
  updated_at: string
}

export interface OrganizationGroup {
  id: number
  organization_id?: number | null
  name: string
  code?: string | null
  description?: string | null
}

export interface OrganizationGroupMember {
  user_id: number
  user_name?: string | null
  user_email?: string | null
  is_active: boolean
}

export interface BlockDepartmentLink {
  department_id: number
  department_name?: string | null
}

export interface BlockProjectLink {
  project_id: number
  project_name?: string | null
}

export interface BlockManagerLink {
  user_id: number
  user_name?: string | null
  is_active: boolean
}

export interface Task {
  id: number
  title: string
  description: string
  project_id: number
  project_name?: string | null
  assignee_id?: number | null
  assignee_name?: string | null
  department_name?: string | null
  creator_id: number
  controller_id?: number | null
  controller_name?: string | null
  due_date: string
  workflow_status_id: number
  workflow_status_name?: string | null
  status_name?: string | null
  computed_deadline_state: TaskDeadlineState
  deadline_state?: TaskDeadlineState | null
  computed_urgency_state: TaskUrgencyState
  is_overdue: boolean
  closed_overdue?: boolean
  last_activity_at?: string | null
  last_activity_by?: string | null
  created_at: string
  updated_at: string
  closed_at?: string | null
}

export interface TaskComment {
  id: number
  task_id: number
  author_id: number
  comment: string
  created_at: string
  updated_at: string
}

export interface TaskAttachment {
  id: number
  task_id: number
  uploaded_by_id: number
  file_name: string
  object_key: string
  content_type?: string | null
  size_bytes: number
  created_at: string
}

export interface TaskHistory {
  id: number
  task_id: number
  actor_id: number
  action: string
  field_name?: string | null
  old_value?: string | null
  new_value?: string | null
  created_at: string
}

export interface DashboardSummary {
  total_tasks: number
  deadline_in_time_count: number
  deadline_overdue_count: number
  closed_in_time_count: number
  closed_overdue_count: number
  top_executors: Array<{
    user_id: number
    user_name: string
    count: number
  }>
  top_overdue_executors: Array<{
    user_id: number
    user_name: string
    count: number
  }>
}

export interface DashboardDistributions {
  statuses: Array<{
    status_id: number
    status_name: string
    status_code?: string | null
    count: number
  }>
  departments: Array<{
    department_id?: number | null
    department_name: string
    count: number
  }>
  projects: Array<{
    project_id: number
    project_name: string
    count: number
  }>
}

export interface DashboardTrendPoint {
  bucket_start: string
  total_tasks: number
  in_time_tasks: number
  overdue_tasks: number
  closed_tasks: number
  closed_in_time_tasks: number
}

export interface DashboardTrends {
  period: "day" | "week" | "month"
  date_from: string
  date_to: string
  data: DashboardTrendPoint[]
}

export type DesktopEventType =
  | "assign"
  | "due_soon"
  | "overdue"
  | "status_changed"
  | "close_requested"
  | "close_approved"
  | "comment_added"
  | "system"

export interface DesktopEvent {
  id: number
  user_id: number
  task_id?: number | null
  project_id?: number | null
  event_type: DesktopEventType
  title: string
  message: string
  deeplink?: string | null
  payload_json?: string | null
  created_at: string
}

export interface DesktopEventsPoll {
  data: DesktopEvent[]
  next_cursor?: number | null
  has_more: boolean
  server_time: string
}

export interface CalendarDaySummary {
  day: string
  total_count: number
  overdue_count: number
  in_time_count: number
  closed_count: number
  day_state: "red" | "neutral"
  max_deadline_state: TaskDeadlineState
}

export interface CalendarDayTask {
  id: number
  title: string
  project_id: number
  project_name?: string | null
  assignee_id?: number | null
  assignee_name?: string | null
  department_name?: string | null
  controller_id?: number | null
  controller_name?: string | null
  workflow_status_id: number
  status_name?: string | null
  due_date: string
  computed_deadline_state: TaskDeadlineState
  is_overdue: boolean
  closed_overdue: boolean
  closed_at?: string | null
  updated_at: string
}

export interface CalendarDayDrilldown {
  day: string
  data: CalendarDayTask[]
  count: number
}

export type CalendarViewMode = "day" | "week" | "month"
export type CalendarScope = "project" | "my"

export interface CalendarViewBucket {
  day: string
  total_count: number
  overdue_count: number
  in_time_count: number
  closed_count: number
  tasks: CalendarDayTask[]
}

export interface CalendarViewResponse {
  mode: CalendarViewMode
  scope: CalendarScope
  date_from: string
  date_to: string
  project_id?: number | null
  data: CalendarViewBucket[]
}

export interface ReportTaskRow {
  task_id: number
  title: string
  project_name: string
  assignee_name: string | null
  department_name: string
  status_name: string
  due_date: string
  is_overdue: boolean
  closed_at?: string | null
  closed_overdue: boolean
  days_overdue: number
}

export interface DisciplineRow {
  department_name: string
  project_name: string
  assignee_name: string
  task_title: string
  due_date: string
  closed_at?: string | null
  days_overdue: number
}

export interface DemoDataCredential {
  email: string
  full_name?: string | null
  system_role:
    | "user"
    | "system_admin"
    | "executor"
    | "controller"
    | "manager"
    | "admin"
  department_name?: string | null
  password: string
}

export interface DemoDataSummary {
  enabled: boolean
  marker: string
  users_count: number
  departments_count: number
  projects_count: number
  tasks_count: number
  credentials: DemoDataCredential[]
}
