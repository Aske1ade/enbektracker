from typing import Literal

from sqlmodel import SQLModel


class AdminDesktopEventsTestRequest(SQLModel):
    mode: Literal["single", "full"] = "full"


class AdminDesktopEventsTestResponse(SQLModel):
    user_id: int
    mode: Literal["single", "full"]
    created_count: int
    event_ids: list[int]
