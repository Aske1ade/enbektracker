from sqlmodel import SQLModel

from app.models.enums import SystemRole


class DemoDataCredential(SQLModel):
    email: str
    full_name: str | None = None
    system_role: SystemRole
    department_name: str | None = None
    password: str


class DemoDataSummary(SQLModel):
    enabled: bool
    marker: str
    users_count: int
    departments_count: int
    projects_count: int
    tasks_count: int
    credentials: list[DemoDataCredential]


class DemoDataToggleRequest(SQLModel):
    enabled: bool
