from datetime import datetime

from sqlmodel import SQLModel


class OrganizationCreate(SQLModel):
    name: str
    code: str | None = None
    description: str | None = None


class OrganizationUpdate(SQLModel):
    name: str | None = None
    code: str | None = None
    description: str | None = None


class OrganizationPublic(SQLModel):
    id: int
    name: str
    code: str | None = None
    description: str | None = None
    groups_count: int = 0
    projects_count: int = 0
    managers_count: int = 0
    created_at: datetime
    updated_at: datetime


class OrganizationsPublic(SQLModel):
    data: list[OrganizationPublic]
    count: int


class GroupCreate(SQLModel):
    name: str
    code: str | None = None
    description: str | None = None


class GroupPublic(SQLModel):
    id: int
    organization_id: int | None = None
    name: str
    code: str | None = None
    description: str | None = None


class GroupsPublic(SQLModel):
    data: list[GroupPublic]
    count: int


class GroupMemberPublic(SQLModel):
    user_id: int
    user_name: str | None = None
    user_email: str | None = None
    is_active: bool


class GroupMembersPublic(SQLModel):
    data: list[GroupMemberPublic]
    count: int


class GroupMemberAssign(SQLModel):
    user_id: int
