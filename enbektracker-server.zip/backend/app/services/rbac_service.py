from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlmodel import Session, select

from app.core.permissions import ALL_PERMISSION_KEYS
from app.models import (
    GroupMembership,
    OrgGroup,
    Permission,
    Project,
    ProjectAccessSubjectType,
    ProjectMember,
    ProjectMemberRole,
    ProjectSubjectRole,
    Role,
    RolePermission,
    SystemRole,
    User,
    WorkBlockManager,
    WorkBlockProject,
)
from app.repositories import projects as project_repo


LEGACY_PROJECT_MEMBER_TO_ROLE_KEY: dict[ProjectMemberRole, str] = {
    ProjectMemberRole.EXECUTOR: "reader",
    ProjectMemberRole.CONTROLLER: "project_admin",
    ProjectMemberRole.MANAGER: "project_admin",
}


def canonical_system_role(user: User) -> SystemRole:
    if user.is_superuser:
        return SystemRole.SYSTEM_ADMIN
    if user.system_role in {
        SystemRole.SYSTEM_ADMIN,
        SystemRole.ADMIN,
        SystemRole.MANAGER,
    }:
        return SystemRole.SYSTEM_ADMIN
    return SystemRole.USER


def is_system_admin(user: User) -> bool:
    return canonical_system_role(user) == SystemRole.SYSTEM_ADMIN


def require_system_admin(user: User) -> None:
    if not is_system_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="System admin role required",
        )


def require_manager(user: User) -> None:
    require_system_admin(user)


def require_controller(user: User) -> None:
    require_system_admin(user)


def get_project_membership(
    session: Session,
    *,
    project_id: int,
    user_id: int,
) -> ProjectMember | None:
    return project_repo.get_project_member(session, project_id=project_id, user_id=user_id)


def _get_user_group_ids(session: Session, *, user: User) -> set[int]:
    group_ids = {
        int(group_id)
        for group_id in session.exec(
            select(GroupMembership.group_id).where(
                GroupMembership.user_id == user.id,
                GroupMembership.is_active.is_(True),
            )
        ).all()
    }
    if user.primary_group_id is not None:
        group_ids.add(int(user.primary_group_id))
    if user.department_id is not None:
        legacy_group_id = session.exec(
            select(OrgGroup.id).where(OrgGroup.legacy_department_id == user.department_id)
        ).first()
        if legacy_group_id is not None:
            group_ids.add(int(legacy_group_id))
    return group_ids


def _get_role_id_by_name(session: Session, role_name: str) -> int | None:
    return session.exec(select(Role.id).where(Role.name == role_name)).first()


def _get_project_subject_role_ids_for_user(
    session: Session,
    *,
    user: User,
    project_id: int | None = None,
) -> set[int]:
    group_ids = _get_user_group_ids(session, user=user)

    subject_condition = (
        (ProjectSubjectRole.subject_type == ProjectAccessSubjectType.USER)
        & (ProjectSubjectRole.subject_user_id == user.id)
    )
    if group_ids:
        subject_condition = or_(
            subject_condition,
            (
                (ProjectSubjectRole.subject_type == ProjectAccessSubjectType.GROUP)
                & (ProjectSubjectRole.subject_group_id.in_(sorted(group_ids)))
            ),
        )

    statement = select(ProjectSubjectRole.role_id).where(
        ProjectSubjectRole.is_active.is_(True),
        subject_condition,
    )
    if project_id is not None:
        statement = statement.where(ProjectSubjectRole.project_id == project_id)

    return {int(role_id) for role_id in session.exec(statement).all()}


def _get_project_subject_project_ids_for_user(
    session: Session,
    *,
    user: User,
) -> set[int]:
    group_ids = _get_user_group_ids(session, user=user)
    subject_condition = (
        (ProjectSubjectRole.subject_type == ProjectAccessSubjectType.USER)
        & (ProjectSubjectRole.subject_user_id == user.id)
    )
    if group_ids:
        subject_condition = or_(
            subject_condition,
            (
                (ProjectSubjectRole.subject_type == ProjectAccessSubjectType.GROUP)
                & (ProjectSubjectRole.subject_group_id.in_(sorted(group_ids)))
            ),
        )

    return {
        int(project_id)
        for project_id in session.exec(
            select(ProjectSubjectRole.project_id).where(
                ProjectSubjectRole.is_active.is_(True),
                subject_condition,
            )
        ).all()
    }


def _get_legacy_project_ids(session: Session, *, user: User) -> set[int]:
    membership_project_ids = {
        int(project_id)
        for project_id in session.exec(
            select(ProjectMember.project_id).where(
                ProjectMember.user_id == user.id,
                ProjectMember.is_active.is_(True),
            )
        ).all()
    }
    block_project_ids = {
        int(project_id)
        for project_id in session.exec(
            select(WorkBlockProject.project_id)
            .join(WorkBlockManager, WorkBlockManager.block_id == WorkBlockProject.block_id)
            .where(
                WorkBlockManager.user_id == user.id,
                WorkBlockManager.is_active.is_(True),
            )
        ).all()
    }
    return membership_project_ids | block_project_ids


def _get_legacy_role_ids_for_project(
    session: Session,
    *,
    project_id: int,
    user: User,
) -> set[int]:
    role_ids: set[int] = set()
    membership = get_project_membership(session, project_id=project_id, user_id=user.id)
    if membership is not None and membership.is_active:
        role_key = LEGACY_PROJECT_MEMBER_TO_ROLE_KEY.get(membership.role)
        if role_key is not None:
            role_id = _get_role_id_by_name(session, role_key)
            if role_id is not None:
                role_ids.add(role_id)

    manager_exists = session.exec(
        select(WorkBlockProject.id)
        .join(WorkBlockManager, WorkBlockManager.block_id == WorkBlockProject.block_id)
        .where(
            WorkBlockProject.project_id == project_id,
            WorkBlockManager.user_id == user.id,
            WorkBlockManager.is_active.is_(True),
        )
        .limit(1)
    ).first()
    if manager_exists is not None:
        role_id = _get_role_id_by_name(session, "project_admin")
        if role_id is not None:
            role_ids.add(role_id)

    return role_ids


def get_permission_keys_for_user(
    session: Session,
    *,
    user: User,
    project_id: int | None = None,
) -> set[str]:
    if is_system_admin(user):
        return set(ALL_PERMISSION_KEYS)

    role_ids = _get_project_subject_role_ids_for_user(session, user=user, project_id=project_id)
    if project_id is not None:
        role_ids |= _get_legacy_role_ids_for_project(
            session,
            project_id=project_id,
            user=user,
        )

    if not role_ids:
        return {"update_self"} if project_id is None else set()

    rows = session.exec(
        select(Permission.key)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .where(RolePermission.role_id.in_(sorted(role_ids)))
    ).all()
    permissions = {str(key) for key in rows}
    if project_id is None:
        permissions.add("update_self")
    return permissions


def has_permission(
    session: Session,
    *,
    user: User,
    permission_key: str,
    project_id: int | None = None,
) -> bool:
    return permission_key in get_permission_keys_for_user(
        session,
        user=user,
        project_id=project_id,
    )


def require_permission(
    session: Session,
    *,
    user: User,
    permission_key: str,
    project_id: int | None = None,
    detail: str | None = None,
) -> None:
    if has_permission(
        session,
        user=user,
        permission_key=permission_key,
        project_id=project_id,
    ):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=detail or "Not enough permissions",
    )


def can_view_project(session: Session, *, project_id: int, user: User) -> bool:
    if is_system_admin(user):
        return True
    if project_id in get_accessible_project_ids(
        session,
        user=user,
        project_ids={project_id},
    ):
        return True
    return has_permission(
        session,
        user=user,
        permission_key="read_project_basic",
        project_id=project_id,
    ) or has_permission(
        session,
        user=user,
        permission_key="issue_read",
        project_id=project_id,
    )


def get_accessible_project_ids(
    session: Session,
    *,
    user: User,
    project_ids: set[int] | None = None,
) -> set[int]:
    # Product decision: every active user can view every project.
    # Write operations are still restricted by role/permission checks.
    all_ids = {int(project_id) for project_id in session.exec(select(Project.id)).all()}
    if project_ids is None:
        return all_ids
    return all_ids & set(project_ids)


def require_project_access(session: Session, *, project_id: int, user: User) -> None:
    if can_view_project(session, project_id=project_id, user=user):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="No access to the project",
    )


def require_project_manager(session: Session, *, project_id: int, user: User) -> None:
    require_permission(
        session,
        user=user,
        permission_key="update_project",
        project_id=project_id,
        detail="Insufficient role in project",
    )


def require_project_controller_or_manager(
    session: Session,
    *,
    project_id: int,
    user: User,
) -> None:
    if has_permission(
        session,
        user=user,
        permission_key="task_update",
        project_id=project_id,
    ) or has_permission(
        session,
        user=user,
        permission_key="update_project",
        project_id=project_id,
    ):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Insufficient role in project",
    )


def require_project_executor_scope(
    session: Session,
    *,
    project_id: int,
    user: User,
) -> None:
    if has_permission(
        session,
        user=user,
        permission_key="issue_read",
        project_id=project_id,
    ) or has_permission(
        session,
        user=user,
        permission_key="task_update",
        project_id=project_id,
    ):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Insufficient role in project",
    )
