from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlmodel import Session, select

from app.models import (
    DesktopEventType,
    NotificationType,
    Project,
    ProjectStatus,
    Task,
    TaskComment,
    TaskDeadlineState,
    TaskHistoryAction,
    TaskUrgencyState,
    User,
)
from app.repositories import project_statuses as status_repo
from app.repositories import task_attachments as attachment_repo
from app.repositories import task_comments as comment_repo
from app.repositories import tasks as task_repo
from app.services import audit_service, desktop_event_service, notification_service


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def compute_deadline_flags(
    due_date: datetime,
    *,
    normal_days: int,
    yellow_days: int | None = None,
) -> tuple[TaskDeadlineState, TaskUrgencyState, bool]:
    # `yellow_days` is kept for backward compatibility with legacy tests/callers.
    _ = yellow_days
    now = utcnow()
    delta_days = (due_date.date() - now.date()).days

    if delta_days < 0:
        return TaskDeadlineState.RED, TaskUrgencyState.OVERDUE, True

    if delta_days < normal_days:
        return TaskDeadlineState.YELLOW, TaskUrgencyState.CRITICAL, False

    return TaskDeadlineState.GREEN, TaskUrgencyState.RESERVE, False


def refresh_task_computed_fields(task: Task, project: Project) -> None:
    deadline_state, urgency_state, is_overdue = compute_deadline_flags(
        task.due_date,
        normal_days=project.deadline_normal_days,
    )
    task.computed_deadline_state = deadline_state
    task.computed_urgency_state = urgency_state
    task.is_overdue = is_overdue


def _get_final_status(session: Session, project_id: int) -> ProjectStatus:
    status_obj = session.exec(
        select(ProjectStatus)
        .where(ProjectStatus.project_id == project_id, ProjectStatus.is_final)
        .order_by(ProjectStatus.order)
    ).first()
    if not status_obj:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Project has no final status configured",
        )
    return status_obj


def _unique_users(
    users: list[User | None],
    *,
    exclude_user_id: int | None = None,
) -> list[User]:
    result: list[User] = []
    seen_ids: set[int] = set()
    for user in users:
        if user is None or user.id is None:
            continue
        if exclude_user_id is not None and user.id == exclude_user_id:
            continue
        if user.id in seen_ids:
            continue
        seen_ids.add(user.id)
        result.append(user)
    return result


def _task_participants(session: Session, task: Task) -> list[User]:
    creator = session.get(User, task.creator_id)
    assignee = session.get(User, task.assignee_id) if task.assignee_id else None
    controller = session.get(User, task.controller_id) if task.controller_id else None
    return _unique_users([creator, assignee, controller])


def _emit_assignment_event(session: Session, *, task: Task, assignee: User) -> None:
    desktop_event_service.enqueue_task_event(
        session,
        user_id=assignee.id,
        event_type=DesktopEventType.ASSIGN,
        task=task,
        title="Назначена задача",
        message=f"Вам назначена задача '{task.title}'",
        payload={"task_id": task.id, "project_id": task.project_id},
        dedupe_key=f"task:{task.id}:assign:{assignee.id}",
    )


def _emit_due_window_events(
    session: Session,
    *,
    task: Task,
    assignee_id: int,
    previous_due_soon: bool,
    previous_overdue: bool,
) -> None:
    assignee = session.get(User, assignee_id)
    if not assignee:
        return

    due_soon = not task.is_overdue and desktop_event_service.is_due_soon(task.due_date)
    if due_soon and not previous_due_soon:
        desktop_event_service.enqueue_task_event(
            session,
            user_id=assignee.id,
            event_type=DesktopEventType.DUE_SOON,
            task=task,
            title="Срок задачи скоро наступит",
            message=f"Задача '{task.title}' скоро просрочится",
            payload={"task_id": task.id, "due_date": task.due_date.isoformat()},
            dedupe_key=f"task:{task.id}:due_soon:{task.due_date.date().isoformat()}",
        )

    if task.is_overdue and not previous_overdue:
        desktop_event_service.enqueue_task_event(
            session,
            user_id=assignee.id,
            event_type=DesktopEventType.OVERDUE,
            task=task,
            title="Задача просрочена",
            message=f"Задача '{task.title}' просрочена",
            payload={"task_id": task.id, "due_date": task.due_date.isoformat()},
            dedupe_key=f"task:{task.id}:overdue:{task.due_date.date().isoformat()}",
        )


def _emit_status_changed_events(
    session: Session,
    *,
    task: Task,
    actor: User,
    old_status_id: int,
    new_status_id: int,
    new_status_name: str | None,
) -> None:
    status_label = new_status_name or str(new_status_id)
    participants = _task_participants(session, task)
    recipients = _unique_users(participants, exclude_user_id=actor.id)
    for user in recipients:
        desktop_event_service.enqueue_task_event(
            session,
            user_id=user.id,
            event_type=DesktopEventType.STATUS_CHANGED,
            task=task,
            title="Статус задачи изменен",
            message=f"Статус задачи '{task.title}' изменен на {status_label}",
            payload={
                "task_id": task.id,
                "old_status_id": old_status_id,
                "new_status_id": new_status_id,
            },
            dedupe_key=f"task:{task.id}:status:{old_status_id}:{new_status_id}:{user.id}",
        )


def _emit_close_events(session: Session, *, task: Task, actor: User) -> None:
    participants = _task_participants(session, task)
    recipients = _unique_users(participants, exclude_user_id=actor.id)
    for user in recipients:
        desktop_event_service.enqueue_task_event(
            session,
            user_id=user.id,
            event_type=DesktopEventType.CLOSE_REQUESTED,
            task=task,
            title="Запрошено закрытие задачи",
            message=f"Запрошено закрытие задачи '{task.title}' пользователем {actor.email}",
            payload={"task_id": task.id, "actor_id": actor.id},
            dedupe_key=f"task:{task.id}:close_requested:{user.id}",
        )
        desktop_event_service.enqueue_task_event(
            session,
            user_id=user.id,
            event_type=DesktopEventType.CLOSE_APPROVED,
            task=task,
            title="Задача закрыта",
            message=f"Задача '{task.title}' была закрыта пользователем {actor.email}",
            payload={"task_id": task.id, "actor_id": actor.id},
            dedupe_key=f"task:{task.id}:close_approved:{user.id}",
        )


def create_task(
    session: Session,
    *,
    project: Project,
    creator: User,
    title: str,
    description: str,
    assignee_id: int | None,
    controller_id: int | None,
    due_date: datetime,
    workflow_status_id: int,
) -> Task:
    task = Task(
        title=title,
        description=description,
        project_id=project.id,
        creator_id=creator.id,
        assignee_id=assignee_id,
        controller_id=controller_id,
        due_date=due_date,
        workflow_status_id=workflow_status_id,
    )
    refresh_task_computed_fields(task, project)
    created = task_repo.create_task(session, task)

    audit_service.add_task_history(
        session,
        task_id=created.id,
        actor_id=creator.id,
        action=TaskHistoryAction.CREATED,
        new_value=f"Task {created.title} created",
    )

    if assignee_id:
        assignee = session.get(User, assignee_id)
        if assignee:
            notification_service.notify_user(
                session,
                user_id=assignee.id,
                notification_type=NotificationType.TASK_ASSIGNED,
                title="Назначена задача",
                message=f"Вам назначена задача: {created.title}",
                payload={"task_id": created.id, "project_id": created.project_id},
                user_email=assignee.email,
            )
            _emit_assignment_event(session, task=created, assignee=assignee)
            _emit_due_window_events(
                session,
                task=created,
                assignee_id=assignee.id,
                previous_due_soon=False,
                previous_overdue=False,
            )

    return created


def update_task(
    session: Session,
    *,
    task: Task,
    actor: User,
    project: Project,
    title: str | None = None,
    description: str | None = None,
    assignee_id: int | None = None,
    controller_id: int | None = None,
    due_date: datetime | None = None,
    workflow_status_id: int | None = None,
) -> Task:
    old_assignee_id = task.assignee_id
    old_due_date = task.due_date
    old_status_id = task.workflow_status_id
    old_is_overdue = task.is_overdue
    old_due_soon = (not old_is_overdue) and desktop_event_service.is_due_soon(task.due_date)

    if title is not None:
        task.title = title
    if description is not None:
        task.description = description
    if assignee_id is not None:
        task.assignee_id = assignee_id
    if controller_id is not None:
        task.controller_id = controller_id
    if due_date is not None:
        task.due_date = due_date
    if workflow_status_id is not None:
        task.workflow_status_id = workflow_status_id

    task.updated_at = utcnow()

    refresh_task_computed_fields(task, project)

    updated = task_repo.update_task(session, task)

    audit_service.add_task_history(
        session,
        task_id=updated.id,
        actor_id=actor.id,
        action=TaskHistoryAction.UPDATED,
        new_value="Task updated",
    )

    if old_due_date != updated.due_date:
        audit_service.add_task_history(
            session,
            task_id=updated.id,
            actor_id=actor.id,
            action=TaskHistoryAction.DUE_DATE_CHANGED,
            field_name="due_date",
            old_value=str(old_due_date),
            new_value=str(updated.due_date),
        )

        if updated.assignee_id:
            assignee = session.get(User, updated.assignee_id)
            if assignee:
                notification_service.notify_user(
                    session,
                    user_id=assignee.id,
                    notification_type=NotificationType.TASK_DUE_DATE_CHANGED,
                    title="Изменен срок задачи",
                    message=f"Изменен срок задачи: {updated.title}",
                    payload={"task_id": updated.id},
                    user_email=assignee.email,
                )

    if old_status_id != updated.workflow_status_id:
        status_obj = session.get(ProjectStatus, updated.workflow_status_id)
        audit_service.add_task_history(
            session,
            task_id=updated.id,
            actor_id=actor.id,
            action=TaskHistoryAction.STATUS_CHANGED,
            field_name="workflow_status_id",
            old_value=str(old_status_id),
            new_value=str(updated.workflow_status_id),
        )
        if status_obj and status_obj.is_final:
            updated.closed_at = utcnow()
            updated = task_repo.update_task(session, updated)
        _emit_status_changed_events(
            session,
            task=updated,
            actor=actor,
            old_status_id=old_status_id,
            new_status_id=updated.workflow_status_id,
            new_status_name=status_obj.name if status_obj else None,
        )

    if old_assignee_id != updated.assignee_id and updated.assignee_id:
        audit_service.add_task_history(
            session,
            task_id=updated.id,
            actor_id=actor.id,
            action=TaskHistoryAction.ASSIGNEE_CHANGED,
            field_name="assignee_id",
            old_value=str(old_assignee_id),
            new_value=str(updated.assignee_id),
        )
        assignee = session.get(User, updated.assignee_id)
        if assignee:
            notification_service.notify_user(
                session,
                user_id=assignee.id,
                notification_type=NotificationType.TASK_ASSIGNED,
                title="Назначена задача",
                message=f"Вам назначена задача: {updated.title}",
                payload={"task_id": updated.id},
                user_email=assignee.email,
            )
            _emit_assignment_event(session, task=updated, assignee=assignee)

    if updated.assignee_id:
        previous_due_soon = old_due_soon if old_assignee_id == updated.assignee_id else False
        previous_overdue = old_is_overdue if old_assignee_id == updated.assignee_id else False
        _emit_due_window_events(
            session,
            task=updated,
            assignee_id=updated.assignee_id,
            previous_due_soon=previous_due_soon,
            previous_overdue=previous_overdue,
        )

    return updated


def close_task(
    session: Session,
    *,
    task: Task,
    actor: User,
    project: Project,
    close_comment: str | None,
    attachment_ids: list[int],
) -> Task:
    if project.require_close_comment and not close_comment:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Close comment is required for this project",
        )

    if project.require_close_attachment:
        if not attachment_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Attachment is required for this project",
            )

        for attachment_id in attachment_ids:
            attachment = attachment_repo.get_task_attachment(session, attachment_id)
            if not attachment or attachment.task_id != task.id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Attachment {attachment_id} does not belong to task",
                )

    final_status = _get_final_status(session, task.project_id)

    task.workflow_status_id = final_status.id
    task.closed_at = utcnow()
    task.updated_at = utcnow()
    refresh_task_computed_fields(task, project)

    updated = task_repo.update_task(session, task)

    audit_service.add_task_history(
        session,
        task_id=updated.id,
        actor_id=actor.id,
        action=TaskHistoryAction.CLOSED,
        new_value="Task closed",
    )

    if close_comment:
        comment_obj = TaskComment(task_id=updated.id, author_id=actor.id, comment=close_comment)
        comment_repo.create_task_comment(session, comment_obj)
        audit_service.add_task_history(
            session,
            task_id=updated.id,
            actor_id=actor.id,
            action=TaskHistoryAction.COMMENT_ADDED,
            new_value=close_comment,
        )

    recipients: list[User] = []
    creator = session.get(User, updated.creator_id)
    assignee = session.get(User, updated.assignee_id) if updated.assignee_id else None
    controller = session.get(User, updated.controller_id) if updated.controller_id else None

    for user in [creator, assignee, controller]:
        if user and user.id != actor.id:
            recipients.append(user)

    for user in recipients:
        notification_service.notify_user(
            session,
            user_id=user.id,
            notification_type=NotificationType.TASK_STATUS_CHANGED,
            title="Задача закрыта",
            message=f"Задача '{updated.title}' закрыта пользователем {actor.email}",
            payload={"task_id": updated.id},
            user_email=user.email,
        )

    _emit_close_events(session, task=updated, actor=actor)

    return updated


def add_task_comment(
    session: Session,
    *,
    task: Task,
    actor: User,
    comment: str,
) -> TaskComment:
    comment_obj = TaskComment(task_id=task.id, author_id=actor.id, comment=comment)
    created = comment_repo.create_task_comment(session, comment_obj)

    audit_service.add_task_history(
        session,
        task_id=task.id,
        actor_id=actor.id,
        action=TaskHistoryAction.COMMENT_ADDED,
        new_value=comment,
    )

    if task.assignee_id and task.assignee_id != actor.id:
        assignee = session.get(User, task.assignee_id)
        if assignee:
            notification_service.notify_user(
                session,
                user_id=assignee.id,
                notification_type=NotificationType.TASK_COMMENTED,
                title="Новый комментарий к задаче",
                message=f"Новый комментарий в задаче: {task.title}",
                payload={"task_id": task.id},
                user_email=assignee.email,
            )

    return created


def refresh_deadline_flags_for_open_tasks(session: Session) -> int:
    rows = session.exec(
        select(Task, Project).join(Project, Project.id == Task.project_id).where(Task.closed_at.is_(None))
    ).all()
    updated_count = 0

    for task, project in rows:
        before = (
            task.computed_deadline_state,
            task.computed_urgency_state,
            task.is_overdue,
        )
        refresh_task_computed_fields(task, project)
        after = (
            task.computed_deadline_state,
            task.computed_urgency_state,
            task.is_overdue,
        )
        if before != after:
            task.updated_at = utcnow()
            session.add(task)
            updated_count += 1

    if updated_count:
        session.commit()

    return updated_count
