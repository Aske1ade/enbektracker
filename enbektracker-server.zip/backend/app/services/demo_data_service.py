from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, delete, select

from app import crud
from app.models import (
    Department,
    DemoSeedEntity,
    DesktopEvent,
    Item,
    Notification,
    Project,
    ProjectDepartment,
    ProjectMember,
    ProjectMemberRole,
    ProjectStatus,
    Task,
    TaskAttachment,
    TaskComment,
    TaskHistory,
    User,
    UserCreate,
    WorkBlock,
    WorkBlockDepartment,
    WorkBlockManager,
    WorkBlockProject,
)
from app.repositories import project_statuses as status_repo
from app.repositories import projects as project_repo
from app.schemas.demo_data import DemoDataCredential, DemoDataSummary
from app.services import project_service, task_service

DEMO_MARKER = "demo-batch"
DEMO_USER_PASSWORD = "DemoPass123!"

DEMO_DEPARTMENTS = [
    ("ANL", "Аналитика и контроль"),
    ("DIG", "Цифровая трансформация"),
    ("SUP", "Социальная поддержка"),
]

DEMO_USERS = [
    ("manager_main", "Руководитель демо", "system_admin", "ANL"),
    ("controller_main", "Контролер демо", "user", "ANL"),
    ("executor_1", "Исполнитель 1", "user", "ANL"),
    ("executor_2", "Исполнитель 2", "user", "DIG"),
    ("executor_3", "Исполнитель 3", "user", "DIG"),
    ("executor_4", "Исполнитель 4", "user", "SUP"),
    ("manager_support", "Руководитель департамента", "user", "SUP"),
]

DEMO_BLOCKS = [
    ("BL_ANL", "Блок аналитики", "ANL"),
    ("BL_DIG", "Блок цифровых сервисов", "DIG"),
]

DEMO_PROJECTS = [
    ("PAYMENTS", "Мониторинг социальных выплат", "ANL", "BL_ANL"),
    ("EMPLOYMENT", "Контроль проектов занятости", "DIG", "BL_DIG"),
    ("DISCIPLINE", "Исполнительская дисциплина", "SUP", "BL_ANL"),
]

DEMO_TASK_TEMPLATES = [
    {
        "title": "Сформировать план работ",
        "description": "<p><b>План работ</b> согласовать с департаментом.</p><ul><li>Подготовить этапы</li><li>Определить сроки</li></ul>",
        "due_delta_days": 9,
        "status_code": "new",
        "assignee_key": "executor_1",
        "controller_key": "controller_main",
        "comment": "План готов к согласованию.",
        "close": False,
    },
    {
        "title": "Проверить просроченные задачи",
        "description": "<p>Провести анализ просрочек и подготовить список рисков.</p>",
        "due_delta_days": -2,
        "status_code": "in_progress",
        "assignee_key": "executor_2",
        "controller_key": "controller_main",
        "comment": "Есть 4 критичные просрочки.",
        "close": False,
    },
    {
        "title": "Синхронизировать статусы проекта",
        "description": "<p>Обновить workflow статусы и уведомления.</p>",
        "due_delta_days": 2,
        "status_code": "in_progress",
        "assignee_key": "executor_3",
        "controller_key": "controller_main",
        "comment": "Статусы согласованы с командой.",
        "close": False,
    },
    {
        "title": "Интеграция внешних данных",
        "description": "<p>Проверить интеграцию и устранить блокеры.</p>",
        "due_delta_days": -4,
        "status_code": "blocked",
        "assignee_key": "executor_2",
        "controller_key": "controller_main",
        "comment": "Ожидаем доступ от внешней системы.",
        "close": False,
    },
    {
        "title": "Закрыть релизный пакет",
        "description": "<p>Финальная проверка релизного пакета и закрытие задачи.</p>",
        "due_delta_days": 0,
        "status_code": "done",
        "assignee_key": "executor_1",
        "controller_key": "controller_main",
        "comment": "Релиз принят и закрыт.",
        "close": True,
    },
]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _latest_batch_id(session: Session) -> str | None:
    return session.exec(
        select(DemoSeedEntity.batch_id)
        .order_by(DemoSeedEntity.created_at.desc(), DemoSeedEntity.id.desc())
        .limit(1)
    ).first()


def _batch_entity_ids(session: Session, *, batch_id: str) -> dict[str, list[int]]:
    rows = session.exec(
        select(DemoSeedEntity.entity_type, DemoSeedEntity.entity_id).where(
            DemoSeedEntity.batch_id == batch_id
        )
    ).all()
    result: dict[str, list[int]] = {}
    for entity_type, entity_id in rows:
        result.setdefault(entity_type, []).append(entity_id)
    return result


def _register_entity(
    session: Session,
    *,
    batch_id: str,
    entity_type: str,
    entity_id: int,
) -> None:
    session.add(
        DemoSeedEntity(
            batch_id=batch_id,
            entity_type=entity_type,
            entity_id=entity_id,
        )
    )


def _status_map(session: Session, project_id: int) -> dict[str, ProjectStatus]:
    statuses, _ = status_repo.list_project_statuses(session, project_id=project_id, limit=100)
    return {status_obj.code or "": status_obj for status_obj in statuses}


def _demo_summary(session: Session) -> DemoDataSummary:
    batch_id = _latest_batch_id(session)
    if batch_id is None:
        return DemoDataSummary(
            enabled=False,
            marker=DEMO_MARKER,
            users_count=0,
            departments_count=0,
            projects_count=0,
            tasks_count=0,
            credentials=[],
        )
    ids = _batch_entity_ids(session, batch_id=batch_id)
    user_ids = ids.get("user", [])
    department_ids = ids.get("department", [])
    users = []
    if user_ids:
        users = session.exec(select(User).where(User.id.in_(sorted(set(user_ids))))).all()
    department_name_map = {}
    if department_ids:
        department_name_map = {
            row[0]: row[1]
            for row in session.exec(
                select(Department.id, Department.name).where(
                    Department.id.in_(sorted(set(department_ids)))
                )
            ).all()
        }
    credentials = [
        DemoDataCredential(
            email=user.email,
            full_name=user.full_name,
            system_role=user.system_role,
            department_name=department_name_map.get(user.department_id),
            password=DEMO_USER_PASSWORD,
        )
        for user in sorted(users, key=lambda item: item.email)
    ]
    return DemoDataSummary(
        enabled=True,
        marker=batch_id,
        users_count=len(set(ids.get("user", []))),
        departments_count=len(set(ids.get("department", []))),
        projects_count=len(set(ids.get("project", []))),
        tasks_count=len(set(ids.get("task", []))),
        credentials=credentials,
    )


def clear_demo_data(session: Session) -> DemoDataSummary:
    batch_id = _latest_batch_id(session)
    if batch_id is None:
        return _demo_summary(session)

    ids = _batch_entity_ids(session, batch_id=batch_id)
    task_ids = sorted(set(ids.get("task", [])))
    project_ids = sorted(set(ids.get("project", [])))
    user_ids = sorted(set(ids.get("user", [])))
    department_ids = sorted(set(ids.get("department", [])))
    block_ids = sorted(set(ids.get("block", [])))

    desktop_filters = []
    if task_ids:
        desktop_filters.append(DesktopEvent.task_id.in_(task_ids))
    if project_ids:
        desktop_filters.append(DesktopEvent.project_id.in_(project_ids))
    if user_ids:
        desktop_filters.append(DesktopEvent.user_id.in_(user_ids))
    if desktop_filters:
        condition = desktop_filters[0]
        for item in desktop_filters[1:]:
            condition = condition | item
        session.exec(delete(DesktopEvent).where(condition))

    if user_ids:
        session.exec(delete(Notification).where(Notification.user_id.in_(user_ids)))
        session.exec(delete(Item).where(Item.owner_id.in_(user_ids)))

    if task_ids:
        session.exec(delete(TaskHistory).where(TaskHistory.task_id.in_(task_ids)))
        session.exec(delete(TaskComment).where(TaskComment.task_id.in_(task_ids)))
        session.exec(delete(TaskAttachment).where(TaskAttachment.task_id.in_(task_ids)))
        session.exec(delete(Task).where(Task.id.in_(task_ids)))

    if project_ids:
        session.exec(delete(ProjectStatus).where(ProjectStatus.project_id.in_(project_ids)))
        session.exec(delete(ProjectMember).where(ProjectMember.project_id.in_(project_ids)))
        session.exec(delete(ProjectDepartment).where(ProjectDepartment.project_id.in_(project_ids)))
        session.exec(delete(WorkBlockProject).where(WorkBlockProject.project_id.in_(project_ids)))
        session.exec(delete(Project).where(Project.id.in_(project_ids)))

    if block_ids:
        session.exec(delete(WorkBlockDepartment).where(WorkBlockDepartment.block_id.in_(block_ids)))
        session.exec(delete(WorkBlockManager).where(WorkBlockManager.block_id.in_(block_ids)))
        session.exec(delete(WorkBlock).where(WorkBlock.id.in_(block_ids)))

    if user_ids:
        session.exec(delete(User).where(User.id.in_(user_ids)))

    if department_ids:
        session.exec(delete(WorkBlockDepartment).where(WorkBlockDepartment.department_id.in_(department_ids)))
        session.exec(delete(WorkBlockManager).where(WorkBlockManager.user_id.in_(user_ids)))
        session.exec(delete(Department).where(Department.id.in_(department_ids)))

    session.exec(delete(DemoSeedEntity).where(DemoSeedEntity.batch_id == batch_id))

    session.commit()
    return _demo_summary(session)


def populate_demo_data(session: Session, actor: User) -> DemoDataSummary:
    clear_demo_data(session)
    batch_id = f"{DEMO_MARKER}-{uuid4().hex[:8]}"

    departments_by_key = {}
    users_by_key = {}
    blocks_by_key = {}

    try:
        for dep_code, dep_name in DEMO_DEPARTMENTS:
            department = Department(
                name=dep_name,
                code=f"DEP-{dep_code}-{batch_id[-4:]}",
                description="Тестовый департамент",
            )
            session.add(department)
            session.flush()
            departments_by_key[dep_code] = department
            _register_entity(
                session,
                batch_id=batch_id,
                entity_type="department",
                entity_id=department.id,
            )

        for block_code, block_name, department_key in DEMO_BLOCKS:
            block = WorkBlock(
                name=block_name,
                code=f"{block_code}-{batch_id[-4:]}",
                description="Тестовый блок проектов",
            )
            session.add(block)
            session.flush()
            blocks_by_key[block_code] = block
            session.add(
                WorkBlockDepartment(
                    block_id=block.id,
                    department_id=departments_by_key[department_key].id,
                )
            )
            _register_entity(
                session,
                batch_id=batch_id,
                entity_type="block",
                entity_id=block.id,
            )

        for user_key, full_name, system_role, department_key in DEMO_USERS:
            email = f"{user_key}.{batch_id}@enbek.local"
            user = crud.create_user(
                session=session,
                user_create=UserCreate(
                    email=email,
                    password=DEMO_USER_PASSWORD,
                    full_name=full_name,
                    is_active=True,
                    is_superuser=False,
                    system_role=system_role,
                    department_id=departments_by_key[department_key].id,
                ),
            )
            users_by_key[user_key] = user
            _register_entity(
                session,
                batch_id=batch_id,
                entity_type="user",
                entity_id=user.id,
            )

        for block_code, block in blocks_by_key.items():
            manager_key = "manager_main" if block_code == "BL_ANL" else "manager_support"
            session.add(
                WorkBlockManager(
                    block_id=block.id,
                    user_id=users_by_key[manager_key].id,
                    is_active=True,
                )
            )

        for project_index, (_, project_name, department_key, block_key) in enumerate(DEMO_PROJECTS):
            project = project_service.create_project_with_defaults(
                session,
                creator=actor,
                name=project_name,
                description="Тестовый проект для демо",
                organization_id=None,
                department_id=departments_by_key[department_key].id,
                require_close_comment=True,
                require_close_attachment=False,
                deadline_yellow_days=4,
                deadline_normal_days=5,
            )
            _register_entity(
                session,
                batch_id=batch_id,
                entity_type="project",
                entity_id=project.id,
            )
            session.add(WorkBlockProject(block_id=blocks_by_key[block_key].id, project_id=project.id))

            member_specs = [
                ("manager_main", ProjectMemberRole.MANAGER),
                ("controller_main", ProjectMemberRole.CONTROLLER),
                ("executor_1", ProjectMemberRole.EXECUTOR),
                ("executor_2", ProjectMemberRole.EXECUTOR),
                ("executor_3", ProjectMemberRole.EXECUTOR),
                ("executor_4", ProjectMemberRole.EXECUTOR),
                ("manager_support", ProjectMemberRole.MANAGER),
            ]
            for user_key, role in member_specs:
                user = users_by_key[user_key]
                existing = project_repo.get_project_member(
                    session,
                    project_id=project.id,
                    user_id=user.id,
                )
                if existing:
                    continue
                project_repo.create_project_member(
                    session,
                    ProjectMember(
                        project_id=project.id,
                        user_id=user.id,
                        role=role,
                        is_active=True,
                        created_at=utcnow(),
                        updated_at=utcnow(),
                    ),
                )

            statuses = _status_map(session, project.id)
            status_new = statuses.get("new")
            if not status_new:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Demo data setup failed: default status missing",
                )

            for template_index, template in enumerate(DEMO_TASK_TEMPLATES):
                due_date = utcnow() + timedelta(days=template["due_delta_days"] + project_index)
                assignee = users_by_key[template["assignee_key"]]
                controller = users_by_key[template["controller_key"]]
                task = task_service.create_task(
                    session,
                    project=project,
                    creator=actor,
                    title=f"{template['title']} #{project_index + 1}.{template_index + 1}",
                    description=template["description"],
                    assignee_id=assignee.id,
                    controller_id=controller.id,
                    due_date=due_date,
                    workflow_status_id=status_new.id,
                )
                _register_entity(
                    session,
                    batch_id=batch_id,
                    entity_type="task",
                    entity_id=task.id,
                )

                target_status = statuses.get(template["status_code"])
                if target_status and target_status.id != task.workflow_status_id:
                    task = task_service.update_task(
                        session,
                        task=task,
                        actor=controller,
                        project=project,
                        workflow_status_id=target_status.id,
                    )

                task_service.add_task_comment(
                    session,
                    task=task,
                    actor=controller,
                    comment=template["comment"],
                )

                if template["close"]:
                    task_service.close_task(
                        session,
                        task=task,
                        actor=users_by_key["manager_main"],
                        project=project,
                        close_comment="Демо-закрытие задачи",
                        attachment_ids=[],
                    )

        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Demo data creation conflict: {exc.orig}",
        ) from exc

    return _demo_summary(session)


def get_demo_data_summary(session: Session) -> DemoDataSummary:
    return _demo_summary(session)


def set_demo_data_enabled(
    session: Session,
    *,
    actor: User,
    enabled: bool,
) -> DemoDataSummary:
    if enabled:
        return populate_demo_data(session, actor)
    return clear_demo_data(session)
