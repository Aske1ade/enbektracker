from datetime import date, timedelta

from fastapi import APIRouter, HTTPException, Query

from app.api.deps import CurrentUser, SessionDep
from app.schemas.dashboard import DashboardDistributions, DashboardSummary, DashboardTrendsPublic
from app.services import rbac_service
from app.services.dashboard_service import (
    build_dashboard_distributions,
    build_dashboard_summary,
    build_dashboard_trends,
)

router = APIRouter(prefix="/dashboards", tags=["dashboards"])


@router.get("/summary", response_model=DashboardSummary)
def get_dashboard_summary(
    session: SessionDep,
    current_user: CurrentUser,
) -> DashboardSummary:
    can_view_all = rbac_service.is_system_admin(current_user)
    project_ids = None if can_view_all else rbac_service.get_accessible_project_ids(
        session, user=current_user
    )
    return build_dashboard_summary(session, project_ids=project_ids)


@router.get("/distributions", response_model=DashboardDistributions)
def get_dashboard_distributions(
    session: SessionDep,
    current_user: CurrentUser,
) -> DashboardDistributions:
    can_view_all = rbac_service.is_system_admin(current_user)
    project_ids = None if can_view_all else rbac_service.get_accessible_project_ids(
        session, user=current_user
    )
    return build_dashboard_distributions(session, project_ids=project_ids)


@router.get("/trends", response_model=DashboardTrendsPublic)
def get_dashboard_trends(
    session: SessionDep,
    current_user: CurrentUser,
    period: str = Query(default="week"),
    date_from: date | None = None,
    date_to: date | None = None,
) -> DashboardTrendsPublic:
    can_view_all = rbac_service.is_system_admin(current_user)
    project_ids = None if can_view_all else rbac_service.get_accessible_project_ids(
        session, user=current_user
    )
    end = date_to or date.today()
    start = date_from or (end - timedelta(days=30))
    if start > end:
        raise HTTPException(status_code=422, detail="date_from must be less than or equal to date_to")
    return build_dashboard_trends(
        session,
        period=period,
        date_from=start,
        date_to=end,
        project_ids=project_ids,
    )
