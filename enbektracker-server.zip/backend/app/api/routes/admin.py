from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from starlette import status

from app.api.deps import CurrentUser, SessionDep, get_current_active_superuser
from app.models import DesktopEventType, User
from app.schemas.admin import (
    AdminDesktopEventsTestRequest,
    AdminDesktopEventsTestResponse,
)
from app.schemas.demo_data import DemoDataSummary, DemoDataToggleRequest
from app.services import demo_data_service, desktop_event_service

router = APIRouter(
    prefix="/admin",
    tags=["admin"],
    dependencies=[Depends(get_current_active_superuser)],
)


@router.get("/demo-data", response_model=DemoDataSummary)
def get_demo_data_status(
    session: SessionDep,
    current_user: CurrentUser,
) -> DemoDataSummary:
    _ = current_user
    return demo_data_service.get_demo_data_summary(session)


@router.put("/demo-data", response_model=DemoDataSummary)
def set_demo_data_status(
    payload: DemoDataToggleRequest,
    session: SessionDep,
    current_user: CurrentUser,
) -> DemoDataSummary:
    return demo_data_service.set_demo_data_enabled(
        session,
        actor=current_user,
        enabled=payload.enabled,
    )


@router.post(
    "/users/{user_id}/desktop-events/test",
    response_model=AdminDesktopEventsTestResponse,
)
def send_test_desktop_events(
    user_id: int,
    payload: AdminDesktopEventsTestRequest,
    session: SessionDep,
    current_user: CurrentUser,
) -> AdminDesktopEventsTestResponse:
    target_user = session.get(User, user_id)
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    generated_at = datetime.now(timezone.utc).isoformat()
    base_payload = {
        "kind": "desktop_event_test",
        "mode": payload.mode,
        "generated_at": generated_at,
        "triggered_by_user_id": current_user.id,
        "target_user_id": target_user.id,
    }
    specs = [
        (
            DesktopEventType.ASSIGN,
            "Назначена задача (тест)",
            "Вам назначена задача 'Тестовое desktop-уведомление'",
        ),
        (
            DesktopEventType.DUE_SOON,
            "Срок задачи скоро наступит (тест)",
            "Задача 'Тестовое desktop-уведомление' скоро просрочится",
        ),
        (
            DesktopEventType.OVERDUE,
            "Задача просрочена (тест)",
            "Задача 'Тестовое desktop-уведомление' просрочена",
        ),
        (
            DesktopEventType.STATUS_CHANGED,
            "Статус задачи изменен (тест)",
            "Статус задачи 'Тестовое desktop-уведомление' изменен на Готово",
        ),
        (
            DesktopEventType.CLOSE_REQUESTED,
            "Запрошено закрытие задачи (тест)",
            "Запрошено закрытие задачи 'Тестовое desktop-уведомление'",
        ),
        (
            DesktopEventType.CLOSE_APPROVED,
            "Задача закрыта (тест)",
            "Задача 'Тестовое desktop-уведомление' была закрыта",
        ),
        (
            DesktopEventType.SYSTEM,
            "Системное событие (тест)",
            "Тестовое событие интеграции desktop-агента",
        ),
    ]
    if payload.mode == "single":
        specs = specs[:1]

    event_ids: list[int] = []
    for index, (event_type, title, message) in enumerate(specs, start=1):
        event = desktop_event_service.enqueue_event(
            session,
            user_id=target_user.id,
            event_type=event_type,
            title=title,
            message=message,
            deeplink="/tasks",
            payload={**base_payload, "sequence": index},
        )
        if event is not None:
            event_ids.append(event.id)

    return AdminDesktopEventsTestResponse(
        user_id=target_user.id,
        mode=payload.mode,
        created_count=len(event_ids),
        event_ids=event_ids,
    )
