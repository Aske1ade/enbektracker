# Server Deployment Quickstart (IP/Domain, no localhost bindings)

This setup is intended for a plain Linux server where users open the app by:

- `http://<server-ip>`
- or `http://<your-domain>`

It uses:

- `docker-compose.server.yml` (separate server stack)
- `.env.deploy` (separate deployment env file)
- `scripts/deploy-server.sh` (one-command deploy)

## 1. Prepare env file

On the server, in project root:

```bash
cp .env.deploy.example .env.deploy
```

Edit `.env.deploy` and set at minimum:

- `SERVER_HOST`
- `SECRET_KEY`
- `FIRST_SUPERUSER`
- `FIRST_SUPERUSER_PASSWORD`
- `POSTGRES_PASSWORD`
- `MINIO_ROOT_PASSWORD`

## 2. Deploy

```bash
./scripts/deploy-server.sh
```

Or directly:

```bash
docker compose --env-file .env.deploy -f docker-compose.server.yml up -d --build
```

## 3. Access

- Web UI: `http://SERVER_HOST` (port `APP_PORT`, default `80`)
- API docs: `http://SERVER_HOST/docs`

`frontend` proxies `/api`, `/docs`, `/redoc` internally to `backend`, so clients do not call `localhost`.

## 4. Update release

```bash
git pull
./scripts/deploy-server.sh
```

## 5. Useful commands

```bash
docker compose --env-file .env.deploy -f docker-compose.server.yml ps
docker compose --env-file .env.deploy -f docker-compose.server.yml logs -f backend
docker compose --env-file .env.deploy -f docker-compose.server.yml logs -f frontend
```
