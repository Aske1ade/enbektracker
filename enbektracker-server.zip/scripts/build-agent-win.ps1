param(
    [switch]$NsisOnly
)

$ErrorActionPreference = "Stop"
$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
if ($PSVersionTable.PSVersion.Major -ge 7) {
    $PSNativeCommandUseErrorActionPreference = $true
}

function Invoke-Step {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][scriptblock]$Action
    )

    Write-Host "-> $Name"
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name (exit code: $LASTEXITCODE)"
    }
}

function Stop-AgentProcess {
    $running = Get-Process -Name "desktop-agent" -ErrorAction SilentlyContinue
    if (-not $running) {
        return
    }

    Write-Host "-> Stopping running desktop-agent.exe before build"
    $running | Stop-Process -Force -ErrorAction Stop
    Start-Sleep -Seconds 1
}

function Remove-FileWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [int]$Attempts = 5
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    for ($i = 1; $i -le $Attempts; $i++) {
        try {
            Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            return
        }
        catch {
            if ($i -eq $Attempts) {
                throw "Cannot delete locked file: $Path. Close agent/tray process and retry."
            }
            Start-Sleep -Milliseconds 600
        }
    }
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$agentDir = Join-Path $repoRoot "desktop-agent"
$portableExe = Join-Path $agentDir "src-tauri\target\release\desktop-agent.exe"
$nsisPath = Join-Path $agentDir "src-tauri\target\release\bundle\nsis"
$releasePath = Join-Path $agentDir "src-tauri\target\release"

try {
    Invoke-Step -Name "Switch to $agentDir" -Action { Set-Location $agentDir }
    Stop-AgentProcess
    Remove-FileWithRetry -Path $portableExe

    Invoke-Step -Name "npm install" -Action { npm install }
    Invoke-Step -Name "npm run build" -Action { npm run build }

    if ($NsisOnly) {
        Invoke-Step -Name "npm run tauri:build:nsis" -Action { npm run tauri:build:nsis }
    }
    else {
        Invoke-Step -Name "npm run tauri:build" -Action { npm run tauri:build }
    }

    Write-Host ""
    Write-Host "Build completed successfully."
    Write-Host "Installer .exe: $nsisPath"
    Write-Host "Portable binary: $releasePath"
}
catch {
    Write-Error $_
    exit 1
}
